

#%%
from gprofiler import GProfiler
import matplotlib.pyplot as plt
from natsort import natsorted
import os
import numpy as np
import pandas as pd
import seaborn as sns
import sys

#from pybatch_mast import BatchMAST

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Define samples to analyze
samples = ['AGGR01_mapped',]
prefix = samples[0]
prefix

#%%
# Workdir is root workspace dir
os.chdir('/Sneha/RNAseq/ScSeq/test/scrna-seq-analysis/organoids')
current = os.getcwd()
current

#%%
# Helper closures for path generation
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

#%%
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join('AGGR01_mapped')
data = fullpath_closure(data_dir) 
out_dir = os.path.join( prefix)
out = fullpath_closure(out_dir)

#%%
# Import scanpy and configure figure parameters
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, figsize=(7,7), format ='eps')
sc.settings.figdir = out('fig_supp')

#%%
# Load main AnnData snapshot
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata



#%%

""" #%%
# Workdir is root workspace dir
os.chdir('../../..')
current = os.getcwd()
current
#sys.path.append(os.path.abspath('E:/Sneha/RNASeq/ScSeq/test/scrna-sc-analysis/organoids/AGGR01_mapped'))

#from fbrundu_sclib import *

#%%
samples = ['AGGR01_mapped',]
# 'AGGR01_unmapped']
prefix = samples[0]
prefix

#%%
# Helper closures for path generation
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath


#%%
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join(prefix)
data = fullpath_closure(data_dir) 
out_dir = os.path.join(prefix)
out = fullpath_closure(out_dir)
data_dir


#%%
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, figsize=(7,7), format="eps")
sc.settings.figdir = ('RNAseq/ScSeq/test/scrna-seq-analysis/organoids/contour_plot')

#%%
# Load main AnnData snapshot
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata """


#%%
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)
sc.pl.umap(adata)

#%%
sc.pl.umap(
    adata,
    color=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    save=f'.qc.preoutliers.pdf',
)

#%%
res_array = list(np.linspace(.01, .09, 9)) + list(np.linspace(.1, 1, 10))
res_array = [round(r, 2) for r in res_array]
res_array

#%%
for res in res_array:
    sc.tl.leiden(adata, resolution=res, key_added=f'leiden_{res}')

#%%
adata.write(out(f'{prefix}.final.h5ad'))

#%%
adata

#%%
sc.pl.umap(
    adata,
    color=[f'leiden_{r}' for r in res_array],
    save=f'.leiden.preoutliers.pdf',
    legend_loc='on data',
    ncols=6,
)

#%%
plot_silhouette(
    adata,
    n_comps=adata.obsm['X_liger_H'].shape[1],
    fname=out(f'fig_supp/leiden/silhouette_score.preoutliers.pdf'),
    rep='X_liger_H',
    algs=['leiden'],
    res_array=res_array,
)

#%%
res_prefix = {
    'AGGR01_mapped': 0.3,
}
res = res_prefix[prefix]
prefix, res

#%%
adata = sc.read(out(f'{prefix}.final.h5ad'))

#%%
sc.pl.umap(
    adata,
    color=[f'leiden_{res}'],
    save='.leiden.selected.preoutliers.pdf',
    legend_loc='on data',
)

#%%
adata.obs[f'leiden_{res}'].value_counts()

#%%
adata.write(out(f'{prefix}.final.h5ad'))

#%%
sc.pl.violin(
    adata,
    keys=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
    ],
    groupby=f'leiden_{res}',
    save=f'.qc.leiden_{res}.preoutliers.pdf',
    cut=0,
)

#%%
# https://academic.oup.com/gigascience/article/8/9/giz106/5570567
# http://shiny.maths.usyd.edu.au/SEGs/
# SEG index > .9, Lambda < .1, Sigma < .1, Omega <.1, F < .4
segs = list(set('SNRPD3 PFN1 SRRM1 HNRNPA2B1 YWHAB RPL36 GDI2 NCL RPL8 CSDE1 C14ORF2 ARF1 TARDBP STOML2 RPS5 SRSF3 CKS1B COX6A1 RPL15 RPS19 NPM1 EIF3I DHX9 ETF1 C9ORF78 RSL1D1 ZC3H15 YWHAE MAPRE1 RPS20 COX5B RPS6 NASP RHOA CSNK2B MRPL20 SF3A3 EEF1B2 DDX18 RPL7A WDR43 NACA RPS25 SF3B5 PTMA EIF3L CHCHD2 SNRPG SRSF10.UID_1003 RBM17 SZRD1 RPS24 RPL10A EBNA1BP2 SF3B1 RPS13 NACA2 FAM96B RBMX PLEKHB2 RPL18A SARNP RPS14P3 NDUFA6 DAP3 DRG1 SRP14 POP7 NUDC LRRC75A.AS1 NOP58 SNRPE UBA52 RPLP0 OTUB1 PRPF40A SNHG16 NOP56 RPL35 RPL26 EIF3G IK CYCS SUMO1 STAU1 RPS7 RPL6 SEC61B DENR STIP1 MRPL57 DNAJC8 NOLC1 TMA7'.split()) & set(adata.raw.var_names))
segs

#%%
sc.pl.dotplot(
    adata,
    var_names=segs,
    groupby=f'leiden_{res}',
    color_map='viridis',
    save=f'.segs.leiden_{res}.preoutliers.pdf',
    use_raw=True,
)
sc.pl.dotplot(
    adata,
    var_names=segs,
    groupby='batch',
    color_map='viridis',
    save=f'.segs.batch.preoutliers.pdf',
    use_raw=True,
)

#%%
adata.obs[f'leiden_{res}'].value_counts()

#%%
res_prefix = {
    'AGGR01_mapped': 0.3,
}
res = res_prefix[prefix]
prefix, res

#%%
job_queue = 'x1e-xlarge-4vCPU-120GB'
job_def = 'fb2505-mast'
bucket = 'fb2505-devnull'
layer = 'counts'
bmast = BatchMAST(
    job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
)

#%%
key = f'leiden_{res}_outliers'
adata.obs[key] = adata.obs[f'leiden_{res}'].astype(str)

#%%
n_cells = adata.obs[f'leiden_{res}'].value_counts()
n_cells

#%%
clusters = n_cells[n_cells < 100].index.tolist()
clusters

#%%
adata.obs.loc[~adata.obs[f'leiden_{res}'].isin(clusters), key] = 'OTHER'
adata.obs[key] = pd.Categorical(adata.obs[key])
adata.obs[key]

#%%
adata.obs[key].value_counts()

#%%
n = 200
cells = adata.obs.groupby(f'leiden_{res}').apply(
    lambda x: x.sample(n) if len(x) >= n else x
).index.levels[1]
adata_o = adata[cells].copy()
sc.pp.filter_genes(adata_o, min_cells=1)
adata_o

#%%
n_cells = adata_o.obs[key].value_counts()
n_cells

#%%
# NOTE genes expressed in at least k cells
min_genes = 30
min_perc = min_genes/min(n_cells)
jobs = 1
min_perc, jobs

#%%
keys = [
    'n_genes', 'batch', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', key,
    'myo_perc_legacy',
]
group = key
fdr = .05
lfc = 1
covs_l = ['+pair+percent_mito+percent_ribo_p',]
# '+batch+pair+percent_mito+percent_ribo_p+myo_perc_legacy',]
print(f'Using {jobs} jobs')
for covs in covs_l:
    for de, top, by in bmast.mast(
        adata_o, keys, group, fdr, lfc, covs,
        min_perc=min_perc, on_total=False, jobs=jobs,
    ):
        fname = out(f'interim_data/leiden/mast/de.{group}{covs}') 
        bmast.mast_to_excel(de, fname, top=top)

#%%
# covs = '+pair+percent_mito+percent_ribo_p'
# de = {}
# de['Sheet0'] = bmast._mast_results(
    # remote_dir='mast/b4f1f6f3-b8c5-44f3-8dd1-08800c68c8c2/'
# )
# top = bmast.mast_filter(de, lfc=1, fdr=.05)

#%%
# key = f'leiden_{res}_outliers'
# group = key
# fdr = .05
# lfc = 1
# covs = '+pair+percent_mito+percent_ribo_p'
# fname = out(f'interim_data/leiden/mast/de.{group}{covs}.top.xlsx') 
# top = pd.read_excel(fname, sheet_name=None)
# top = {k: list(top['Sheet0'][k].dropna()) for k in top['Sheet0']}

#%%
# NOTE fine resolution, results with no iea and no ambiguous genes
# result = {}
# for c in top['Sheet0']:
    # genes = top['Sheet0'][c]
    # if len(genes) > 0:
        # result[c] = profile_disambiguate(
            # org='hsapiens', query_genes=genes, ordered=True, no_iea=False,
        # )
# result = {k: v for k, v in result.items()}
# if len(result) > 0: 
    # fname = out(
        # f'interim_data/leiden/mast/enrichment/'
        # f'gprof.de.{group}{covs}'
    # ) 
    # tl_gprof_excel(result, fname)

#%%
base_url = 'https://biit.cs.ut.ee/gprofiler_archive3/e98_eg45_p14/'
result = {}
for c in top:
    genes = top[c]
    if len(genes) > 0:
        result[c] = profile_disambiguate(
            base_url=base_url, org='hsapiens', query_genes=genes,
            ordered=False, no_iea=True, no_evidences=False, user_threshold=.05,
            significance_threshold_method='fdr',
        )
result = {k: v for k, v in result.items()}
if len(result) > 0: 
    fname = out(
        f'interim_data/leiden/mast/enrichment/'
        f'gprof.de.{group}{covs}'
    ) 
    tl_gprof_excel(result, fname)

#%%
# NOTE fine resolution
# 19 - ER stress, UPR, Apoptosis
# 20 - Cell cycle, Execution of Apoptosis
# 21 - Cilium Assembly, probably Ependymal cells, only 31 cells - excluded at this time
# 22-end - Fewer than 30 cells
# NOTE coarse resolution
# 18 - ER stress, UPR, Apoptosis
# 19 - Cell cycle, Execution of Apoptosis
# 20 - Cilium Assembly, probably Ependymal cells, only 31 cells - excluded at this time
# 21-end - Fewer than 30 cells
adata.write(out(f'interim_data/leiden/data.prefilter.h5ad'))
adata = adata[~adata.obs[f'leiden_{res}'].isin([str(i) for i in range(18, 27)])].copy()

#%%
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)

#%%
key = 'nowakowski.fine.noglyc_unmapped'
# key = 'nowakowski.coarse.noglyc_unmapped'
sc.pl.umap(adata, color=key)

#%%
adata.obs[key].value_counts()

#%%
nmarkers = natsorted(list(set(['SLC17A7', 'SLC17A6', 'GAD1', 'GAD2', 'EOMES', 'DCX', 'SYN1', 'VIM', 'OLIG1', 'OLIG2', 'GFAP', 'P2RY12', 'CLDN5', 'SOX2', 'SOX9', 'DLX1', 'DLX5', 'NEUROD1', 'NEUROG1', 'NEUROG2', 'HEXB', 'C1QA', 'C1QB', 'C1QC', 'TREM2', 'TYROBP', 'CX3CR1', 'TMEM119']) & set(adata.raw.var_names)))
sc.pl.dotplot(
    adata,
    var_names=nmarkers,
    color_map='viridis',
    use_raw=True,
    save=f'.neural_markers.prefilter.{key}.pdf',
    groupby=f'{key}',
    mean_only_expressed=True,
    dendrogram=True,
    # dot_max=0.7,
)

#%%
adata.obs[key].value_counts()

#%%
# Removing cell types with fewer than 30 cells and Microglia which don't seem
# to express many Microglial markers (possibly spurious annotation)

#%%
adata = adata[~adata.obs[key].isin([
    'Microglia', 'Endothelial', 'Mural', 'OPC',
])].copy()

#%%
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)
sc.pl.umap(adata, color=key)

#%%
adata.write(out(f'{prefix}.final.h5ad'))

#%%
nmarkers = natsorted(list(set(['SLC17A7', 'SLC17A6', 'GAD1', 'GAD2', 'EOMES', 'DCX', 'SYN1', 'VIM', 'OLIG1', 'OLIG2', 'GFAP', 'P2RY12', 'CLDN5', 'SOX2', 'SOX9', 'DLX1', 'DLX5', 'NEUROD1', 'NEUROD2', 'NEUROG1', 'NEUROG2', 'HEXB', 'C1QA', 'C1QB', 'C1QC', 'TREM2', 'TYROBP', 'CX3CR1', 'TMEM119']) & set(adata.raw.var_names)))
sc.pl.umap(
    adata,
    color=nmarkers,
    cmap='viridis',
    save='.neural_markers.pdf',
)

#%%
sc.tl.dendrogram(adata, key)
sc.pl.dotplot(
    adata,
    var_names=nmarkers,
    color_map='viridis',
    use_raw=True,
    save=f'.neural_markers.{key}.pdf',
    groupby=f'{key}',
    mean_only_expressed=True,
    dendrogram=True,

#%%
def contour_density(
        adata, basis='umap', groupby=None, fname=None, kde=False,
        color=None, colormap=None, lw=.8, contour_color='k',
        min_level=.25, alpha=.5, vmin=None, vmax=None,
    ):
    import matplotlib.pyplot as plt
    import numpy as np
    import seaborn as sns
    if groupby:
        cat = adata.obs[groupby].cat.categories
        n = len(cat)
    else:
        cat = ''
        n = 1
    fig, axs = plt.subplots(nrows=1, ncols=n, figsize=(n*5,6))
    emb = f'X_{basis}'
    axlabel = basis.upper()
    for i, c in enumerate(cat):
        if n > 1:
            cells = adata.obs[groupby].isin([c])
            k = f'{basis}_density_{groupby}'
        else:
            cells = adata.obs_names
            k = f'{basis}_density'
        if kde:
            sns.kdeplot(
                adata.obsm[emb][cells, 0],
                adata.obsm[emb][cells, 1],
                ax=axs[i], cmap='viridis', shade=True,
                shade_lowest=False, cbar=True,
            )
        else:
            cl = axs[i].tricontour(
                adata.obsm[emb][cells, 0],
                adata.obsm[emb][cells, 1],
                adata.obs.loc[cells, k],
                colors=contour_color,
                linewidths=lw,
                levels=np.linspace(min_level,1,10),
            )
            axs[i].clabel(cl, fontsize=4, inline=1)
        axs[i].set_title(c)
        axs[i].set_xlabel(f'{axlabel}1')
        axs[i].set_ylabel(f'{axlabel}2')
        axs[i].xaxis.set_ticklabels('')
        axs[i].yaxis.set_ticklabels('')
        axs[i].grid(False)
        if color is None:
            c = 'lightgrey'
        else:
            c = adata.obs.loc[cells, color].values
        plot = axs[i].scatter(
            adata.obsm[emb][cells, 0],
            adata.obsm[emb][cells, 1],
            c=c, s=1, alpha=alpha, cmap=colormap,
            vmin=vmin, vmax=vmax,
        )
        plt.colorbar(plot, orientation='horizontal', ax=axs[i])
    if fname:
        plt.savefig(fname, bbox_inches='tight', format ='eps')
    else:
        return fig

#%%
sc.tl.embedding_density(
    adata,
    basis='umap',
    groupby='genotype',
)

#%%
fname = out('fig_supp/umap.contour.genotype.eps')
contour_density (adata, basis='umap', groupby='genotype', fname=fname)

#%%
for tp in ['70d', '150d']:
    fname = out(f'fig_supp/umap.contour.genotype.{tp}.eps')
    contour_density(
        adata[adata.obs['timepoint'] == tp, :], basis='umap',
        groupby='genotype', fname=fname,
    )

#%%
for tp in ['70d', '150d']:
    fname = out(f'fig_supp/umap.contour.batch.{tp}.eps')
    adata_t = adata[adata.obs['timepoint'] == tp, :].copy()
    sc.tl.embedding_density(adata_t, basis='umap', groupby='batch')
    contour_density(adata_t, basis='umap', groupby='batch', fname=fname)


#%%
# Main key label used for cell type annotation
key = 'nowakowski.fine.noglyc_unmapped'

#%%
# Plot annotations UMAPs

sc.pl.umap(
    adata,
    color=list(key),
    cmap='viridis',
    ncols=1,
    save='.annotation.unmapped.eps',
)


#%%
#for tp in ['70d', '150d']:
    #fname = out(f'fig_supp/umap.{tp}.eps')
adata_70t = adata[adata.obs['timepoint'] == "70d"]
sc.pl.umap (
    adata_70t,
        color = [ 'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    legend_loc='right margin',
    ncols=1,
    save='.70D.qc.postoutliers',
)









#########################################################################
#%% 

# from fbrundu_sclib_mast import 
from fbrundu_sclib_singler import *
from fbrundu_sclib_tl import *

import pandas as pd
from typing import Dict, List

# Lambda utilities
flatten = lambda l: [e for sl in l for e in sl]

def fb_setup(out_dir, data_dir=None, cellranger_dir=None):
    import scanpy as sc
    out = fullpath_closure(out_dir)
    data = fullpath_closure(data_dir) if data_dir else None
    cellranger = fullpath_closure(cellranger_dir) if cellranger_dir else None
    sc.settings.verbosity = 3
    sc.settings.set_figure_params(dpi=150, dpi_save=150)
    sc.settings.figdir = out('fig_supp')
    return out, data, cellranger

def pp_read(raw_filename, genome, densify=True, filename=None, meta=None):
    import os
    import pandas as pd
    import scanpy as sc
    if os.path.isfile(raw_filename):
        print('Raw file already exists. Reading it...')
        adata = _pp_read_raw(raw_filename, densify)
    else:
        adata = _pp_read_10x(filename, genome, densify, raw_filename)
    sc.pl.highest_expr_genes(adata, n_top=40, save='.pdf');
    adata.obs['batch'] = adata.obs_names.str.split('-').str[1]
    if meta is not None:
        adata.obs = pd.merge(adata.obs, meta, left_on='batch', right_index=True)
    return adata

def _pp_read_raw(raw_filename, densify):
    import numpy as np
    import scanpy as sc
    from scipy import sparse
    adata = sc.read(raw_filename)
    if densify and type(adata.X) == sparse.csr.csr_matrix:
        print('Densifying matrix...')
        adata.X = adata.X.todense()
    elif not densify and type(adata.X) == np.ndarray:
        print('Creating sparse matrix...')
        adata.X = sparse.csr.csr_matrix(adata.X)
    return adata

def _pp_read_10x(filename, genome, densify, raw_filename):
    import scanpy as sc
    # Cellranger 3
    adata = sc.read_10x_h5(filename=filename, genome=genome, gex_only=True)
    if densify:
        adata.X = adata.X.todense()
    adata.var_names_make_unique()
    if raw_filename:
        adata.write(raw_filename)
        adata = sc.read(raw_filename)
    return adata

def pp_preqc(adata, preqc_h5ad, genome=None):
    import scanpy as sc
    assert 'genome' in adata.var.columns or genome
    if not genome:
        genome = adata.var['genome'].unique()[0]
        print(f'No genome provided. {genome} inferred from data')
    _pp_preqc_spike(adata, genome)
    _pp_preqc_mito(adata, genome)
    _pp_preqc_ribo(adata, genome)
    _pp_preqc_segs(adata, genome)
    sc.pp.calculate_qc_metrics(
        adata,
        qc_vars=['mito', 'ribo_p', 'segs'],
        percent_top=None,
        inplace=True,
    )
    _pp_preqc_plots(adata, groupby=['batch'])
    adata.write(preqc_h5ad)

def pp_postqc(adata):
    sc.pl.highest_expr_genes(adata, n_top=40, save='.filter.pdf')
    sc.pl.dotplot(
        adata,
        var_names=adata.var_names[adata.var['segs']],
        groupby='batch',
        color_map='viridis',
        mean_only_expressed=False,
        save='.filter.segs.batch.pdf',
    )

def pp_qc(adata, min_counts=None, max_counts=None, min_genes=None, max_genes=None, max_mito=None, min_segs=None):
    import scanpy as sc
    if min_counts or max_counts or min_genes or max_genes:
        sc.pp.filter_cells(
            adata,
            min_counts=min_counts,
            max_counts=max_counts,
            min_genes=min_genes,
            max_genes=max_genes,
        )
    if max_mito:
        adata = adata[adata.obs['pct_counts_mito'] < max_mito, :].copy()
    if min_segs:
        adata = adata[adata.obs['pct_counts_segs'] < min_segs, :].copy()
    sc.pp.calculate_qc_metrics(
        adata,
        qc_vars=['mito', 'ribo_p', 'segs'],
        percent_top=None,
        inplace=True,
    )
    _pp_preqc_scatter(
        adata,
        x='total_counts',
        y='n_genes_by_counts',
        c='pct_counts_mito',
        save='.qc.lib_det_mito.filter.pdf',
    )
    sc.pp.filter_genes(adata, min_cells=3)
    return adata

def pp_downsample(adata, counts_per_cell):
    import scanpy as sc
    sc.pp.downsample_counts(adata, counts_per_cell=int(counts_per_cell))
    sc.pp.calculate_qc_metrics(
        adata,
        qc_vars=['mito', 'ribo_p', 'segs'],
        percent_top=None,
        inplace=True,
    )
    _pp_preqc_plots(adata, groupby=['batch'])

def _pp_preqc_plots(adata, groupby):
    if groupby is None:
        groupby = []
    metrics = [
        'n_genes_by_counts',
        'total_counts',
        'pct_counts_mito',
        'pct_counts_ribo_p',
        'pct_counts_segs',
    ]
    _pp_preqc_violin(adata, metrics, f'.qc.pdf')
    for gb in groupby:
        _pp_preqc_violin(adata, metrics, f'.qc.{gb}.pdf', groupby=gb)
    _pp_preqc_scatter(
        adata,
        x='total_counts',
        y='n_genes_by_counts',
        c='pct_counts_mito',
        save='.qc.lib_det_mito.pdf',
    )

def _pp_preqc_violin(adata, metrics, save, groupby=None):
    import scanpy as sc
    sc.pl.violin(
        adata,
        metrics,
        jitter=0.4,
        multi_panel=True,
        save=save,
        cut=0,
        groupby=groupby,
    )

def _pp_preqc_scatter(adata, x, y, c, save):
    import scanpy as sc
    sc.pl.scatter(
        adata,
        color=c,
        x=x,
        y=y,
        frameon=True,
        save=save,
        color_map='viridis',
    )

def _pp_preqc_spike(adata, genome):
    spike = []
    if genome in ['mm10']:
        spike = genes_startswith(adata, ['ercc-'])
    else:
        print(f'Genome {genome} not specified')
    print(f'{len(spike)} spike genes found')
    assert len(spike) == 0

def _pp_preqc_mito(adata, genome):
    mito = []
    if genome in ['mm10']:
        mito = genes_startswith(adata, ['mt-'])
        adata_var_mask(adata, 'mito', mito)
    else:
        print(f'Genome {genome} not specified')
    print(f'{len(mito)} mitochondrial genes found')

def _pp_preqc_ribo(adata, genome):
    ribo_p = []
    ribo_r = []
    if genome in ['mm10']:
        ribo_p = genes_startswith(adata, ['rpl', 'rps', 'mrpl', 'mrps'])
        adata_var_mask(adata, 'ribo_p', ribo_p)
        ribo_r = genes_startswith(adata, ['rn45s', 'rn4.5s'])
    else:
        print(f'Genome {genome} not specified')
    print(f'{len(ribo_p)} ribosomal protein genes found')
    assert len(ribo_r) == 0

def _pp_preqc_segs(adata, genome):
    # https://academic.oup.com/gigascience/article/8/9/giz106/5570567
    # http://shiny.maths.usyd.edu.au/SEGs/
    # SEG index > .9, Lambda < .1, Sigma < .1, Omega <.1, F < .4
    if genome in ['mm10']:
        segs = set(
            'Gdi2 Birc6 Hdlbp Hnrnpu 2310003F16Rik H3F3B Ptp4A2 Hnrnpc Smc4 Rbm39 Prpf40A Smc3 Csnk2B Ubl5 Kif5B Txndc9 Csde1 Rbm25 Atp5B Ahsa1 Rhoa Sf3B1 Rbm8A Ssu72 Ddx5 Rai12 Eif5B Sfpq Atf4 Snrpe Cwc15 Mapk1Ip1L Pfdn2 Rfc1 St13 Csl Ptbp1 Cs G3Bp2 Eif3I Mapre1 Anp32B Smu1 G3Bp1 Rsl1D1 Eprs Ubqln1 Rad21 Dkc1 Tpd52L2 Cnot1 Sec11A Orc6 Rnf4 Hmgb2 Usp7 Ncbp2 Rnmt Qars Brix1'.split()
        )
        segs &= set(adata.var_names)
        adata_var_mask(adata, 'segs', segs)
    else:
        print(f'Genome {genome} not specified')
    print(f'{len(segs)} stably expressed genes found')

def min_lfc(out_folder, gb, fdr, ref_genes, ref_group):
    import os
    import pandas as pd
    de_df = pd.read_csv(
        os.path.join(
            out_folder, f'interim_data/de.{gb}.csv',
        ),
        index_col=0,
    )
    del_df = de_df.loc[
        set(ref_genes) & set(de_df.index),
        de_df.columns[de_df.columns.str.startswith(f'{ref_group}_')]
    ]
    lfc = trunc(
        del_df.loc[
            del_df[f'{ref_group}_pvals_adj'] < fdr,
            f'{ref_group}_logfoldchanges'
        ].min(),
        decs=3,
    )
    return lfc

def pl_multi_violin(adata, keys, groupby, fname, ncols=4, wspace=0.4):
    import matplotlib.pyplot as plt
    import scanpy as sc
    r = len(keys) // ncols + int((len(keys) % ncols) != 0)
    fig, axs = plt.subplots(r, ncols, figsize=(ncols*5, r*5))
    axs = axs.ravel()
    for i, ax in enumerate(axs):
        if i < len(keys):
            k = keys[i]
            sc.pl.violin(adata, keys=k, groupby=groupby, ax=ax, show=False)
        else:
            ax.axis('off')
    plt.subplots_adjust(wspace=wspace)
    fig.savefig(fname, bbox_inches='tight')

### NOTE Usage below
def corrfunc(x, y, ax=None, **kws):
    """Plot the correlation coefficient in the top left hand corner of a plot."""
    from scipy.stats import pearsonr
    import matplotlib.pyplot as plt
    r, p = pearsonr(x, y)
    ax = ax or plt.gca()
    # Unicode for lowercase rho (ρ)
    # rho = '\u03C1'
    ax.annotate(
        f'Pearson\'s r = {r:.2f}\np-val = {p:.2e}', xy=(.5, .9),
        xycoords=ax.transAxes, fontsize='xx-small',
    )

### NOTE Usage for corrfunc
# g = sns.PairGrid(df)
# g.map_diag(sns.histplot)
# g.map_offdiag(corrfunc)
# g.map_offdiag(sns.scatterplot, marker='.', linewidth=.1, s=7)

def trunc(values, decs=0):
    import numpy as np
    return np.trunc(values*10**decs) / (10**decs)

def pl_sankey(df, label_color, categories, value, title='Sankey Diagram', fname=None, width=3000, height=1600, scale=2):
    from IPython.display import Image
    import plotly.graph_objects as go
    import pandas as pd
    df = df.copy()
    labels = []
    colors = []
    for k, v in label_color.items():
        labels += [k]
        colors += [v]
    # transform df into a source-target pair
    st_df = None
    for i in range(len(categories)-1):
        _st_df = df[[categories[i],categories[i+1],value]]
        _st_df.columns = ['source', 'target', 'count']
        st_df = pd.concat([st_df, _st_df])
        st_df = st_df.groupby(['source', 'target']).agg({'count': 'sum'}).reset_index()
    # add index for source-target pair
    st_df['sourceID'] = st_df['source'].apply(lambda x: labels.index(str(x)))
    st_df['targetID'] = st_df['target'].apply(lambda x: labels.index(str(x)))
    # creating the sankey diagram
    data = dict(
        type='sankey', node=dict(
            pad=15, thickness=20, line = dict(color='black', width=0.5), label=labels, color=colors,
        ),
        link=dict(source=st_df['sourceID'], target=st_df['targetID'], value=st_df['count']),
    )
    layout = dict(title=title, font=dict(size=16, family='Arial'))  
    fig = go.Figure(dict(data=[data], layout=layout))
    if fname:
        fig.write_image(f'{fname}.pdf', format='pdf', width=width, height=height, scale=scale)
    return Image(fig.to_image(format='png', width=width, height=height, scale=scale))

def pl_dotplot(adata, sign, gb, n=10, cmap='viridis', save=None, show=None):
    from natsort import natsorted
    import scanpy as sc
    sign = {c: sign[c][:n] for c in sign if len(sign[c]) > 0}
    var_names, var_group_labels, var_group_positions =  prepare_dotplot(sign)
    if save:
        save = f'{save}.pdf'
    if len(var_names) > 0:
        adata.obs[gb] = adata.obs[gb].cat.reorder_categories(
            natsorted(adata.obs[gb].cat.categories)
        )
        sc.pl.dotplot(
            adata,
            var_names=var_names,
            var_group_labels=var_group_labels,
            var_group_positions=var_group_positions,
            groupby=gb,
            color_map=cmap,
            standard_scale='var',
            save=save,
            show=show,
        )

def pl_ridge(df, x, y, fname, split=None, pal=None, bw='scott'):
    import numpy as np
    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt

    sns.set(style='white', rc={'axes.facecolor': (0, 0, 0, 0)})
    # Initialize the FacetGrid object
    # if pal is None:
        # pal = sns.cubehelix_palette(10, rot=-.25, light=.7)
    if split is None:
        hue = y
        shade = True
        hue_pal = pal
    else:
        hue = split
        shade = False
        hue_pal = ['#ff0000', '#333333']
    g = sns.FacetGrid(
        df, row=y, hue=hue, aspect=15, height=.5, palette=hue_pal,
    )
    # Draw the densities in a few steps
    g.map(
        sns.kdeplot, x, clip_on=False, shade=shade, alpha=1, lw=1, bw=bw,
    )
    if shade:
        g.map(
            sns.kdeplot, x, clip_on=False, color='w', lw=1, bw=bw,
        )
        g.map(plt.axhline, y=0, lw=2, clip_on=False)
    else:
        for i_c, (label, ax) in enumerate(zip(g.row_names, g.axes.flat)):
            ax.axhline(y=0, lw=1, clip_on=False, color='#333333')
    g.map(sns.rugplot, x, height=.1)
    # Define and use a simple function to label the plot in axes coordinates
    if split is None:
        def label(x, color, label):
            ax = plt.gca()
            ax.text(0, .2, label, fontweight='bold', color=color,
                    ha='left', va='center', transform=ax.transAxes)
        g.map(label, x)
    else:
        for i_c, (label, ax) in enumerate(zip(g.row_names, g.axes.flat)):
            ax.text(0, .2, label, fontweight='bold', color=pal[i_c],
                    ha='left', va='center', transform=ax.transAxes)
            for i_hc, label in enumerate(g.hue_names):
                ax.text(1, .4-.3*i_hc, label, fontsize='small',
                    fontweight='bold', color=hue_pal[i_hc], ha='left',
                    va='bottom', transform=ax.transAxes)

    if shade:
        # Set the subplots to overlap
        g.fig.subplots_adjust(hspace=-.25)
    else:
        g.fig.subplots_adjust(hspace=-.02)
    # Remove axes details that don't play well with overlap
    g.set_titles('')
    g.set(yticks=[])
    g.despine(bottom=True, left=True)
    g.savefig(fname, bbox_inches='tight')

def pl_rank_tfs_specificity(rss, fname):
    from adjustText import adjust_text
    import matplotlib.pyplot as plt
    import numpy as np
    from pyscenic.plotting import plot_rss
    cats = sorted(list(rss.index))
    l = len(cats)
    side = int(np.ceil(np.sqrt(l)))
    fig = plt.figure(figsize=(5*side, 5*side))
    for i, c in enumerate(cats):
        x = rss.T[c]
        ax = fig.add_subplot(side, side, i+1)
        plot_rss(rss, c, top_n=10, max_n=None, ax=ax)
        ax.set_ylim(
            x.min()-(x.max()-x.min())*0.05,
            x.max()+(x.max()-x.min())*0.05
        )
        for t in ax.texts:
            t.set_fontsize(12)
        ax.set_ylabel('')
        ax.set_xlabel('')
        adjust_text(
            ax.texts, autoalign='xy', ha='right', va='bottom',
            arrowprops=dict(arrowstyle='-',color='lightgrey'),
            precision=0.001
        )
    fig.text(
        0.5, 0.0, 'Regulon', ha='center', va='center',
        size='x-large'
    )
    fig.text(
        0.00, 0.5, 'Regulon specificity score (RSS)',
        ha='center', va='center', rotation='vertical',
        size='x-large'
    )
    plt.tight_layout()
    plt.rcParams.update({
        'figure.autolayout': True,
        'figure.titlesize': 'large' ,
        'axes.labelsize': 'medium',
        'axes.titlesize':'large',
        'xtick.labelsize':'medium',
        'ytick.labelsize':'medium'
    })

    plt.savefig(fname, dpi=600, bbox_inches='tight')

def adata_var_mask(adata, mask_name, genes):
    adata.var.loc[adata.var.index & genes, mask_name] = True
    adata.var.loc[adata.var.index ^ genes, mask_name] = False
    adata.var[mask_name] = adata.var[mask_name].astype(bool)

def genes_startswith(adata, prefix_l):
    genes = set()
    for p in prefix_l:
        mask = adata.var_names.str.lower().str.startswith(p)
        genes |= set(adata.var_names[mask])
    return list(genes)

def print_Cs(adata, prefix='PC', n_genes=100, n_comps=20, return_dict=False):
    import pandas as pd
    d = {}
    for i in range(n_comps):
        print(f'> {prefix}{i}')
        pc = pd.DataFrame(
            adata.varm[f'{prefix}s'][:,i],
            index=adata.var_names,
            columns=[prefix],
        )
        pc = pc.abs().sort_values(
            by=prefix,
            ascending=False,
        ).head(n_genes).index.tolist()
        print('\n'.join(pc))
        if return_dict:
            d[i] = pc
    return d

def pl_factors(
    adata,
    factors: List[int] = None,
    ncols: int = 4,
    rep: str = 'X_liger_H',
    suffix: str = '',
    violin_groupby: str = None,
    violin_fname: str = '',
):
    import scanpy as sc
    _adata = adata.copy()
    factors_names = []
    if factors is None:
        factors = range(_adata.obsm[rep].shape[1])
    for f in factors:
        _adata.obs.loc[:, f'Factor{f}'] = pd.Series(
            _adata.obsm[rep][:, f], index=_adata.obs_names,
        )
        factors_names += [f'Factor{f}']
    sc.pl.umap(
        _adata, color=factors_names, cmap='viridis', ncols=ncols,
        save=f'.liger_factors{suffix}.pdf',
    )
    if violin_groupby is not None:
        pl_multi_violin(
            _adata, factors_names, violin_groupby, violin_fname,
        )

def print_factors(
        adata, varm, prefix='C', n_genes=100, n_comps=20, return_dict=False,
    ):
    import pandas as pd
    d = {}
    for i in range(n_comps):
        # print(f'> {i}')
        c = pd.Series(
            adata.varm[varm][:,i],
            index=adata.var_names,
        )
        c = c[c > 0].sort_values(
            ascending=False,
        )
        if n_genes > 1:
            c = c.head(n_genes)
        else:
            c /= c.sum()
            c = c[c.cumsum() < n_genes]
        c = c.index.tolist()
        # print('\n'.join(c))
        if return_dict:
            d[i] = c
    return d

def profile_disambiguate(
    org: str,
    query_genes: List[str],
    ordered: bool,
    no_iea: bool,
    base_url: str = None,
    **kwargs,
) -> pd.DataFrame:
    from gprofiler import GProfiler
    gp = GProfiler(
        base_url=base_url,
        return_dataframe=True,
    )
    print('> Pre-profiling...')
    pre = gp.profile(
        organism=org, query=query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )
    meta = gp.meta['genes_metadata']
    print(
        f'  Failed: {len(meta["failed"])},'
        f' Ambiguous: {len(meta["ambiguous"])}'
    )
    print('  ', ' '.join(meta['ambiguous'].keys()))
    best = {
        gene: max(
            meta['ambiguous'][gene],
            key=lambda x: x['number_of_go_annotations']
        )['gene_id']
        for gene in meta['ambiguous'].keys()
    }
    print(f'  Disambiguated: {len(best)}')
    final_query_genes = [
        gene if gene not in best else best[gene]
        for gene in query_genes
    ]
    print(f'  Final profiling...')
    final = gp.profile(
        organism=org, query=final_query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )   
    # Fewer ambiguous genes now
    meta = gp.meta['genes_metadata']
    try:
        assert len(meta['ambiguous']) == 0
    except AssertionError:
        print('  Some genes have still ambiguous annotation')
    return final

def barplot(
        x, y, adata, by=None, fig_folder=None, palette=None, stacked=True,
        fname=None, normalize=True, order=None,
    ):
    import matplotlib.pyplot as plt
    import os
    # Default
    nrows = 1
    ncols = 1
    if by is not None:
        if 'row' in by.keys():
            rows = by['row'][1]
            nrows = len(rows)
        else:
            rows = ['all']
        if 'col' in by.keys():
            cols = by['col'][1]
            ncols = len(cols)
        else:
            cols = ['all']
    figsize = (10*ncols, 7*nrows)
    f, ax = plt.subplots(nrows, ncols, figsize=figsize, sharey=True)
    if nrows > 1 or ncols > 1:
        ax = ax.ravel()
    if by is None:
        data = adata.obs[[x, y]]
        _barplot_internal(data, x, y, palette, stacked, ax, order=order, normalize=normalize)
    else:
        for i, r in enumerate(rows):
            if r != 'all':
                data_r = adata.obs.loc[adata.obs[by['row'][0]] == r].copy()
            else:
                data_r = adata.obs.copy()
            for j, c in enumerate(cols):
                if c != 'all':
                    data = data_r.loc[
                        data_r[by['col'][0]] == c, [x, y]
                    ].copy()
                else:
                    data = data_r.loc[:, [x, y]].copy()
                _barplot_internal(
                    data, x, y, palette, stacked, ax[i*ncols+j], order=order,
                    normalize=normalize,
                )
        plt.tight_layout()
    plt.legend(bbox_to_anchor=(1.1, .55), ncol=1, prop={'size': 10})
    by_pref = ''
    if by is not None:
        if 'row' in by.keys():
            by_pref += f'.{by["row"][0]}'
        if 'col' in by.keys():
            by_pref += f'.{by["col"][0]}'
    if not normalize:
        norm_pref = ''
    else:
        norm_pref = '.norm'
    if fig_folder is not None:
        plt.savefig(
            os.path.join(fig_folder, f'bar{by_pref}.{x}.{y}{norm_pref}.pdf'),
            bbox_inches='tight',
        )

def scan_hdf5(path, recursive=True, tab_step=2):
    def scan_node(g, tabs=0):
        print(' ' * tabs, g.name)
        for k, v in g.items():
            if isinstance(v, h5py.Dataset):
                print(' ' * tabs + ' ' * tab_step + ' -', v.name)
            elif isinstance(v, h5py.Group) and recursive:
                scan_node(v, tabs=tabs + tab_step)
    with h5py.File(path, 'r') as f:
        scan_node(f)

def _barplot_internal(
        data, x, y, palette, stacked, ax, order=None, normalize=True,
    ):
    import matplotlib.pyplot as plt
    from natsort import natsorted
    counts = data.groupby([x,y]).agg(len).to_frame()
    counts.columns = ['counts']
    total = data.groupby([x]).agg(len)
    total.columns = ['counts']
    if normalize:
        data = counts / total
        ylabel = '% of cells'
    else:
        data = counts
        ylabel = 'n of cells'
    data = data.reset_index()
    data = data.pivot(index=x, columns=y, values='counts')
    if order is not None:
        data = data[order]
    else:
        data = data[natsorted(data.columns)]
    data = data.fillna(0.0)
    data.plot.bar(
        stacked=stacked, legend=False, color=palette, ax=ax,
    )
    ax.tick_params(labelsize='small')
    ax.set_ylabel(ylabel)
    ax.grid(False)

def pl_prop_barplot_ci(
        adata,
        x,
        y,
        stats_folder=None,
        fig_folder=None,
        ci_p=.95,
        independent=False,
        precomputed=None,
    ):
    yvalues = list(adata.obs[y].unique())
    n_yvalues = len(yvalues)
    df = _pl_prop_barplot_ci_count(adata, x, y, ci_p, independent, stats_folder, precomputed=precomputed)
    df = _pl_prop_barplot_ci_pivot(df, x, y, yvalues, n_yvalues)
    data, yerr = _pl_prop_barplot_ci_split(df, x, y, n_yvalues)
    _pl_prop_barplot_ci_plot(data, yerr, n_yvalues, x, y, fig_folder)

def _pl_prop_barplot_ci_pivot(df, x, y, yvalues, n_yvalues):
    import pandas as pd
    df = df.pivot_table(index=[x], columns=[y], fill_value=0.0)
    err_low = df['mean'] - df['ci_low']
    err_high = df['ci_high'] - df['mean']
    df.columns = [
        '_'.join(
            [str(e) for e in reversed(col)]
        ).strip()
        for col in df.columns.values
    ]
    err = err_low.join(err_high, rsuffix='_elow', lsuffix='_ehigh')
    df = pd.concat([df, err], axis=1)
    df = df.loc[
        :, 
        [f'{e}_mean' for e in yvalues] + [f'{e}_{s}' for e in yvalues for s in ['elow', 'ehigh']]
    ]
    df.columns = [
        pd.Index(yvalues + flatten([[c,c] for c in yvalues])),
        pd.Index(['mean'] * n_yvalues + ['elow', 'ehigh'] * n_yvalues),
    ]
    order = df.sort_values(by=df.columns[0], ascending=False).index
    df.index = df.index.astype('category')
    df.index = df.index.reorder_categories(order)
    return df

def _pl_prop_barplot_ci_count(adata, x, y, ci_p, independent=False,stats_folder=None, precomputed=None):
    import os
    import pandas as pd
    from statsmodels.stats.proportion import proportion_confint, multinomial_proportions_confint
    count = adata.obs.groupby(y)[x].value_counts().to_frame()
    count.columns = ['count']
    if precomputed is None and not independent:
        count = _pl_prop_barplot_ci_count_collapse(count, x, y)
    nobs = adata.obs[y].value_counts().to_frame()
    nobs.columns = ['count']
    nobs.index.name = y
    count = count.join(nobs, rsuffix='_total')
    means = (count['count'] / count['count_total']).to_frame()
    means.columns = ['mean']
    if precomputed is None:
        if independent:
            ci = pd.DataFrame(
                proportion_confint(
                    count['count'],
                    count['count_total'],
                    alpha=1-ci_p,
                ),
                index=['ci_low', 'ci_high'],
            ).T
        else:
            ci = None
            count = count.reset_index()
            for yy in count[y].unique():
                count_l = count[count[y] == yy]
                ci_l = pd.DataFrame(
                    multinomial_proportions_confint(
                        count_l['count'],
                        alpha=1-ci_p,
                    ),
                    index=count_l.index,
                    columns=['ci_low', 'ci_high'],
                )
                ci_l = pd.concat([
                    count_l[[y, x]], ci_l,
                ], axis=1)
                ci = pd.concat([ci, ci_l])
            ci = ci.set_index([y, x])
        df = pd.concat([means, ci], axis=1)
    else:
        df = precomputed
    if stats_folder:
        fname = f'bar.{x}.{y}'
        df.reorder_levels([x, y]).sort_index(level=[x]).to_csv(
            os.path.join(stats_folder, f'{fname}.csv')
        )
    return df

def _pl_prop_barplot_ci_count_collapse(count, x, y):
    import pandas as pd
    count = count.reset_index()
    min_counts = 5
    min_satisfied = False
    while not min_satisfied:
        collapse_ix = count.loc[
            count['count'] < min_counts
        ].reset_index()[x].unique()
        others = count[
            count[x].isin(collapse_ix)
        ].groupby(y)['count'].sum().to_frame()
        if others['count'].min() >= 5:
            min_satisfied = True
        else:
            min_counts += 1
    print(f'Grouping together groups with min_counts {min_counts}')
    others[x] = 'Others'
    others = others.set_index(x, append=True)
    count_collapsed = pd.concat([
        count[~count[x].isin(collapse_ix)],
        others.reset_index(),
    ]).set_index([y, x])['count'].to_frame().sort_index(level=0)
    return count_collapsed

def _pl_prop_barplot_ci_split(df, x, y, n_yvalues):
    data = df.iloc[:, :n_yvalues]
    yerr = df.iloc[:, n_yvalues:]
    yerr = yerr.stack().stack()
    yerr.index.set_names([x, 'ci_err', y], inplace=True)
    yerr = yerr.reorder_levels([y, 'ci_err', x])
    yerr = yerr.to_frame()
    yerr = yerr.sort_index(
        level=[y, 'ci_err', x],
        ascending=[True, False, True],
    )
    yerr = yerr.values.reshape((
        len(yerr.index.levels[0]),
        2,
        len(yerr.index.levels[2]),
    ))
    return data, yerr

def _pl_prop_barplot_ci_plot(data, yerr, n_yvalues, x, y, fig_folder=None):
    import matplotlib.pyplot as plt
    import os
    ax = data.sort_index().plot.bar(
        grid=False,
        figsize=(5*n_yvalues,5),
        width=0.9,
        yerr=yerr,
        capsize=2,
    )
    handles, labels = ax.get_legend_handles_labels()
    # labels = [l.strip('()').replace(',', '') for l in labels]
    labels = [l.strip('()').split(',')[0] for l in labels]
    ax.legend(handles, labels)
    ax.set_ylim(0, ax.get_ylim()[1])
    ax.set_ylabel(f'% in {y}')
    fname = f'bar.{x}.{y}'
    if fig_folder:
        plt.savefig(
            os.path.join(fig_folder, f'{fname}.pdf'),
            bbox_inches='tight',
        )

def plot_silhouette(
        adata, 
        n_comps,
        fname,
        algs,
        res_array,
        rep='X_pca',
        subres='',
    ):
    # NOTE Please check silhouette score first argument
    import matplotlib.pyplot as plt
    from sklearn.metrics import silhouette_score
    fig = plt.figure(dpi=150, figsize=(10,5))
    for a in algs:
        sil_res = [
            r for r in res_array
            if adata.obs[f'{a}_{subres}{r}'].unique().shape[0] > 1
        ]
        sil = [
            silhouette_score(
                adata.obsm[rep][:,:n_comps],
                adata.obs[f'{a}_{subres}{r}']
            ) for r in sil_res 
        ]
        ks = [
            adata.obs[f'{a}_{subres}{r}'].astype(int).max() + 1 for r in sil_res
        ]
        plt.plot(sil_res, sil, label=f'{a}')
        for r, s, k in zip(sil_res, sil, ks):
            plt.text(r, s*1.01, k, fontdict={'fontsize': 6})
    plt.legend()
    fig.savefig(fname, bbox_inches='tight')

def contour_density(
        adata, basis='umap', groupby=None, fname=None, kde=False,
        color=None, colormap=None, lw=.8, contour_color='k',
        min_level=.25, alpha=.5, vmin=None, vmax=None,
    ):
    import matplotlib.pyplot as plt
    import numpy as np
    import seaborn as sns
    if groupby:
        cat = adata.obs[groupby].cat.categories
        n = len(cat)
    else:
        cat = ''
        n = 1
    fig, axs = plt.subplots(nrows=1, ncols=n, figsize=(n*5,6))
    emb = f'X_{basis}'
    axlabel = basis.upper()
    for i, c in enumerate(cat):
        if n > 1:
            cells = adata.obs[groupby].isin([c])
            k = f'{basis}_density_{groupby}'
        else:
            cells = adata.obs_names
            k = f'{basis}_density'
        if kde:
            sns.kdeplot(
                adata.obsm[emb][cells, 0],
                adata.obsm[emb][cells, 1],
                ax=axs[i], cmap='viridis', shade=True,
                shade_lowest=False, cbar=True,
            )
        else:
            cl = axs[i].tricontour(
                adata.obsm[emb][cells, 0],
                adata.obsm[emb][cells, 1],
                adata.obs.loc[cells, k],
                colors=contour_color,
                linewidths=lw,
                levels=np.linspace(min_level,1,10),
            )
            axs[i].clabel(cl, fontsize=4, inline=1)
        axs[i].set_title(c)
        axs[i].set_xlabel(f'{axlabel}1')
        axs[i].set_ylabel(f'{axlabel}2')
        axs[i].xaxis.set_ticklabels('')
        axs[i].yaxis.set_ticklabels('')
        axs[i].grid(False)
        if color is None:
            c = 'lightgrey'
        else:
            c = adata.obs.loc[cells, color].values
        plot = axs[i].scatter(
            adata.obsm[emb][cells, 0],
            adata.obsm[emb][cells, 1],
            c=c, s=1, alpha=alpha, cmap=colormap,
            vmin=vmin, vmax=vmax,
        )
        plt.colorbar(plot, orientation='horizontal', ax=axs[i])
    if fname:
        plt.savefig(fname, bbox_inches='tight')
    else:
        return fig

# %%
