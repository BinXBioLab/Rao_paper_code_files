#%%
# Load modules
#from gprofiler import GProfiler
import matplotlib.pyplot as plt
from natsort import natsorted
import os
import numpy as np
import pandas as pd
import seaborn as sns
import sys
from typing import Dict, List

# Module available at https://github.com/fbrundu/pybatch-mast
from pybatch_mast import BatchMAST

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Not used, custom functions added to code
# os.chdir('../..')
# sys.path.append(os.path.abspath('..'))
# from fbrundu_sclib import *

#%%
# Define samples
samples = ['AGGR01_mapped',]
prefix = samples[0]
prefix

''' #%%
# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath '''
''' 
data_dir = os.path.join('data')
data = fullpath_closure(data_dir)  '''
out_dir = ("E:/Sneha/RNAseq/scSEq/AGGR01_mapped/fig_supp")
out = out_dir

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, figsize=(7,7))
sc.settings.figdir = out('fig_supp')

#%%
# Load main AnnData
adata = sc.read('E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad')
adata

#%%
# Recompute neighbors and UMAP
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)
sc.pl.umap(adata)

#%%
# Plot QC metrics UMAP before filtering outliers
sc.pl.umap(
    adata,
    color=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    save=f'.qc.preoutliers.pdf',
)

#%%
# Define resolution parameter range
res_array = list(np.linspace(.01, .09, 9)) + list(np.linspace(.1, 1, 10))
res_array = [round(r, 2) for r in res_array]
res_array

#%%
# Compute leiden clustering for each resolution value
for res in res_array:
    sc.tl.leiden(adata, resolution=res, key_added=f'leiden_{res}')

#%%
# Update main AnnData
adata.write(out(f'{prefix}.final.h5ad'))

#%%
# Plot leiden clustering UMAPs
sc.pl.umap(
    adata,
    color=[f'leiden_{r}' for r in res_array],
    save=f'.leiden.preoutliers.pdf',
    legend_loc='on data',
    ncols=6,
)

#%%
def plot_silhouette(
    adata: sc.AnnData, 
    n_comps: int,
    fname: str,
    algs: List[str],
    res_array: List[float],
    rep: str = 'X_pca',
    subres: str = '',
):
    # NOTE Please check silhouette score first argument
    import matplotlib.pyplot as plt
    from sklearn.metrics import silhouette_score
    fig = plt.figure(dpi=150, figsize=(10,5))
    for a in algs:
        sil_res = [
            r for r in res_array
            if adata.obs[f'{a}_{subres}{r}'].unique().shape[0] > 1
        ]
        sil = [
            silhouette_score(
                adata.obsm[rep][:,:n_comps],
                adata.obs[f'{a}_{subres}{r}']
            ) for r in sil_res 
        ]
        ks = [
            adata.obs[f'{a}_{subres}{r}'].astype(int).max() + 1 for r in sil_res
        ]
        plt.plot(sil_res, sil, label=f'{a}')
        for r, s, k in zip(sil_res, sil, ks):
            plt.text(r, s*1.01, k, fontdict={'fontsize': 6})
    plt.legend()
    fig.savefig(fname, bbox_inches='tight')

# Compute Silhouette score for different leiden clusterings
plot_silhouette(
    adata,
    n_comps=adata.obsm['X_liger_H'].shape[1],
    fname=out(f'fig_supp/leiden/silhouette_score.preoutliers.pdf'),
    rep='X_liger_H',
    algs=['leiden'],
    res_array=res_array,
)

#%%
# Define selected resolution value
res_prefix = {
    'AGGR01_mapped': 0.3,
}
res = res_prefix[prefix]
prefix, res

#%%
# Load AnnData snapshot from disk (useful if starting from here)
adata = sc.read(out(f'{prefix}.final.h5ad'))

#%%
# Plot clustering with selected resolution through UMAP
sc.pl.umap(
    adata,
    color=[f'leiden_{res}'],
    save='.leiden.selected.preoutliers.pdf',
    legend_loc='on data',
)

#%%
# Print clustering quantification
adata.obs[f'leiden_{res}'].value_counts()

#%%
# Update main AnnData on disk
adata.write(out(f'{prefix}.final.h5ad'))

#%%
# Plot distribution of QC metrics before filtering
sc.pl.violin(
    adata,
    keys=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
    ],
    groupby=f'leiden_{res}',
    save=f'.qc.leiden_{res}.preoutliers.pdf',
    cut=0,
)

#%%
# Define stably expressed genes (housekeeping-like genes for scRNA-Seq)
# https://academic.oup.com/gigascience/article/8/9/giz106/5570567
# http://shiny.maths.usyd.edu.au/SEGs/
# SEG index > .9, Lambda < .1, Sigma < .1, Omega <.1, F < .4
segs = list(set('SNRPD3 PFN1 SRRM1 HNRNPA2B1 YWHAB RPL36 GDI2 NCL RPL8 CSDE1 C14ORF2 ARF1 TARDBP STOML2 RPS5 SRSF3 CKS1B COX6A1 RPL15 RPS19 NPM1 EIF3I DHX9 ETF1 C9ORF78 RSL1D1 ZC3H15 YWHAE MAPRE1 RPS20 COX5B RPS6 NASP RHOA CSNK2B MRPL20 SF3A3 EEF1B2 DDX18 RPL7A WDR43 NACA RPS25 SF3B5 PTMA EIF3L CHCHD2 SNRPG SRSF10.UID_1003 RBM17 SZRD1 RPS24 RPL10A EBNA1BP2 SF3B1 RPS13 NACA2 FAM96B RBMX PLEKHB2 RPL18A SARNP RPS14P3 NDUFA6 DAP3 DRG1 SRP14 POP7 NUDC LRRC75A.AS1 NOP58 SNRPE UBA52 RPLP0 OTUB1 PRPF40A SNHG16 NOP56 RPL35 RPL26 EIF3G IK CYCS SUMO1 STAU1 RPS7 RPL6 SEC61B DENR STIP1 MRPL57 DNAJC8 NOLC1 TMA7'.split()) & set(adata.raw.var_names))
segs

#%%
# Plot expression of SEGs, in different clusters or batches
sc.pl.dotplot(
    adata,
    var_names=segs,
    groupby=f'leiden_{res}',
    color_map='viridis',
    save=f'.segs.leiden_{res}.preoutliers.pdf',
    use_raw=True,
)
sc.pl.dotplot(
    adata,
    var_names=segs,
    groupby='batch',
    color_map='viridis',
    save=f'.segs.batch.preoutliers.pdf',
    use_raw=True,
)

#%%
# Initialize MAST on AWS batch
# - job queue on AWS batch that will receive job
job_queue = 'x1e-xlarge-4vCPU-120GB'
# - name of the job definition
job_def = 'fb2505-mast'
# - temporary S3 bucket for input/output with job
bucket = 'fb2505-devnull'
# - layer of AnnData containing counts matrix to use
layer = 'counts'
# Initialize MAST
bmast = BatchMAST(
    job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
)

#%%
# The code in the next lines will compute differentially expressed
# genes with MAST for the leiden clusters with fewer than 100 cells
# - define a new label, starting from original clustering
key = f'leiden_{res}_outliers'
adata.obs[key] = adata.obs[f'leiden_{res}'].astype(str)

#%%
# - get number of cells for each cluster
n_cells = adata.obs[f'leiden_{res}'].value_counts()
n_cells

#%%
# - define cluster of interest the ones with fewer than 100 cells
clusters = n_cells[n_cells < 100].index.tolist()
clusters

#%%
# - bigger clusters are instead pooled into a single cluster label `OTHER`
adata.obs.loc[~adata.obs[f'leiden_{res}'].isin(clusters), key] = 'OTHER'
adata.obs[key] = pd.Categorical(adata.obs[key])
adata.obs[key]

#%%
# - print number of cells for each cluster
adata.obs[key].value_counts()

#%%
# - subsample `OTHER` cluster for speed, take only max 200 cells from
#   each original cluster pooled in `OTHER`
n = 200
cells = adata.obs.groupby(f'leiden_{res}').apply(
    lambda x: x.sample(n) if len(x) >= n else x
).index.levels[1]
adata_o = adata[cells].copy()
# - Filter out genes that are not expressed anymore in the dataset
sc.pp.filter_genes(adata_o, min_cells=1)
adata_o

#%%
# - Get updated number of cells for each cluster
n_cells = adata_o.obs[key].value_counts()
n_cells

#%%
# - keep only genes expressed in at least 30 cells
min_genes = 30
min_perc = min_genes/min(n_cells)
jobs = 1
min_perc, jobs

#%%
# - Define covariate to keep for each cell
keys = [
    'n_genes', 'batch', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', key,
    'myo_perc_legacy',
]
# - We test the label in variable `key`
group = key
# - When filtering for DEGs we consider FDR < 0.05 and LFC > 1
fdr = .05
lfc = 1
# - Define all additional covariates (group and n_genes are always used)
covs_l = ['+pair+percent_mito+percent_ribo_p',]
# - Compute DEGs and save results to Excel file
print(f'Using {jobs} jobs')
for covs in covs_l:
    for de, top, by in bmast.mast(
        adata_o, keys, group, fdr, lfc, covs,
        min_perc=min_perc, on_total=False, jobs=jobs,
    ):
        fname = out(f'interim_data/leiden/mast/de.{group}{covs}') 
        bmast.mast_to_excel(de, fname, top=top)

#%%
def profile_disambiguate(
    org: str,
    query_genes: List[str],
    ordered: bool,
    no_iea: bool,
    base_url: str = None,
    **kwargs,
) -> pd.DataFrame:
    """ Running enrichment with gProfiler with automatic resolution
        of ambiguous annotations.
    """
    from gprofiler import GProfiler
    gp = GProfiler(
        base_url=base_url,
        return_dataframe=True,
    )
    print('> Pre-profiling...')
    pre = gp.profile(
        organism=org, query=query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )
    meta = gp.meta['genes_metadata']
    print(
        f'  Failed: {len(meta["failed"])},'
        f' Ambiguous: {len(meta["ambiguous"])}'
    )
    print('  ', ' '.join(meta['ambiguous'].keys()))
    best = {
        gene: max(
            meta['ambiguous'][gene],
            key=lambda x: x['number_of_go_annotations']
        )['gene_id']
        for gene in meta['ambiguous'].keys()
    }
    print(f'  Disambiguated: {len(best)}')
    final_query_genes = [
        gene if gene not in best else best[gene]
        for gene in query_genes
    ]
    print(f'  Final profiling...')
    final = gp.profile(
        organism=org, query=final_query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )   
    # Fewer ambiguous genes now
    meta = gp.meta['genes_metadata']
    try:
        assert len(meta['ambiguous']) == 0
    except AssertionError:
        print('  Some genes have still ambiguous annotation')
    return final

# Compute enrichment on DEGs results
base_url = 'https://biit.cs.ut.ee/gprofiler_archive3/e98_eg45_p14/'
result = {}
for c in top:
    genes = top[c]
    if len(genes) > 0:
        result[c] = profile_disambiguate(
            base_url=base_url, org='hsapiens', query_genes=genes,
            ordered=False, no_iea=True, no_evidences=False, user_threshold=.05,
            significance_threshold_method='fdr',
        )

def tl_gprof_excel(
    phenos: Dict[str, pd.DataFrame],
    fname: str,
):
    """ Save gProfiler results to Excel. """
    import pandas as pd
    writer = pd.ExcelWriter(
        f'{fname}.xlsx', engine='xlsxwriter'
    )
    for s, data in phenos.items():
        data.to_excel(writer, sheet_name=s, index=False)
    writer.save()

# Save gProfiler results to Excel
result = {k: v for k, v in result.items()}
if len(result) > 0: 
    fname = out(
        f'interim_data/leiden/mast/enrichment/'
        f'gprof.de.{group}{covs}'
    ) 
    tl_gprof_excel(result, fname)

#%%
# NOTE fine resolution enrichment results
# 19 - ER stress, UPR, Apoptosis
# 20 - Cell cycle, Execution of Apoptosis
# 21 - Cilium Assembly, probably Ependymal cells, only 31 cells - excluded at this time
# 22-end - Fewer than 30 cells

#%%
# Save AnnData snapshot before filtering of small groups
adata.write(out(f'interim_data/leiden/data.prefilter.h5ad'))
# Filter out small groups
adata = adata[
    ~adata.obs[f'leiden_{res}'].isin([str(i) for i in range(19, 28)])
].copy()

#%%
# Recompute neighbors and UMAP
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)

#%%
# Plot cell type annotation
key = 'nowakowski.fine.noglyc_unmapped'
sc.pl.umap(adata, color=key)

#%%
# Print cell type counts
adata.obs[key].value_counts()

#%%
# Plot neural markers before filtering for cell types with low counts
nmarkers = natsorted(list(set([
    'SLC17A7', 'SLC17A6', 'GAD1', 'GAD2', 'EOMES', 'DCX', 'SYN1', 'VIM',
    'OLIG1', 'OLIG2', 'GFAP', 'P2RY12', 'CLDN5', 'SOX2', 'SOX9', 'DLX1',
    'DLX5', 'NEUROD1', 'NEUROG1', 'NEUROG2', 'HEXB', 'C1QA', 'C1QB', 'C1QC',
    'TREM2', 'TYROBP', 'CX3CR1', 'TMEM119',
]) & set(adata.raw.var_names)))
sc.pl.dotplot(
    adata,
    var_names=nmarkers,
    color_map='viridis',
    use_raw=True,
    save=f'.neural_markers.prefilter.{key}.pdf',
    groupby=f'{key}',
    mean_only_expressed=True,
    dendrogram=True,
)

#%%
# NOTE Removing cell types with fewer than 30 cells and Microglia which don't 
# seem to express many Microglial markers (possibly spurious annotation)
adata = adata[~adata.obs[key].isin([
    'Microglia', 'Endothelial', 'Mural', 'OPC',
])].copy()

#%%
# Recompute neighbors and UMAP
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)
sc.pl.umap(adata, color=key)

#%%
# Save snapshot after filtering
adata.write(out(f'{prefix}.final.h5ad'))

#%%
# Plot neural markers after filtering
nmarkers = natsorted(list(set([
    'SLC17A7', 'SLC17A6', 'GAD1', 'GAD2', 'EOMES', 'DCX', 'SYN1', 'VIM',
    'OLIG1', 'OLIG2', 'GFAP', 'P2RY12', 'CLDN5', 'SOX2', 'SOX9', 'DLX1',
    'DLX5', 'NEUROD1', 'NEUROD2', 'NEUROG1', 'NEUROG2', 'HEXB', 'C1QA', 'C1QB',
    'C1QC', 'TREM2', 'TYROBP', 'CX3CR1', 'TMEM119',
]) & set(adata.raw.var_names)))
sc.pl.umap(
    adata,
    color=nmarkers,
    cmap='viridis',
    save='.neural_markers.pdf',
)
sc.tl.dendrogram(adata, key)
sc.pl.dotplot(
    adata,
    var_names=nmarkers,
    color_map='viridis',
    use_raw=True,
    save=f'.neural_markers.{key}.pdf',
    groupby=f'{key}',
    mean_only_expressed=True,
    dendrogram=True,
)

# %%
# NOTE defining deletion genes
# DGCR14 replaced with ESS2
# UFD1L replaced with UFD1
# C22orf29 replaced with RTL10
# SEPT5 replaced with SEPTIN5
# LRRC748 corrected with LRRC74B
# LOC101927859 not found
# mir-1286, mir-6816, mir-649, mir-185 in introns
# mir-1306 and mir-3618 are embedded in DGCR8
# mir-4761 in exon and intron of COMT
# Mature miRNA lack polyA tail and are not capture by 10x
del_genes = 'DGCR6 PRODH DGCR2 ESS2 TSSK2 GSC2 SLC25A1 CLTCL1 HIRA MRPL40 C22orf39 UFD1 CDC45 CLDN5 SEPTIN5 GP1BB TBX1 COMT GNB1L RTL10 TXNRD2 DGCR8 TRMT2A mir-4761 mir-1286 ARVCF USP41 TANGO2 LOC101927859 RTN4R DGCR6L mir-185 mir-6816 RANBP1 ZDHHC8 CCDC188 LINC00896 mir-1306 mir-3618 ZNF74 SCARF2 KLHL22 MED15 SERPIND1 PI4KA SNAP29 CRKL AIFM3 LZTR1 THAP7 P2RX6 SLC7A4 mir-649 LRRC74B HIC2'.split()

#%%
# Check which genes are missing in our data
not_found = list(set(del_genes) - set(adata.raw.var_names))

#%%
# Remove missing genes keeping the original order
del_genes = [g for g in del_genes if g in adata.raw.var_names]

#%%
# Print missing genes
not_found

# %%
# Plot deletion genes by genotype, batch, leiden clustering and
# cell type annotation
sc.pl.dotplot(
    adata,
    var_names=del_genes,
    color_map='viridis',
    use_raw=True,
    save='.22q11.del_genes.genotype.pdf',
    groupby='genotype',
    mean_only_expressed=True,
)
sc.pl.dotplot(
    adata,
    var_names=del_genes,
    color_map='viridis',
    use_raw=True,
    save='.22q11.del_genes.batch.pdf',
    groupby='batch',
    mean_only_expressed=True,
)
sc.pl.dotplot(
    adata,
    var_names=del_genes,
    color_map='viridis',
    use_raw=True,
    save=f'.22q11.del_genes.leiden_{res}.pdf',
    groupby=f'leiden_{res}',
    mean_only_expressed=True,
)
sc.pl.dotplot(
    adata,
    var_names=del_genes,
    color_map='viridis',
    use_raw=True,
    save=f'.22q11.del_genes.{key}.pdf',
    groupby=f'{key}',
    mean_only_expressed=True,
)

#%%
# NOTE hallmark genesets (from MSigDB) plots
sc.pl.umap(
    adata,
    color=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    cmap='viridis',
    save='.hallmarks.pdf',
    ncols=5,
)
# By batch
sc.pl.violin(
    adata,
    keys=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    groupby='batch',
    save='.hallmarks.batch.pdf',
    rotation=90,
    cut=0,
)
# By genotype
sc.pl.violin(
    adata,
    keys=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    groupby='genotype',
    save='.hallmarks.genotype.pdf',
    cut=0,
)
# By timepoint
sc.pl.violin(
    adata,
    keys=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    groupby='timepoint',
    save='.hallmarks.timepoint.pdf',
    cut=0,
)
# By leiden clustering
sc.pl.violin(
    adata,
    keys=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    groupby=f'leiden_{res}',
    save=f'.hallmarks.leiden_{res}.pdf',
    rotation=90,
    cut=0,
)
# By cell type annotation
sc.pl.violin(
    adata,
    keys=[
        'hallmark_apoptosis',
        'hallmark_glycolysis',
        'hallmark_hypoxia',
        'hallmark_mitotic_spindle',
        'hallmark_unfolded_protein_response',
    ],
    groupby=key,
    save=f'.hallmarks.{key}.pdf',
    rotation=90,
    cut=0,
)

#%%
# NOTE In the original code this is the section where
# contour plots are drawn. Due to the fact that we might
# use barplots instead, to show differences in cell type
# contributions, I decided to leave contour plots out in this version.
# However, they are present in the master file and we
# can retrieve them if necessary.

#%% Plot cell type annotation
key = 'nowakowski.fine.noglyc_unmapped'
sc.pl.umap(
    adata,
    color=[key],
    cmap='viridis',
    ncols=1,
    save='.annotation.unmapped.pdf',
)

#%%
# Compute cell type contributions per timepoint
contrib = pd.concat([
    adata.obs.loc[
        adata.obs['timepoint'] == tp, :
    ].groupby('genotype')[key].value_counts(
        normalize=norm
    ).round(3)
    for tp in ['70d', '150d']
    for norm in [False, True]
], axis=1).fillna(0)
contrib.columns = [
    f'{tp}_{n}' for tp in ['70d', '150d'] for n in ['counts', 'perc']
]
contrib = contrib.convert_dtypes()
contrib.to_csv(out(f'interim_data/singler/contribution.{key}.csv'))
contrib

#%%
# Plot UMAP annotation by timepoint
cols = [key]
fig, axs = plt.subplots(2, len(cols), figsize=(len(cols)*5, 2*5), squeeze=False)
for i, t in enumerate(['70d', '150d']):
    adata_s = adata[adata.obs['timepoint'] == t].copy()
    for j, c in enumerate(cols):
        adata.obs[c] = adata.obs[c].cat.remove_unused_categories()
        sc.pl.umap(
            adata_s,
            color=c,
            cmap='viridis',
            show=False,
            ax=axs[i, j],
            legend_fontsize=7,
        )
plt.subplots_adjust(wspace=0.6, hspace=0.5)
fig.savefig(
    out(f'fig_supp/singler/umap.{key}.timepoint.pdf'),
    bbox_inches='tight',
)

#%%
# Save AnnData snapshot to disk
adata.write(out(f'{prefix}.final.h5ad'))

# %%
# On the filtered dataset, recompute silhouette score on
# remaining cells grouped into clusters, to find the final
# clustering to keep
res_array = list(np.linspace(.01, .09, 9)) + list(np.linspace(.1, 1, 10))
res_array = [round(r, 2) for r in res_array]
res_array

#%%
# Compute and plot average silhouette score for each clustering
plot_silhouette(
    adata,
    n_comps=adata.obsm['X_liger_H'].shape[1],
    fname=out(f'fig_supp/leiden/silhouette_score.pdf'),
    rep='X_liger_H',
    algs=['leiden'],
    res_array=res_array,
)

#%%
# Define final resolution
res_prefix = {
    'AGGR01_mapped': 0.05,
}
res = res_prefix[prefix]
prefix, res

#%%
key = 'leiden_final'

#%%
# Subset cluster 6 for final resolution
sc.tl.leiden(
    adata,
    resolution=0.1,
    key_added=key,
    restrict_to=(f'leiden_{res}', ['6']),
    random_state=42,
)

#%%
# Replace comma with hyphen in cluster name
adata.obs[key].cat.rename_categories({
    k: k.replace(',', '-')
    for k in adata.obs[key].cat.categories
}, inplace=True)

#%%
# Plot final resolution UMAP
sc.pl.umap(
    adata,
    color=[f'leiden_{res}', key],
    save='.leiden.selected.pdf',
    legend_loc='on data',
)

#%%
# Get number of cells for each cluster
n_cells = adata.obs[key].value_counts()
n_cells

#%%
# For performance reason, remove genes expressed in fewer
# than 5 cells
sc.pp.filter_genes(adata, min_cells=5)

#%%
# Set parameters for MAST on AWS batch
job_queue = 'x1e-xlarge-4vCPU-120GB'
job_def = 'fb2505-mast'
bucket = 'fb2505-devnull'
layer = 'counts'
bmast = BatchMAST(
    job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
)

#%%
# NOTE test only genes expressed in at least 30 cells (for each cell type)
min_genes = 30
min_perc = min_genes/min(n_cells)
jobs = 1
min_perc, jobs

#%%
# Compute DEGs with MAST
keys = [
    'n_genes', 'batch', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', key,
    'myo_perc_legacy',
]
group = key
fdr = .05
lfc = 1
covs_l = ['+pair+percent_mito+percent_ribo_p',]
print(f'Using {jobs} jobs')
for covs in covs_l:
    for de, top, by in bmast.mast(
        adata, keys, group, fdr, lfc, covs,
        min_perc=min_perc, on_total=False, jobs=jobs,
    ):
        fname = out(f'interim_data/leiden/mast/de.{group}{covs}') 
        bmast.mast_to_excel(de, fname, top=top)

#%%
# Update data snapshot on disk
adata.write(out(f'{prefix}.final.h5ad'))

#%%
# Compute enrichment on DEGs across clusters
base_url = 'https://biit.cs.ut.ee/gprofiler_archive3/e98_eg45_p14/'
result = {}
for c in top:
    genes = top[c]
    if len(genes) > 0:
        result[c] = profile_disambiguate(
            base_url=base_url, org='hsapiens', query_genes=genes,
            ordered=False, no_iea=True, no_evidences=False, user_threshold=.05,
            significance_threshold_method='fdr',
        )
result = {k: v for k, v in result.items()}
if len(result) > 0: 
    fname = out(
        f'interim_data/leiden/mast/enrichment/'
        f'gprof.de.{group}{covs}'
    ) 
    tl_gprof_excel(result, fname)

#%%
# Plot final UMAP of QC
sc.pl.umap(
    adata,
    color=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    save=f'.qc.postoutliers.pdf',
)

#%%
# Stably expressed genes (housekeeping-like genes for scRNA-Seq)
# https://academic.oup.com/gigascience/article/8/9/giz106/5570567
# http://shiny.maths.usyd.edu.au/SEGs/
# SEG index > .9, Lambda < .1, Sigma < .1, Omega <.1, F < .4
segs = natsorted(list(set('SNRPD3 PFN1 SRRM1 HNRNPA2B1 YWHAB RPL36 GDI2 NCL RPL8 CSDE1 C14ORF2 ARF1 TARDBP STOML2 RPS5 SRSF3 CKS1B COX6A1 RPL15 RPS19 NPM1 EIF3I DHX9 ETF1 C9ORF78 RSL1D1 ZC3H15 YWHAE MAPRE1 RPS20 COX5B RPS6 NASP RHOA CSNK2B MRPL20 SF3A3 EEF1B2 DDX18 RPL7A WDR43 NACA RPS25 SF3B5 PTMA EIF3L CHCHD2 SNRPG SRSF10.UID_1003 RBM17 SZRD1 RPS24 RPL10A EBNA1BP2 SF3B1 RPS13 NACA2 FAM96B RBMX PLEKHB2 RPL18A SARNP RPS14P3 NDUFA6 DAP3 DRG1 SRP14 POP7 NUDC LRRC75A.AS1 NOP58 SNRPE UBA52 RPLP0 OTUB1 PRPF40A SNHG16 NOP56 RPL35 RPL26 EIF3G IK CYCS SUMO1 STAU1 RPS7 RPL6 SEC61B DENR STIP1 MRPL57 DNAJC8 NOLC1 TMA7'.split()) & set(adata.raw.var_names)))
segs

#%%
# Plot SEGs expression on different final leiden clusters
sc.pl.dotplot(
    adata,
    var_names=segs,
    groupby='leiden_final',
    color_map='viridis',
    save=f'.segs.leiden_final.postoutliers.pdf',
    use_raw=True,
)

#%%
# Read snapshot from disk
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Remove genes expressed in fewer than 5 cells
sc.pp.filter_genes(adata, min_cells=5)

#%%
# Optional: save files for external tools
# adata.X = adata.layers['counts']
# adata.to_df().reset_index().to_feather(
    # out(f'interim_data/counts/{prefix}.counts.fth')
# )
# adata.obs.to_csv(
    # out(f'interim_data/counts/{prefix}.obs.csv')
# )
# adata.var.to_csv(
    # out(f'interim_data/counts/{prefix}.var.csv')
# )
