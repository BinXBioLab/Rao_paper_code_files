

#%%
# from google.colab import drive 
# drive.mount('/content/drive') 
#!pip3 install scvelo 
#!pip install scvelo 
import sys 
import os 
import pandas as pd 
import scvelo as scv
from sympy import prefixes 
scv.set_figure_params() 
import numpy as np 
import matplotlib.pyplot as plt 
import matplotlib as mpl 
from scipy.sparse import issparse 
from scipy import sparse 
import anndata as an 
from matplotlib import rcParams 
import matplotlib.pyplot as pl 
import loompy
import scanpy as sc

#%%
# Specify figure output folder 
scv.settings.figdir = "E:/Sneha/RNAseq/Scseq/scVelo/figures"
final = scv.read("E:/Sneha/RNAseq/Scseq/scVelo/final_merged.loom", cache=True)
#finalcontrol = scv.read("/content/drive/MyDrive/RNA velocity/loompy/finalcontrol_merged.loom", cache=True)
#finalcase = scv.read("/content/drive/MyDrive/RNA velocity/loompy/finalcase_merged.loom", cache=True)



#%%
#read batch corrected scVELo matrices
#
#spliced_liger = sc.read_csv("E:/Sneha/RNAseq/Scseq/scVelo/old/spliced.liger.mat.csv")
#unspliced_liger =  sc.read_csv("E:/Sneha/RNAseq/Scseq/scVelo/old/unspliced.liger.mat.csv")


#%%

spliced_H = pd.read_csv("E:/Sneha/RNAseq/Scseq/scVelo/spliced.liger.usage_norm.csv", index_col="Unnamed: 0")
spliced_H.columns = range(1, 45+1)
spliced_W = pd.read_csv ("E:/Sneha/RNAseq/Scseq/scVelo/spliced.liger.weights_shared.csv", index_col="Unnamed: 0")
spliced_liger =spliced_H.dot(spliced_W)
spliced_liger= spliced_liger.astype(int)
spliced_liger

#%%
unspliced_H = pd.read_csv("E:/Sneha/RNAseq/Scseq/scVelo/unspliced.liger.usage_norm.csv", index_col="Unnamed: 0")
unspliced_H.columns = range(1, 45+1)
unspliced_W = pd.read_csv ("E:/Sneha/RNAseq/Scseq/scVelo/unspliced.liger.weights_shared.csv", index_col="Unnamed: 0")
unspliced_liger =unspliced_H.dot(unspliced_W)
unspliced_liger= unspliced_liger.astype(int)
unspliced_liger

#%%
#spliced_liger = spliced_liger.rename (columns = {"Unnamed: 0" : "CellID" })
#unspliced_liger = unspliced_liger.rename (columns = {"Unnamed: 0" : "CellID" })
#print (spliced_liger.obs)
#print (unspliced_liger.obs)


#%%
# add normalized splcied and unspliced counts to layers and rename raw counts
#merge =spliced_liger

#merge.layers['spliced']= spliced_liger.X
#merge.layers['unspliced'] = unspliced_liger.X

final.layers['spliced']=spliced_liger
final.layers['unspliced']=unspliced_liger
print ("done!")
#final.layers
#final_added = pd.concat [final.layers, spliced_liger]
#final_scvelo= final [spliced_liger]= spliced_liger, key= "CellID"
#final["empty_floats"] = "float32"
#final ["empty_floats"]="float32"

#%%
#merge = merge [:,merge.var.index.isin(final.var.index)]

#print ("obs filtered")
#print (merge)

#%%
#final = final [:, final.var.index.isin(merge.var.index)]
#final= final [final.obs.index.isin(merge.obs.index),:]
#%%
#merge = merge[merge.obs.index.isin(final.obs.index),:]

#merge.layers['matrix'] = final.layers['matrix']
#merge.layers['ambiguous'] = final.layers['ambiguous']


#%%
#merge.obs['batch'] = final.obs['batch']
#merge.obs['pair'] = final.obs['pair']
#merge.obs['genotype'] = final.obs['genotype']
#merge.obs['timepoint'] = final.obs['timepoint']
#merge.obs['sample_id'] = final.obs['sample_id']
#merge.obs['nowakowski.fine.noglyc_unmapped.aggr'] = final.obs['nowakowski.fine.noglyc_unmapped.aggr']
#merge.obs['leiden_final'] = final.obs['leiden_final']
#merge.uns ['nowakowski.fine.noglyc_unmapped.aggr_colors'] = final.uns ['nowakowski.fine.noglyc_unmapped.aggr_colors']
#merge.uns ['nowakowski.fine.noglyc_unmapped_colors'] = final.uns['nowakowski.fine.noglyc_unmapped_colors']
#%%
#subset 22q and cotnrol samples
finalcase = final [final.obs["genotype"]== "Case"]
print (finalcase.obs)
finalcontrol = final [final.obs["genotype"]== "Control"]
print (finalcontrol.obs)
print ("subsetting done")

#%%
# save loom files
finalcase.write_loom('E:/Sneha/RNAseq/Scseq/scVelo/finalcase.loom')
finalcontrol.write_loom('E:/Sneha/RNAseq/Scseq/scVelo/finalcontrol.loom')
final.write_loom('E:/Sneha/RNAseq/Scseq/scVelo/finalliger.loom')
print ("saved")


#%%  
# Read saved loom files
#final = scv.read("/content/drive/MyDrive/RNA velocity/loompy/finalliger.loom", cache=True)
#finalcontrol = scv.read("/content/drive/MyDrive/RNA velocity/loompy/finalcontrol.loom", cache=True)
finalcase = scv.read("E:/Sneha/RNAseq/Scseq/scVelo/finalcase.loom", cache=True)
finalcase = adata.read("E:/Sneha/RNAseq/Scseq/scVelo/finalcase.loom")

#%% Start here once files are ready
#process RNA velocity data by genotype
#for batch in final.obs['batch']: 
prefix = finalcase
#prefix = finalcontrol
scv.pp.filter_and_normalize(prefix,log=True)
scv.pp.moments(prefix)
scv.tl.umap(prefix)
scv.tl.velocity(prefix, mode='stochastic')
scv.tl.velocity_graph(prefix, n_jobs=28)

#finalcase.write_loom('E:/Sneha/RNAseq/Scseq/scVelo/finalcasevelo.loom')

#%%
#velocity plots
#for batch in final.obs['batch']:
scv.pl.velocity_embedding (prefix,legend_loc='right',title='velocity',palette='Paired', color = 'nowakowski.fine.noglyc_unmapped.aggr' )
scv.pl.velocity_embedding (prefix,legend_loc='right',title='velocity',palette='Paired', color = 'batch' )

#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.control.eps', format='eps')
plt.savefig('E:/Sneha/RNAseq/Scseq/scVelo/figures/veloplot.case.eps', format='eps')

#%%
#scv.pl.velocity_embedding_grid(final,legend_loc='right',title="control",palette='Paired', color = 'nowakowski.fine.noglyc_unmapped.aggr')  
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.grid.control.eps', format='eps')

scv.pl.velocity_embedding_grid(prefix,legend_loc='right',title="control",palette='Paired', color = 'nowakowski.fine.noglyc_unmapped.aggr')  
plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.grid.case.eps', format='eps')

#%%
#scv.pl.velocity_embedding_stream(final,legend_loc='right',alpha=0.3,title="control",palette='Paired', color = 'nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.control.eps', format='eps')

scv.pl.velocity_embedding_stream(prefix,legend_loc='right',alpha=0.3,title="control",palette='Paired', color = 'nowakowski.fine.noglyc_unmapped.aggr') 
plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.case.eps', format='eps')

#%%
#scv.pl.velocity_embedding_stream(final,legend_loc='right',color='SYN1',title="controlSYN1") 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.SYN1.control.eps', format='eps')

scv.pl.velocity_embedding_stream(prefix,legend_loc='right',color='SYN1',title="controlSYN1") 
plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.SYN1.case.eps', format='eps')

#%%
#scv.pl.proportions(final, groupby= "nowakowski.fine.noglyc_unmapped.aggr") 
#plt.savefig('/content/drive/MyDrive/RNA velocity/proportions.control.eps', format='eps')

scv.pl.proportions(prefixes, groupby= "nowakowski.fine.noglyc_unmapped.aggr") 
plt.savefig('/content/drive/MyDrive/RNA velocity/proportions.case.eps', format='eps')


#%%
#scv.pl.velocity_embedding_stream(final, basis='umap',palette='Paired', color= 'nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.ann.umap.control.eps', format='eps')

scv.pl.velocity_embedding_stream(final, basis='umap',palette='Paired', color= 'nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.stream.ann.umap.case.eps', format='eps')


#%%
#scv.pl.velocity_embedding(final,legend_loc='right', arrow_length=3,arrow_size=2, dpi=200, color='nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.embedding.control.eps', format='eps')

scv.pl.velocity_embedding(final,legend_loc='right', arrow_length=3,arrow_size=2, dpi=200, color='nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.embedding.case.eps', format='eps')

#%%
scv.pl.velocity(final,['RANBP1','DGCR8','TANGO2','COMT','DGCR6','MRPL40','SYN1','DCX','GAD2','EOMES','VIM'],ncols=2) 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.markers.control.eps', format='eps')
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.markers.case.eps', format='eps')

#%%
scv.pl.scatter(JS002, 'SYN1', color=['nowakowski.fine.noglyc_unmapped.aggr', 'velocity']) 

scv.tl.rank_velocity_genes(JS002, groupby='nowakowski.fine.noglyc_unmapped.aggr', min_corr=.3) 
#df = scv.DataFrame(JS002.uns['rank_velocity_genes']['names']) 
#df.head() 

#%%
scv.tl.score_genes_cell_cycle(final) 

#%%
scv.pl.velocity_graph(final, threshold=.1, color= 'nowakowski.fine.noglyc_unmapped.aggr') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.graph.control.eps', format='eps')
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.graph.case.eps', format='eps')

#%%

#plot Pseudotimes
scv.tl.velocity_pseudotime(final) 
scv.pl.scatter(final, color='velocity_pseudotime', cmap='gnuplot') 
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.pseudotime.control.eps', format='eps')
#plt.savefig('/content/drive/MyDrive/RNA velocity/veloplot.pseudotime.case.pdf', format='pdf')


#%%
#Running PAGA
!pip3 install python-igraph --upgrade --quiet 
final.uns['neighbors']['distances'] = final[0].obsp['distances'] final.uns['neighbors']['connectivities'] = final.obsp['connectivities'] 
scv.tl.paga(final, groups='nowakowski.fine.noglyc_unmapped.aggr') 
df = scv.get_df(final, 'paga/transitions_confidence', precision=2).T df.style.background_gradient(cmap='Blues').format('{:.2g}') 

#%%
scv.pl.paga(final, threshold=0.04, basis='umap', size=20, alpha=0.5, min_edge_width=2, node_size_scale=1.5) 

#%%
#Dynamics
scv.tl.recover_dynamics(final) 


#%%
scv.tl.velocity(final, mode='dynamical') 
scv.tl.velocity_graph(final)


#%%
df = final.var 
df = df[(df['fit_likelihood'] > .1) & df['velocity_genes'] == True] 
kwargs = dict(xscale='log', fontsize=16) 
with scv.GridSpec(ncols=3) as pl: 
pl.hist(df['fit_alpha'], xlabel='transcription rate', **kwargs) pl.hist(df['fit_beta'] * df['fit_scaling'], xlabel='splicing rate',xticks=[.1, .4, 1], **kwargs) 
pl.hist(df['fit_gamma'], xlabel='degradation rate', xticks=[.1, .4, 1],␣ !→**kwargs) 
scv.get_df(final, 'fit*', dropna=True).head() 

#%%
fit_alpha fit_beta ... fit_alignment_scaling fit_r2 Sox17 3.68e-02 1.43 ... 5.63 0.12 Rgs20 1.48e-02 0.06 ... 3.73 0.33 Cpa6 8.64e-03 0.28 ... 5.32 0.01 Slco5a1 2.10e-02 0.06 ... 5.86 0.21 Sbspon 3.62e+00 12.15 ... 1.26 0.79

#%%
scv.tl.latent_time(final) 
scv.pl.scatter(final, color='latent_time', color_map='gnuplot', size=80) 

#%%
: top_genes = final.var['fit_likelihood'].sort_values(ascending=False). !→index[:300] 
scv.pl.heatmap(final, var_names=top_genes, sortby='latent_time',col_color='clusters', n_convolve=100) 

#%%
top_genes = final.var['fit_likelihood'].sort_values(ascending=False). !→index 
scv.pl.scatter(final, basis=top_genes[:15], ncols=5, frameon=False) 

#%%
var_names = ['SYN1','VIM','EOMES','DCX'] scv.pl.scatter(final, var_names, frameon=False) 
scv.pl.scatter(final, x='latent_time', y=var_names, frameon=False) Output 

#%%
 scv.tl.rank_dynamical_genes(final, groupby='clusters') df = scv.get_df(adata_scV[0], 'rank_dynamical_genes/names') 
df.head(5) 

#%%
0.2.5 Differential Kinetics 
[139]: var_names = ['SYN1'] 
scv.tl.differential_kinetic_test(JS002, var_names=var_names,groupby='clusters') 
scv.tl.differential_kinetic_test(JS002, var_names=var_names,groupby='clusters') 
kwargs = dict(linewidth=2, add_linfit=True, frameon=False) 
scv.pl.scatter(JS002, basis=var_names, add_outline='fit_diff_kinetics',␣ !→**kwargs) 
diff_clusters=list(JS002[:, var_names].var['fit_diff_kinetics']) scv.pl.scatter(adata_scV[0], legend_loc='right', size=60, title='diff kinetics', add_outline=diff_clusters, outline_width=(.8, .2)) 

#%%
0.3 Analyzing merged samples 
[140]: from scV_utils import merge_adata 
[ ]: ## match metadata to loom file 
metadata = match_lm(metadata,adata_all,loom_list)

















#%%
# Add additional cell annotation (i.e., batch, pair, genotype, timepoint
# and sample ID)
final.obs ['batch']= adata.obs ['batch']
final.obs ['pair']= adata.obs ['pair']
final.obs ['genotype']= adata.obs ['genotype']
final.obs ['timepoint']= adata.obs ['timepoint']
final.obs ['sample_id']= adata.obs ['sample_id']
final.obs['nowakowski.fine.noglyc_unmapped.aggr'] = adata.obs ['nowakowski.fine.noglyc_unmapped.aggr']
final.obs ['leiden_final']= adata.obs ['leiden_final']
print ("annotation copied")
final.obs

#%%
JS001= final

#%%
scv.pp.filter_and_normalize(JS001,log=True) 
scv.pp.moments(JS001) 
scv.tl.umap(JS001) 
scv.tl.velocity(JS001, mode='stochastic') 
scv.tl.velocity_graph(JS001) 

# %% Shortcut from Sevlo tutorials
#%%
# # load all loom files
#  ## load loom and metadata 
# ROOT_DIR = "E:\Sneha\RNAseq\ScSeq"
# dat_folder = 'Raw' 
# input_folfer = 'loompy' 
# loom_list = [file for file in os.listdir(os.path.join(ROOT_DIR,dat_folder,input_folfer)) if file.endswith('.loom')] 
# adata_all = list() 
# for file in loom_list: 
#  print('loading:'+str(file)) 

# #%%
# adata_i = scv.read(os.path.join(ROOT_DIR,dat_folder,input_folfer,file),cache=True) 
# adata_i.var_names_make_unique() 
# adata_all.append(adata_i) 
# print('loom data loading finished') 

#%%
#merge AnnData with loom
# # #ldata = scv.read (final, cache=True)
# adata_i = scv.read("E:\Sneha\RNAseq\ScSeq\Raw\loompy\possorted_genome_bam_JS001.loom", cache=True)
# adata = anndata.read("E:\Sneha\RNAseq\ScSeq\AGGR01_mapped\AGGR01_mapped.final.h5ad")
# print ('loaded loom')
# adata_test = scv.utils.merge(adata, ds)

# # %%
