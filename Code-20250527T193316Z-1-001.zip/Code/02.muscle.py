#%%
# Import modules
from gprofiler import GProfiler
import matplotlib.pyplot as plt
import os
import numpy as np
import pandas as pd
import seaborn as sns

# Tune output figures parameters
sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Not used, custom functions added to code
# os.chdir('../..')
# sys.path.append(os.path.abspath('..'))
# from fbrundu_sclib import *

#%%
# AGGR01_mapped will be used for downstream analyses
samples = ['AGGR01_mapped',]
prefix = samples[0]
prefix

#%%
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join('data')
data = fullpath_closure(data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir)

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, figsize=(7,7))
sc.settings.figdir = out('fig_supp')

#%%
# Load main h5ad file
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Save log-normalized data as raw component for this AnnData
# file. Used as underlying data for some figures (where parameter
# use_raw=True)
adata.raw = sc.AnnData(
    adata.layers['sf_log1p'], obs=adata.obs, var=adata.var,
)

#%%
# Compute neighbors and UMAP from LIGER space
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)
sc.pl.umap(adata)

#%%
def print_factors(
    adata: sc.AnnData,
    varm: str,
    n_genes: float = 100,
    n_comps: int = 20,
    return_dict: bool = False,
):
    """ Return a dictionary containing the top genes (sorted by
        loading) in the first `n_comps` factors. The label of
        the varm matrix containing the loadings is provided with
        through the varm parameter.
    """
    import pandas as pd
    d = {}
    for i in range(n_comps):
        c = pd.Series(adata.varm[varm][:,i], index=adata.var_names)
        c = c[c > 0].sort_values(ascending=False)
        # If n_genes > 1 consider it as the actual number of top genes
        if n_genes > 1:
            c = c.head(n_genes)
        # If n_genes <= consider it the percentage of top genes
        else:
            c /= c.sum()
            c = c[c.cumsum() < n_genes]
        c = c.index.tolist()
        if return_dict:
            d[i] = c
    return d

# Get the top 80% of genes (highest loading genes in all
# the factors derived from LIGER)
factors = print_factors(
    adata, 'X_liger_W', return_dict=True,
    n_comps=adata.varm['X_liger_W'].shape[1],
    n_genes=.8,
)
# Factors are returned as a dictionary of lists.
# The key is the factor index, the value is a list of the
# top genes (sorted by loading in the factor) for each factor

#%%
# Save factors' top genes as a CSV
pd.DataFrame.from_dict(factors, orient='index').T.to_csv(
    out(f'interim_data/qc/{prefix}.factors.csv')
)

#%%
from typing import Dict

def tl_gprof_excel(
    phenos: Dict[str, pd.DataFrame],
    fname: str,
):
    """Save enrichment results to Excel worksheet"""
    import pandas as pd
    writer = pd.ExcelWriter(
        f'{fname}.xlsx', engine='xlsxwriter',
    )
    # Each item on the dictionary represents a different
    # sheet in the resulting file
    for s, data in phenos.items():
        data.to_excel(writer, sheet_name=s, index=False)
    writer.save()

# Factors' enrichment (used only for exploratory analysis)
gp = GProfiler(return_dataframe=True)
res = {}
# For each factor
for f in factors.keys():
    # Get top genes
    genes = factors[f]
    # Compute enrichment
    res[f] = gp.profile(
        organism='hsapiens', query=genes, all_results=False,
        ordered=True, no_iea=True,
    )
# Format results and save them to an Excel worksheet
res = {f'C{k}': v for k, v in res.items()}
if len(res) > 0: 
    tl_gprof_excel(res, out(f'interim_data/qc/{prefix}.liger.factor_gprof'))

#%%
from typing import List

def pl_multi_violin(
    adata: sc.AnnData,
    keys: List[str],
    groupby: str,
    fname: str,
    ncols: int = 4,
    wspace: float = 0.4,
):
    """ Plot different keys on different violin plots with
        tunable parameters.
    """
    import matplotlib.pyplot as plt
    import scanpy as sc
    r = len(keys) // ncols + int((len(keys) % ncols) != 0)
    fig, axs = plt.subplots(r, ncols, figsize=(ncols*5, r*5))
    axs = axs.ravel()
    for i, ax in enumerate(axs):
        if i < len(keys):
            k = keys[i]
            sc.pl.violin(adata, keys=k, groupby=groupby, ax=ax, show=False)
        else:
            ax.axis('off')
    plt.subplots_adjust(wspace=wspace)
    fig.savefig(fname, bbox_inches='tight')

def pl_factors(
    adata: sc.AnnData,
    factors: List[int] = None,
    ncols: int = 4,
    rep: str = 'X_liger_H',
    suffix: str = '',
    violin_groupby: str = None,
    violin_fname: str = '',
):
    """ Plot UMAPs of factors' usage, with optional
        factor usage violin plots.
    """
    import scanpy as sc
    _adata = adata.copy()
    factors_names = []
    if factors is None:
        factors = range(_adata.obsm[rep].shape[1])
    for f in factors:
        _adata.obs.loc[:, f'Factor{f}'] = pd.Series(
            _adata.obsm[rep][:, f], index=_adata.obs_names,
        )
        factors_names += [f'Factor{f}']
    sc.pl.umap(
        _adata, color=factors_names, cmap='viridis', ncols=ncols,
        save=f'.liger_factors{suffix}.pdf',
    )
    if violin_groupby is not None:
        pl_multi_violin(
            _adata, factors_names, violin_groupby, violin_fname,
        )

# Plot factor usage through UMAPs (with optional violin plots)
pl_factors(adata, factors, suffix='.prefilter')

#%%
# Plot UMAPs of QC metrics and cell library annotations
sc.pl.umap(
    adata,
    color=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    save=f'.qc.prefilter.pdf',
)

#%%
# NOTE Execute from here only if repeating filtering
# This file is generated below.
adata = sc.read(out(f'interim_data/qc/{prefix}.final.prefilter.h5ad'))

#%%
# Load myogenesis genes from MSigDB
myogenesis = pd.read_csv(
    data('msigdb.hallmark_myogenesis.txt'),
    skiprows=2,
    header=None,
).T.values.tolist()[0]
# Load DEG specific to JS006 in bulk
bulk_deg = pd.read_csv(
    'data/JS006.bulk_deg.csv',
    index_col=0,
)[['name']].T.values.tolist()[0]
# Get myogenesis genes (myo_genes) identified in bulk as specific to JS006
myo_genes_legacy = list(
    set(myogenesis) & set(bulk_deg) & set(adata.raw.var_names)
)
# Get total number of counts associated with this gene subset
myo_counts = np.expm1(adata.raw[:, myo_genes_legacy].X).sum(axis=1)
# Get total counts for all genes
tot_counts = np.expm1(adata.raw.X).sum(axis=1)
# Compute percentage of myo genes detected for each cell
adata.obs['myo_detect_legacy'] = (
    adata.raw[:, myo_genes_legacy].X > 0
).mean(axis=1)
# Log-transform counts associated with myo_genes
adata.obs['myo_counts_legacy'] = np.log1p(myo_counts)
# Compute percentage of myo_genes counts over total counts
adata.obs['myo_perc_legacy'] = myo_counts / tot_counts

#%%
# Plot myo_genes information
sc.pl.violin(
    adata,
    keys=['myo_perc_legacy', 'myo_counts_legacy', 'myo_detect_legacy'],
    groupby='batch',
    save='.myo_legacy.batch.pdf',
    rotation=90,
    cut=0,
)

#%%
# Select cells based on myo_genes count and detection percentage
cells = (
    ~(adata.obs['myo_perc_legacy'] > .0025)
    & ~(adata.obs['myo_detect_legacy'] > .2)
)

#%%
cells.value_counts()

#%%
# Label cells with high counts and detection of myo_genes and
# explore the distribution by batch.
k = 'Muscle (high)'
adata.obs[k] = ~cells
adata.obs.groupby('batch')[k].value_counts(normalize=True).round(2)

#%%
sc.pl.umap(
    adata,
    color=['Muscle (high)'],
    cmap='viridis',
    save='.muscle.prefilter.pdf',
)

#%%
# Save snapshot before filtering
adata.write(out(f'interim_data/qc/{prefix}.final.prefilter.h5ad'))

#%%
adata = sc.read(out(f'interim_data/qc/{prefix}.final.prefilter.h5ad'))

#%%
adata.obs[k].value_counts()

#%%
# Filter cells with high expression/detection of myo_genes
adata = adata[~adata.obs[k],:].copy()
adata

#%%
# Recompute neighbors and UMAPs
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)

#%%
# Plot QC metrics and cell annotations after myo_genes filtering
sc.pl.umap(
    adata,
    color=[
        'n_counts',
        'n_genes',
        'percent_mito',
        'percent_ribo_p',
        'batch',
        'genotype',
        'pair',
        'timepoint',
        'sample_id',
    ],
    cmap='viridis',
    size=5,
    wspace=.3,
    save=f'.qc.postmuscle.pdf',
)

#%%
# Update final AnnData
adata.write(out(f'{prefix}.final.h5ad'))

#%%
