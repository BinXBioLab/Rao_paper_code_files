#%%
# Load modules
import matplotlib.pyplot as plt
import os
import pandas as pd
import seaborn as sns
import sys

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Not used, custom functions added to code
# os.chdir('../..')
# sys.path.append(os.path.abspath('..'))
# from fbrundu_sclib import *

#%%
# Define samples
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

#%%
# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

data_dir = os.path.join('data')
data = fullpath_closure(data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

#%%
# Load main AnnData
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Load unmapped counts (no read depth normalization)
adata_counts = sc.read(
    f'results/v01/AGGR01_unmapped/interim_data/qc/AGGR01_unmapped.preqc.h5ad'
)

#%%
# Generate counts matrix
mat = adata_counts[adata.obs_names].to_df()
mat

#%%
# Optional: if using mapped counts, use this to generate
# the counts matrix
# mat = pd.DataFrame(
    # adata.layers['counts'].todense(),
    # index=adata.obs_names,
    # columns=adata.var_names,
# )

#%%
# Define parameters for AWS batch
# - Temporary bucket (with autoremoval policy - i.e. after 20 days)
bucket = 'fb2505-devnull'
# - Minimum of cells required for a group in the training dataset
#   Groups with fewer cells than this will not be used for annotation
min_cells = 5
# - AWS bucket containing data/code/reference to use with SingleR
ref_s3 = 's3://fb2505-misc/2020-sc-ref'
# - Parameters within the reference AWS bucket for each training dataset
refs = {
    'nowakowski.fine.noglyc_unmapped': {
        'folder': 'nowakowski',
        'base': 'nowakowski',
        'labels': 'nowakowski.fine.noglyc',
    },
    # NOTE not used
    # 'nowakowski.coarse.noglyc_unmapped': {
    #     'folder': 'nowakowski',
    #     'base': 'nowakowski',
    #     'labels': 'nowakowski.coarse.noglyc',
    # },
    # 'nowakowski.fine.noglyc': {
    #     'folder': 'nowakowski',
    #     'base': 'nowakowski',
    #     'labels': 'nowakowski.fine.noglyc',
    # },
    # 'nowakowski.coarse.noglyc': {
    #     'folder': 'nowakowski',
    #     'base': 'nowakowski',
    #     'labels': 'nowakowski.coarse.noglyc',
    # },
}

#%%
# NOTE Helper functions to run SingleR on AWS batch
from typing import Dict, Union

class SingleRCollectionError(Exception):
    def __init__(
        self,
        message: str,
        job_collection: Dict[str, Dict[str, str]],
    ):
        """ Exception raised when results cannot be retrieved. """
        # Call the base class constructor with the parameters it needs
        super().__init__(message)
        self.jc = job_collection

def tl_annotate_singler(
        bucket: str,
        ref: str,
        mat: pd.DataFrame, 
        labels: str,
        min_cells: int = 5,
        # Bys not implemented
        bys=None,
        verbose: bool = False,
    ):
    """ Main entrypoint for annotation. """
    from botocore.exceptions import ClientError
    pred = None
    conf = None
    if bys is None:
        job_collection = {}
        job_collection = _tl_annotate_singler_internal(
            job_collection, bucket, ref, mat, labels, min_cells=min_cells,
            verbose=verbose,
        )
        try:
            pred, conf = tl_annotate_singler_prep_output(
                job_collection, bucket,
            )
        except ClientError as e:
            raise SingleRCollectionError(e, job_collection) from e
        except Exception as e:
            raise SingleRCollectionError(e.message, job_collection) from e
        yield pred, conf
    else:
        raise NotImplementedError('Bys parameter not implemented')

def _tl_annotate_singler_internal(
        job_collection: Dict[str, Dict[str, str]],
        bucket: str,
        ref: str,
        mat: pd.DataFrame,
        labels: str,
        by: str = None,
        min_cells: int = 5,
        verbose: bool = False,
    ):
    if by is None:
        b = 'Sheet0'
    remote_dir, job_id, job_name, pred, conf = tl_annotate_singler_compute(
        bucket, ref, mat, labels, block=False, min_cells=min_cells, 
        verbose=verbose,
    )
    job_collection[job_id] = {'group': b, 'remote_dir': remote_dir}
    return job_collection

def tl_annotate_singler_prep_output(
    job_collection: Dict[str, Dict[str, str]],
    bucket: str,
    wait: int = 30,
):
    """Get results from AWS batch - only implemented for a single execution."""
    pred = None
    conf = None
    for job_id, status, metadata, pred, conf in tl_annotate_singler_collect(
            job_collection, bucket, wait=wait,
        ):
        if status == 'SUCCEEDED':
            b = metadata['group']
        elif status == 'FAILED':
            print(f'Job Failed: group {metadata["group"]}')
        else:
            raise NotImplementedError(f'Status {status} not managed')
    return pred, conf

def _tl_annotate_singler_prep(
        ref: Union[str, pd.DataFrame],
        mat: pd.DataFrame,
        labels: str,
        bucket: str,
        remote_dir: str,
        ready: List[str] = None,
        min_cells: int = 5,
        n_iter: int = 300,
        verbose: bool = False,
    ):
    """ Preparing job for AWS batch execution. """
    import boto3 as bt
    import os
    import pandas as pd
    import scanpy as sc
    import tempfile
    # Prepare AWS S3 resource for working with temporary bucket
    s3 = bt.resource('s3')
    if ready is None:
        ready = []
    # Within a local temporary directory
    with tempfile.TemporaryDirectory() as td:
        # If ref and mat are not already in the temporary bucket
        if ('ref' not in ready) or ('mat' not in ready):
            # Prepare path for local reference matrix
            local_ref = os.path.join(td, 'ref.fth')
            # If reference is stored in a second bucket
            if type(ref) is str and ref.startswith('s3://'):
                if verbose:
                    print('Reference is s3 path, downloading...')
                # Get the reference from the bucket
                bucket_d = ref[5:].split('/')[0]
                ref = '/'.join(ref[5:].split('/')[1:])
                ext = os.path.splitext(ref)[1]
                local_ref_temp = os.path.join(td, f'ref_temp.{ext}')
                s3.Bucket(bucket_d).download_file(ref, local_ref_temp)
                # Depending on the reference format load it in different
                # ways to a pandas DataFrame
                if ref.endswith('.csv'):
                    if verbose:
                        print('Reference is CSV')
                    ref = pd.read_csv(local_ref_temp, index_col=0)
                elif ref.endswith('.h5ad'):
                    if verbose:
                        print('Reference is AnnData')
                    ref = sc.read(local_ref_temp)
                    ref = ref.to_df()
                else:
                    raise NotImplementedError('Ref format not recognized')
            # If it's already a pandas DataFrame, just copy it
            else:
                ref = ref.copy()
            if verbose:
                print('Filtering ref by number of genes and cells detected')
                print(f'Initial shape: {ref.shape[0]} cells, {ref.shape[1]} genes')
            # Filter cells from ref, with fewer than 200 genes expressed
            ref = ref.loc[((ref > 0).sum(axis=1) >= 200), :]
            # Filter genes from ref, expressed in fewer than 3 cells
            ref = ref.loc[:, ((ref > 0).sum(axis=0) >= 3)]
            if verbose:
                print(
                    f'Filtered shape: {ref.shape[0]} cells, '
                    f'{ref.shape[1]} genes'
                )
            # Prepare local path for dataset to annotate (raw counts matrix)
            local_mat = os.path.join(td, 'mat.fth')
            mat = mat.copy()
            # Filter out genes expressed in fewer than 3 cells
            mat = mat.loc[:, ((mat > 0).sum(axis=0) >= 3)]
            # Get common genes between reference and dataset to annotate
            genes = list(set(ref.columns) & set(mat.columns))
            if verbose:
                print(f'Common genes between ref and matrix: {len(genes)}')
            # Keep only these genes on both reference and dataset to annotate
            ref = ref.loc[:, genes]
            mat = mat.loc[:, genes]
            if verbose:
                print('Running CPM normalization')
            # Run CPM normalization and save to local temporary paths as
            # uncompressed feather files, ready to be sent to AWS batch
            ref.apply(
                lambda x: x*1e6/x.sum(), axis=1,
            ).reset_index().to_feather(local_ref, compression='uncompressed')
            mat.apply(
                lambda x: x*1e6/x.sum(), axis=1,
            ).reset_index().to_feather(local_mat, compression='uncompressed')
            if verbose:
                print('Uploading reference and matrix to s3...')
            # Upload files to temporary bucket
            remote_ref = os.path.join(remote_dir, 'ref.fth')
            s3.meta.client.upload_file(local_ref, bucket, remote_ref)
            remote_mat = os.path.join(remote_dir, 'mat.fth')
            s3.meta.client.upload_file(local_mat, bucket, remote_mat)
        # If labels are not already in temporary bucket
        if 'labels' not in ready:
            # Prepare local path for labels
            local_labels = os.path.join(td, 'labels.csv')
            # If they are located in a remote s3 file, download labels and load
            # them as a pandas DataFrame
            if type(labels) is str and labels.startswith('s3://'):
                if verbose:
                    print('Labels is s3 path, downloading...')
                bucket_d = labels[5:].split('/')[0]
                labels = '/'.join(labels[5:].split('/')[1:])
                s3.Bucket(bucket_d).download_file(labels, local_labels)
                labels = pd.read_csv(local_labels, index_col=0)
            # Otherwise just make a copy
            else:
                labels = labels.copy()
            if verbose:
                print(f'Removing groups with fewer than {min_cells} cells...')
            # Remove groups with fewer than `min_cells` cells
            groups = labels.value_counts()
            groups = groups[
                groups >= min_cells
            ].index.to_frame().iloc[:, 0].tolist()
            labels = labels[labels.iloc[:, 0].isin(groups)]
            # Save to local temporary file and upload to temporary S3 bucket
            labels.to_csv(local_labels, header=True)
            remote_labels = os.path.join(remote_dir, 'labels.csv')
            s3.meta.client.upload_file(local_labels, bucket, remote_labels)
        if verbose:
            print('Preparing manifest')
        # Define remote directory on S3 temporary bucket
        remote = os.path.join(bucket, remote_dir)
        # Prepare manifest to instruct code on AWS batch
        manifest = '\n'.join([
            f'WORKSPACE={remote}', 'BATCH_INDEX_OFFSET=0', 'REF=ref.fth',
            'MAT=mat.fth', 'LABELS=labels.csv', 'PRED=pred.csv',
            f'MIN_CELLS={min_cells}', f'N_ITER={n_iter}',
            f'LABEL_ID={labels.columns[0]}', 'CONF=conf.csv',
        ])
        # Save and upload manifest to remote directory on S3 temp bucket
        local_manifest = os.path.join(td, 'manifest.txt')
        with open(local_manifest, 'w') as m:
            m.write(manifest + '\n')
        remote_manifest = os.path.join(remote_dir, 'manifest.txt')
        s3.meta.client.upload_file(local_manifest, bucket, remote_manifest)
        if verbose:
            print('Done preparing')
    # Return the remote manifest path to the caller
    return remote_manifest

def _tl_annotate_singler_submit(
        bucket: str,
        manifest: str,
        block: bool = False,
        job_name: str = 'singler',
    ):
    """ Submit job to AWS batch. """
    import boto3 as bt
    import os
    # Prepare AWS batch, and associated variables
    batch = bt.client('batch')
    job_queue = 'x1e-xlarge-4vCPU-120GB'
    job_def = 'fb2505-singler'
    job_manifest = f's3://{os.path.join(bucket, manifest)}'
    job_id = None
    try:
        print(f'Submitting job {job_name} to the job queue {job_queue}')
        submit_job_response = batch.submit_job(
            jobName=job_name, jobQueue=job_queue, jobDefinition=job_def,
            containerOverrides={'command': [job_manifest]}
        )
        # Get job id of submitted job
        job_id = submit_job_response['jobId']
        print(f'Submitted job {job_name} {job_id} to the job queue {job_queue}')
    except Exception as err:
        print(f'error: {str(err)}')
    return job_id

def tl_annotate_singler_compute(
        bucket: str,
        ref: Union[str, pd.DataFrame],
        mat: pd.DataFrame,
        labels: str,
        block: bool = False,
        remote_dir: str = None,
        min_cells: int = 5,
        verbose: bool = False,
    ):
    """ Prepare data and submit AWS job. Optionally block and release only
        when results are ready (not used).
    """
    import os
    import uuid
    pred = None
    conf = None
    if remote_dir is None:
        # Create a unique id for a remote_dir
        remote_dir = os.path.join('singler', str(uuid.uuid4()))
        if verbose:
            print(f'Initializing remote dir {remote_dir}')
        ready = []
    else:
        ready = ['ref', 'mat', 'labels']
    # Prepare data for SingleR and get manifest
    manifest = _tl_annotate_singler_prep(
        ref, mat, labels, bucket, remote_dir, min_cells=min_cells, n_iter=300,
        verbose=verbose,
    )
    # Submit job to AWS batch
    job_name = f'singler'
    job_id = _tl_annotate_singler_submit(
        bucket, manifest, block=block, job_name=job_name,
    )
    # Only non-blocking API is used (this step is provided for compatibility)
    if block:
        status = _tl_aws_batch_job_status(job_id, wait=60)
        if status == 'SUCCEEDED':
            pred, conf = _tl_annotate_singler_results(bucket, remote_dir)
    # Return results if blocking API is used
    return remote_dir, job_id, job_name, pred, conf

def tl_annotate_singler_collect(
    collection: Dict[str, Dict[str, str]],
    bucket: str,
    wait: int = 30,
):
    """ Perform polling on AWS batch to retrieve results when ready. """
    import time
    while wait and len(collection) > 0:
        time.sleep(wait)
        for job_id in list(collection.keys()):
            status = _tl_aws_batch_job_status(job_id)
            if status == 'SUCCEEDED':
                remote_dir = collection[job_id]['remote_dir']
                # Status is success, retrieve result
                pred, conf = _tl_annotate_singler_results(bucket, remote_dir)
                yield job_id, status, collection.pop(job_id), pred, conf
            elif status == 'FAILED':
                yield job_id, status, collection.pop(job_id), None, None

def _tl_aws_batch_job_status(
    job_id: str,
    wait: int = 0,
    verbose: bool = False,
):
    """ Get job status. """
    import boto3 as bt
    import time
    batch = bt.client('batch')
    describe_jobs_response = batch.describe_jobs(jobs=[job_id])
    status = describe_jobs_response['jobs'][0]['status']
    if verbose: print(status)
    while wait:
        time.sleep(wait)
        describe_jobs_response = batch.describe_jobs(jobs=[job_id])
        new_status = describe_jobs_response['jobs'][0]['status']
        if new_status != status:
            status = new_status
            if verbose: print(status)
        if status == 'SUCCEEDED' or status == 'FAILED':
            break
    return status

def _tl_annotate_singler_results(
    bucket: str,
    remote_dir: str,
):
    """ Retrieve job results. """
    import boto3 as bt
    import os
    import pandas as pd
    import tempfile
    s3 = bt.resource('s3')
    with tempfile.TemporaryDirectory() as td:
        remote_pred = os.path.join(remote_dir, 'pred.csv')
        local_pred = os.path.join(td, 'pred.csv')
        s3.Bucket(bucket).download_file(remote_pred, local_pred)
        pred = pd.read_csv(local_pred, index_col=0)
        remote_conf = os.path.join(remote_dir, 'conf.csv')
        local_conf = os.path.join(td, 'conf.csv')
        s3.Bucket(bucket).download_file(remote_conf, local_conf)
        conf = pd.read_csv(local_conf, index_col=0)
    return pred, conf

#%%
def tl_annotate_excel(pred, conf, fname):
    import pandas as pd
    writer = pd.ExcelWriter(
        f'{fname}.xlsx', engine='xlsxwriter'
    )
    for s, data in [('Prediction', pred), ('Confidence', conf)]:
        data.to_excel(writer, sheet_name=s)
    writer.save()

#%%
from typing import List

def tl_annotate_hiconf(
    obs: pd.DataFrame,
    pred: pd.DataFrame,
    conf: pd.DataFrame,
    ref_name: str,
    aggr: Dict[str, List[str]] = None,
    map_dict: Dict[str, str] = None,
):
    """ Based on annotation on stratified subsamples, compute and
        select the most robust annotations.
    """
    import pandas as pd
    # Remove previous annotations from main AnnData obs
    obs = obs.loc[:, ~obs.columns.str.startswith(ref_name)]
    # Save new annotation on main AnnData obs
    obs[ref_name] = pred.loc[obs.index, 'labels']
    # Annotate also pruned labels (not used in downstream analyses)
    obs[f'{ref_name}.pruned'] = pred.loc[obs.index, 'pruned.labels']
    # In case cell types should be remapped with a different name
    if map_dict:
        obs[ref_name] = obs[ref_name].astype(str).map(
            map_dict
        ).astype('category')
        conf = conf.apply(
            lambda x: pd.Categorical(
                x.astype(str).map(map_dict),
                categories=obs[ref_name].cat.categories
            )
        )
    # Compute the percentage of times a label is kept during training
    # on stratified subsamples
    obs[f'{ref_name}.accuracy'] = conf.eq(
        obs[ref_name], axis='index',
    ).mean(axis=1).loc[obs.index]
    # Get number of cell types
    n_classes = obs[ref_name].nunique()
    # Consider robust annotation the ones with higher percentage
    # than random assignment
    hiconf = obs[f'{ref_name}.accuracy'] > (1 / n_classes)
    # Transform into a categorical datatype
    obs[ref_name] = obs[ref_name].astype('category')
    # Add low confidence category
    obs[ref_name] = obs[ref_name].cat.add_categories(['loconf'])
    # Annotate least robust annotation as loconf (low confidence)
    obs.loc[~hiconf, ref_name] = 'loconf'
    # Annotate the number of cells for each cell type, too
    new_k = f'{ref_name}.n'
    ccounts = obs[ref_name].value_counts().to_dict()
    # Create a separate annotation where each cell type has its
    # prevalence as suffix
    obs[new_k] = obs[ref_name].map(
        {k: f'{k} ({v})' for k, v in ccounts.items()}
    )
    # If a mapping dictionary for aggregation is provided, aggregate
    # and generate a separated aggregated annotation
    if aggr:
        k = f'{ref_name}.aggr'
        obs[k] = obs[ref_name].astype(str).map(aggr).astype('category')
        new_k = f'{k}.n'
        ccounts = obs[k].value_counts().to_dict()
        obs[new_k] = obs[k].map(
            {k: f'{k} ({v})' for k, v in ccounts.items()}
        )
    # Return obs annotation to update main AnnData
    return obs


#%%
# Annotate and save results to an Excel file
for r in refs.keys():
    print(f'> Starting annotation with {r}')
    rr = refs[r]
    ref = f'{ref_s3}/{rr["folder"]}/{rr["base"]}.h5ad'
    labels = f'{ref_s3}/{rr["folder"]}/{rr["labels"]}.labels.csv'
    for pred, conf in tl_annotate_singler(
            bucket, ref, mat, labels, min_cells=min_cells, verbose=True,
        ):
        fname = out(f'interim_data/singler/pred.{prefix}.{r}') 
        tl_annotate_excel(pred, conf, fname)

#%%
# Save annotations into main AnnData
for r in list(refs.keys()):
    fname = out(f'interim_data/singler/pred.{prefix}.{r}.xlsx') 
    results = pd.read_excel(fname, sheet_name=None, index_col=0)
    pred, conf = results['Prediction'], results['Confidence']
    pred = pred.loc[adata.obs_names]
    conf = conf.loc[adata.obs_names]
    adata.obs = tl_annotate_hiconf(adata.obs, pred, conf, r)

#%%
# Plot annotations UMAPs
sc.pl.umap(
    adata,
    color=list(refs.keys()),
    cmap='viridis',
    ncols=1,
    # save='.annotation.unmapped.pdf',
)

#%%
# Main key label used for cell type annotation
key = 'nowakowski.fine.noglyc_unmapped'

#%%
# Save AnnData snapshot before filtering
adata.write(out(f'interim_data/singler/{prefix}.final.prefilter.h5ad'))

#%%
# Load snapshot (start from here if you want to change filtering parameters)
adata = sc.read(out(f'interim_data/singler/{prefix}.final.prefilter.h5ad'))
adata

#%%
# Check cell type quantification
adata.obs[key].value_counts()

#%%
# Remove unstable and unknown annotations
adata = adata[~adata.obs[key].isin(['loconf', 'U1', 'U2', 'U4'])].copy()

#%%
# Update main AnnData on disk
adata.write(out(f'{prefix}.final.h5ad'))

#%%
