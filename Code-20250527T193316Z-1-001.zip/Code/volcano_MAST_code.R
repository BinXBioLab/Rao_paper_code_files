

setwd("E:/Sneha/MAST/volcano")
  
res = read.csv("divRG_MAST_volcano.csv", header= TRUE, row.names = 1)
  
  
  ##volcano plot
library(EnhancedVolcano)
EnhancedVolcano(res,
                lab = rownames(res),
                x = 'Case_coef',
                y = 'Case_pval',
                selectLab = c("PEG3", "VIM", "TUSC1", "KIF15", "LINC01551", "LINC02301", "TUBB2A", "MED15", "CDC42", "MRPL40", "ARC", "RANBP1", "DGCR8", "COMT", "PTN" ),
                xlab = bquote(Coeff),
                ylab = bquote(~-Log[10] ~ italic(P)),
                xlim = c(-4, 4), title= NULL, pCutoff = 0.05, FCcutoff = 0.02, pointSize = 2.0, 
                ylim = c(0, 100),
                drawConnectors = TRUE,
                widthConnectors = 0.5,
                typeConnectors = "closed",
                endsConnectors = "first",
                lengthConnectors = unit(1, "npc"),
                colConnectors = "grey10",
                maxoverlapsConnectors = 25,
                directionConnectors = "both",
                arrowheads = FALSE,
                gridlines.major = FALSE,
                gridlines.minor = FALSE,
                labSize = 4.0, 
                legendPosition = 'right', legendLabSize = 0,
                legendIconSize = 0)




res= read.csv('EN_MAST_volcano.csv', header = TRUE, row.names = 1)

EnhancedVolcano(res,
                lab = rownames(res),
                x = 'Case_coef',
                y = 'Case_pval',
                selectLab = c("PEG3", "PKIB", "SOX4", "EMC10", "SLITRK5", "TCF4", "SEMA6A", "DCX", "PI4KA", "CDC42", "MRPL40", "GRIA4", "RANBP1", "DGCR8", "COMT", "GRIA2", "SCN9A" ),
                xlab = bquote(Coeff),
                ylab = bquote(~-Log[10] ~ italic(P)),
                xlim = c(-7, 7), title= NULL, pCutoff = 0.05, FCcutoff = 0.02, pointSize = 2.0, 
                ylim = c(0, 200),
                drawConnectors = TRUE,
                widthConnectors = 0.5,
                typeConnectors = "closed",
                endsConnectors = "first",
                lengthConnectors = unit(1, "npc"),
                colConnectors = "grey10",
                maxoverlapsConnectors = 25,
                directionConnectors = "both",
                arrowheads = FALSE,
                gridlines.major = FALSE,
                gridlines.minor = FALSE,
                labSize = 4.0, 
                legendPosition = 'right', legendLabSize = 0,
                legendIconSize = 0)
