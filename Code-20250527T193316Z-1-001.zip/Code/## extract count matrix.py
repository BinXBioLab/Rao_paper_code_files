## extract count matrix
#%%

#%%
import scanpy as sc

#%%
adata = sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad" )

#%%


data = adata.write_csvs("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01.mapped.final.counts", skip_data=False)

# %%
adata
# %%
import pandas as pd
#adata= adata.T

# %%
data = pd.DataFrame(adata.X.todense(), index=adata.obs.index, columns=adata.var.index)

#%%
#data = data.transpose(copy=False)  ## not needed to read in R, it automatically transposes

#%%
data.to_csv('E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01.mapped.final.counts.2.csv')
#data= pd.DataFrame(adata.X,index=adata.obs.index,columns=adata.var.index)


# %%
adata.var.to_csv("adatavar.csv")
