#%%
# NOTE check that MAST is using either counts_mapped or _unmapped
# NOTE in this analysis it should be counts_mapped (counts layer)
# Import modules
from gprofiler import GProfiler
import matplotlib.pyplot as plt
from natsort import natsorted
import numpy as np
import os
import pandas as pd
import re
import seaborn as sns

from pybatch_mast import BatchMAST

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

#%%
# Workdir is root workspace dir
os.chdir('/Sneha/RNAseq/ScSeq/test/scrna-seq-analysis/organoids')
current = os.getcwd()
current

#%%
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join(prefix)
data = fullpath_closure(data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, format ="eps" )
sc.settings.figdir = out('fig_supp')

#%%
# Load main AnnData snapshot from disk
adata = sc.read(data(f'{prefix}.final.h5ad'))
adata

#%%
# Define label for cell type annotation
key = 'nowakowski.fine.noglyc_unmapped'

#%%
# Define color palette for cell type annotation
palette = sns.color_palette('Set2') + '#235b54 #3998f5 #991919 #c56133 #2f2aa0 #b732cc #f07cab #d30b94 #c3a5b4 #5d4c86'.split()
sns.palplot(palette)

#%%
# Plot UMAPs with:
# - on rows, fine and fine aggregated annotation
# - on columns, full dataset and only cells on a specific timepoint
rows = [key]
if 'fine' in key:
    rows.append(f'{key}.aggr')
fig, axes = plt.subplots(
    len(rows), 3, figsize=(7.5*3, 6*len(rows)), squeeze=False,
)
for j, tp in enumerate(['full', '70d', '150d']):
    for i, c in enumerate(rows):
        if tp == 'full':
            cells = adata.obs_names
        else:
            cells = adata.obs[adata.obs['timepoint'] == tp].index
        sc.pl.umap(
            adata[cells],
            color=c,
            cmap='viridis',
            palette=palette,
            legend_fontsize=7,
            show=False,
            ax=axes[i][j],
        )
plt.subplots_adjust(wspace=.45)
fig.savefig(
    out(f'fig_supp/singler/umap.{key}.pdf'), bbox_inches='tight',
)

#%%
# Create composite label for genotype and timepoint
adata.obs['genotype_timepoint'] = [
    f'{adata.obs.loc[r, "genotype"]}_{adata.obs.loc[r, "timepoint"]}'
    for r in adata.obs_names
]
adata.obs['genotype_timepoint']

#%%
# Save data snapshot to disk
adata.write(out(f'{prefix}.final.h5ad'))

#%%
# Compute differential expressed genes with MAST for genotype
# genotype_timepoint and timepoint
for group in ['genotype', 'genotype_timepoint', 'timepoint']:
    print(f'Analyzing {group}')
    # Define parameters for MAST on AWS Batch
    job_queue = 'x1e-xlarge-4vCPU-120GB'
    job_def = 'fb2505-mast'
    bucket = 'fb2505-devnull'
    # Use counts (mapped)
    layer = 'counts'
    bmast = BatchMAST(
        job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
    )
    print(f'{layer} layer')

    # Get number of cells for each cell type
    n_cells = adata.obs[key].value_counts()
    print(n_cells)

    # Get number of cells for each group (e.g. genotype)
    # within each cell type
    clusters_size = adata.obs.groupby(key)[group].value_counts()
    print(clusters_size)

    # Get minimum size (between different values of group, e.g., 
    # genotype) for each cell type
    min_clusters = clusters_size.groupby(level=0).min()
    print(min_clusters)

    # For each cell type, set parameters to keep only 
    # genes expressed in at least k cells on all values
    # of group (e.g., for genotype, at least k cells for
    # each genotype value)
    min_genes = 30
    min_size = {
        kname: min_clusters.loc[kname]
        for kname in adata.obs[key].unique()
    }
    min_perc = {
        kname: min_genes/min_size[kname] 
        for kname in adata.obs[key].unique()
    }
    min_perc

    # Set parameters for different performance version
    # of the AWS batch job (i.e., increased memory or
    # number of jobs)
    tot_cells = adata.shape[0]
    if tot_cells < 5000:
        jobs = 4
        job_def = 'fb2505-mast-lowmem'
    elif tot_cells < 15000:
        jobs = 2
    else:
        jobs = 1
    job_def, jobs

    # Define parameters to run one MAST execution for each
    # cell type (key is the variable that identifies the cell
    # type annotation)
    bys = [
        (key, list(adata.obs[key].cat.categories)),
    ]
    # Define cell annotation to pass to MAST
    keys = ['n_genes', 'genotype', 'timepoint', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', 'genotype_timepoint', key]
    # Set parameters for filtering of top differentially
    # expressed genes
    fdr = .05
    lfc = .5
    # Set covariates to use (in this case only one setup)
    covs_l = ['+pair+percent_mito+percent_ribo_p',]
    print(f'Using {jobs} jobs')
    # Submit job to MAST and save results to an excel file
    for covs in covs_l:
        for de, top, by in bmast.mast(
            adata, keys, group, fdr, lfc, covs, min_perc=min_perc,
            on_total=False, jobs=jobs, bys=bys,
        ):
            fname = out(f'interim_data/singler/mast/de.{by}.{group}{covs}') 
            bmast.mast_to_excel(de, fname, top=top, top_prefix=f'{lfc}')

#%%
# Test differentially expressed genes between timepoints on each
# genotype separately (for each cell type)
for genotype in ['Case', 'Control']:
    for group in ['timepoint']:
        print(f'Analyzing {group}')
        # Define parameters for MAST on AWS Batch
        job_queue = 'x1e-xlarge-4vCPU-120GB'
        job_def = 'fb2505-mast'
        bucket = 'fb2505-devnull'
        # Use counts (mapped)
        layer = 'counts'
        bmast = BatchMAST(
            job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
        )
        print(f'{layer} layer')

        # Get data only for current genotype
        adata_g = adata[adata.obs['genotype'] == genotype].copy()
    
        # Get number of cells for each cell type
        n_cells = adata_g.obs[key].value_counts()
        print(n_cells)
    
        # Get number of cells for each group (e.g. timepoint)
        # within each cell type
        clusters_size = adata_g.obs.groupby(key)[group].value_counts()
        print(clusters_size)
    
        # Get minimum size (between different values of group, e.g., 
        # timepoint) for each cell type
        min_clusters = clusters_size.groupby(level=0).min()
        print(min_clusters)
    
        # For each cell type, set parameters to keep only 
        # genes expressed in at least k cells on all values
        # of group (e.g., for timepoint, at least k cells for
        # each timepoint value)
        min_genes = 30
        min_size = {
            kname: min_clusters.loc[kname]
            for kname in adata_g.obs[key].unique()
        }
        min_perc = {
            kname: min_genes/min_size[kname] 
            for kname in adata_g.obs[key].unique()
        }
        min_perc

        # Set parameters for different performance version
        # of the AWS batch job (i.e., increased memory or
        # number of jobs)
        tot_cells = adata_g.shape[0]
        if tot_cells < 5000:
            jobs = 4
            job_def = 'fb2505-mast-lowmem'
        elif tot_cells < 15000:
            jobs = 2
        else:
            jobs = 1
        job_def, jobs
    
        # Define parameters to run one MAST execution for each
        # cell type (key is the variable that identifies the cell
        # type annotation)
        bys = [
            (key, list(adata_g.obs[key].cat.categories)),
        ]
        # Define cell annotation to pass to MAST
        keys = ['n_genes', 'genotype', 'timepoint', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', 'genotype_timepoint', key]
        # Set parameters for filtering of top differentially
        # expressed genes
        fdr = .05
        lfc = .5
        # Set covariates to use (in this case only one setup)
        covs_l = ['+pair+percent_mito+percent_ribo_p',]
        print(f'Using {jobs} jobs')
        # Submit job to MAST and save results to an excel file
        for covs in covs_l:
            for de, top, by in bmast.mast(
                adata_g, keys, group, fdr, lfc, covs, min_perc=min_perc,
                on_total=False, jobs=jobs, bys=bys,
            ):
                fname = out(
                    'interim_data/singler/mast/'
                    f'de.{genotype}.{by}.{group}{covs}'
                ) 
                bmast.mast_to_excel(de, fname, top=top, top_prefix=f'{lfc}')


#%%
# Compute differential expressed genes with MAST for genotype
# for each timepoint separately
key_by = f'{key}'
for tp in ['70d', '150d']:
    # Define parameters for MAST on AWS Batch
    job_queue = 'x1e-xlarge-4vCPU-120GB'
    job_def = 'fb2505-mast'
    bucket = 'fb2505-devnull'
    # Use counts (mapped)
    layer = 'counts'
    bmast = BatchMAST(
        job_queue=job_queue, job_def=job_def, bucket=bucket, layer=layer,
    )

    # Get data for current timepoint
    adata_t = adata[adata.obs['timepoint'] == tp].copy()
    # Get minimum number of cells across genotypes for each
    # cell type
    clusters_size = adata_t.obs.groupby(key_by)['genotype'].value_counts()
    min_clusters = clusters_size.groupby(level=0).min()
    # Set parameters to filter out genes expressed in fewer than
    # k cells (e.g., 30) across genotypes, within each cell type
    min_genes = 30
    min_size = {
        kname: min_clusters.loc[kname]
        for kname in adata_t.obs[key_by].unique()
    }
    min_perc = {
        kname: min_genes/min_size[kname] 
        for kname in adata_t.obs[key_by].unique()
    }
    # Compute one MAST execution for each cell type defined in
    # `key_by` cell annotation
    bys = [
        (key_by, list(adata_t.obs[key_by].cat.categories)),
    ]
    # Cell annotations passed to MAST
    keys = ['n_genes', 'genotype', 'timepoint', 'pair', 'percent_mito', 'percent_ribo_p', 'batch', 'myo_perc_legacy', key_by]
    # Testing differences in gene expression between genotypes
    group = 'genotype'
    # Parameters for filtering of top DEGs
    fdr = .05
    lfc = .5
    # Covariate setups to test
    covs_l = ['+pair+percent_mito+percent_ribo_p',]
    # Using only 1 job
    jobs = 1
    print(f'Using {jobs} jobs')
    # Submit job to MASt and save results to an excel file
    for covs in covs_l:
        for de, top, by in bmast.mast(
            adata_t, keys, group, fdr, lfc, covs, min_perc=min_perc,
            on_total=False, jobs=jobs, bys=bys,
        ):
            fname = out(
                f'interim_data/singler/mast/by_timepoint/'
                f'de.{tp}.{by}.{group}{covs}'
            ) 
            bmast.mast_to_excel(de, fname, top=top, top_prefix=f'{lfc}')

#%%
# Helper functions for GO enrichment
def profile_disambiguate(
    org: str,
    query_genes: List[str],
    ordered: bool,
    no_iea: bool,
    base_url: str = None,
    **kwargs,
) -> pd.DataFrame:
    """ Running enrichment with gProfiler with automatic resolution
        of ambiguous annotations.
    """
    from gprofiler import GProfiler
    gp = GProfiler(
        base_url=base_url,
        return_dataframe=True,
    )
    print('> Pre-profiling...')
    pre = gp.profile(
        organism=org, query=query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )
    meta = gp.meta['genes_metadata']
    print(
        f'  Failed: {len(meta["failed"])},'
        f' Ambiguous: {len(meta["ambiguous"])}'
    )
    print('  ', ' '.join(meta['ambiguous'].keys()))
    best = {
        gene: max(
            meta['ambiguous'][gene],
            key=lambda x: x['number_of_go_annotations']
        )['gene_id']
        for gene in meta['ambiguous'].keys()
    }
    print(f'  Disambiguated: {len(best)}')
    final_query_genes = [
        gene if gene not in best else best[gene]
        for gene in query_genes
    ]
    print(f'  Final profiling...')
    final = gp.profile(
        organism=org, query=final_query_genes, all_results=False, 
        ordered=ordered, no_iea=no_iea, **kwargs,
    )   
    # Fewer ambiguous genes now
    meta = gp.meta['genes_metadata']
    try:
        assert len(meta['ambiguous']) == 0
    except AssertionError:
        print('  Some genes have still ambiguous annotation')
    return final

def tl_gprof_excel(
    phenos: Dict[str, pd.DataFrame],
    fname: str,
):
    """ Save gProfiler results to Excel. """
    import pandas as pd
    writer = pd.ExcelWriter(
        f'{fname}.xlsx', engine='xlsxwriter'
    )
    for s, data in phenos.items():
        data.to_excel(writer, sheet_name=s, index=False)
    writer.save()

#%%
# Compute GO enrichment of DEGs
base_url = 'https://biit.cs.ut.ee/gprofiler_archive3/e98_eg45_p14/'
for tp in ['70d', '150d']:
    group = 'genotype'
    by = key
    fdr = .05
    lfc = .2
    covs = '+pair+percent_mito+percent_ribo_p'
    fname = out(
        f'interim_data/singler/mast/by_timepoint/'
        f'de.{tp}.{by}.{group}{covs}.{lfc}.top.xlsx'
    ) 
    top = pd.read_excel(fname, sheet_name=None)
    for cell_type in top.keys():
        res = {}
        for condition in top[cell_type].columns:
            genes = list(top[cell_type][condition].dropna())
            meta = None
            if len(genes) > 0:
                res[condition] = profile_disambiguate(
                    org='hsapiens', query_genes=genes,
                    ordered=False, no_iea=True, base_url=base_url,
                    no_evidences=False, user_threshold=.05,
                    significance_threshold_method='fdr',
                )
        if len(res) > 0: 
            fname = out(
                f'interim_data/singler/mast/by_timepoint/gprof/'
                f'gprof.de.{tp}.{by}.{cell_type}.{group}{covs}.{lfc}'
            ) 
            tl_gprof_excel(res, fname)


#plot heatmaps of genes of interest

#%% subset Excitatory neurons
adataEN =  adata[adata.obs["nowakowski.fine.noglyc_unmapped"]== "EN"]
adataEN.obs
adataENcase = adataEN[adataEN.obs['genotype']== 'Case']
adataENcase
adataENcontrol = adataEN[adataEN.obs['genotype']== 'Control']

# %%
var_names = {
    'Up at both ': set (['TCF4', 'ZNF667', 'ZNF528', 'SOX4', 'SLITRK5', 'EPHA4', 'CNTN4', 'DPP6', 'MIR124-1HG', 'MIR9-1HG', 'LINC01551', 'LINC00685', 'LINC00461']),
    'Down at both' : set (['PAK3', 'CALY', 'AAK1', 'SYNPR', 'GRIA2', 'NRP2', 'SYT10', 'COMT', 'PI4KA', 'LZTR1', 'PCDH10', 'THAP7']),
    'Only70Up': set(['ZFPM2', 'TRIM28', 'TP73', 'SMC3', 'SLF1', 'SFPQ', 'PCP4', 'NFIA', 'NDST3', 'LTBP4', 'KMT2B', 'JUND', 'JUN', 'JPT1', 'IGDCC3', 'HLA-DQB1', 'HACD3', 'FKBP4', 'EBF2', 'DUS1L', 'CDKN1C', 'ATXN2', 'H3-3B', 'H3-3A', 'H2AZ1', 'H1-3', 'H1-0', 'GABRG1', 'GABRA2', 'FSTL5', 'GABRG3']),
    'Only70Down': set(['SYAP1', 'SLC32A1', 'RTN4R', 'RTN4', 'RPS4X', 'NRXN2', 'NDFIP1', 'GRIPAP1', 'GRIA4', 'GPM6A', 'GAD2', 'FZD3', 'ERBB4', 'EFNB1', 'DMD', 'ATP6AP2', 'ANK3', 'SCARB2', 'LAPTM4A', 'CTSF', 'AP1S2', 'HLA-C', 'DYNC1LI2', 'DYNC1H1', 'ATP6V0A1', 'ATP6AP1', 'TMEM97', 'SEC62', 'ARL6IP1']),
    'Only150Up': set([ 'TUBB3', 'STMN2', 'STMN1',  'SLITRK1', 'SEMA7A', 'POU3F2', 'PLXNA4',  'MEF2C', 'MAPT', 'MAP1B', 'EPHB2', 'DPYSL3', 'DCX', 'CNTN2', 'CNTN1', 'CACNA1A', 'MEF2C', 'GRIN2B', 'GRIA4', 'GRIA3', 'CACNB4', 'CACNA1A']),
    'Only150DDown': set(['SYT4', 'SNAP25', 'RELN', 'GUCY1B1', 'GRM7', 'GRM1', 'GRID2', 'GJD2', 'GABRG2', 'GABRA1', 'SCN2A', 'DCC', 'CHRNB1', 'CALB2', 'CACNG4', 'AMPH', 'CNTNAP2']),
    'Down70 up150': set(['BHLHE22','DDX18','FABP7','FZD3','GPM6A','GPM6B','GRIA4','MEIS2','MIR100HG','NOVA1','RNF24','RNMT','SAT1','ZNF431','ZNF738','ZRANB2']),
    'Up70Down150': set (['ANKRD11','ARHGAP21','ARL6IP5','CAMK2D','CHD5','CKB','CNTNAP2','EBF2','EDIL3','EFNB2','FAM43A','FSTL5','H1-0','H3-3B','HACD3','HNRNPA2B1','IAH1','ID3','KC6','MAZ','NDST3','NHLH2','NR2F1','OCIAD2','PCDH9','RALYL','RPS4Y1','RSPO3','SCG5','SECISBP2','SEMA6A'])
}
# %%
sc.pl.heatmap(adataEN, var_names, groupby= 'genotype_timepoint', dendrogram=True, standard_scale= 'var', save= "heatmapDEG.eps")
# %%
ax = sc.pl.dotplot(adataEN, var_names, groupby='genotype_timepoint', dendrogram=True,
                   standard_scale='var', smallest_dot=40, color_map='Blues', figsize=(8,5),categories_order= ('Case_70d', 'Case_150d', 'Control_70d', 'Control_150d'), save = "dotplotDEG.eps")
# %%
gs = sc.pl.matrixplot(adataEN, var_names, groupby='genotype_timepoint',  categories_order= ('Case_70d', 'Case_150d', 'Control_70d', 'Control_150d'), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotDEG_bwr.eps")
gs = sc.pl.matrixplot(adataENcase, var_names, groupby='genotype_timepoint',  categories_order= ('Case_70d', 'Case_150d'), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotDEGcase_bwr.eps")
gs = sc.pl.matrixplot(adataENcontrol, var_names, groupby='genotype_timepoint',  categories_order= ('Control_70d', 'Control_150d'), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotDEGcontrol_bwr.eps")


# %%
import pandas as pd
import numpy as np

up70Dcontrol= pd.read_csv(data('up70Dcontrol.csv'), skip_blank_lines=True, na_values="", na_filter= True)
up150Dcontrol =  pd.read_csv(data('up150Dcontrol.csv'), skip_blank_lines=True, na_values="", na_filter= True)
unchangedcontrol =  pd.read_csv(data('unchangedcontrol.csv'), skip_blank_lines=True, na_values="", na_filter= True)


up70Dcase = pd.read_csv(data('up70Dcase.csv'), skip_blank_lines=True, na_values="", na_filter= True)
up150Dcase = pd.read_csv(data('up150Dcase.csv'), skip_blank_lines=True, na_values="", na_filter= True)
unchangedcase = pd.read_csv(data('unchangedcase.csv'), skip_blank_lines=True, na_values="", na_filter= True)

print (up70Dcontrol)
#%%
var_namescontrol = {
 'up70DIVcontrol': up70Dcontrol['up70Dcontrol'].to_list(),
 'up150DIVcontrol': up150Dcontrol ['up150Dcontrol'].to_list(),
 'unchangedcontrol': unchangedcontrol ['unchangedcontrol'].to_list()
}

var_namescase ={
'up70DIVcase': up70Dcase['up70Dcase'].to_list(),
'up150DIVcase': up150Dcase['up150Dcase'].to_list(),
'unchangedcase': unchangedcase ['unchangedcase'].to_list()
}
#%%
up70divcontrol =  up70Dcontrol['up70Dcontrol'].to_list()
up150DIVcontrol= up150Dcontrol ['up150Dcontrol'].to_list()
unchangedcontrol = unchangedcontrol['unchangedcontrol'].to_list()
#%%
gs = sc.pl.matrixplot(adataENcontrol, var_namescontrol, groupby='genotype_timepoint', categories_order= ("Control_70d", "Control_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols= None, cmap = 'bwr', save = "matrixplotControl70150d_bwr.eps")

gs= sc.pl.matrixplot(adataENcase, var_namescase, groupby='genotype_timepoint', categories_order= ("Case_70d", "Case_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols = None, cmap = 'bwr', save = "matrixplotCase70150d_bwr.eps")

#%%
gs = sc.pl.matrixplot (adataENcase, up70divcontrol , groupby='genotype_timepoint', categories_order= ("Case_70d", "Case_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols = None, cmap = 'bwr', save = "matrixplotcontroldeccase_bwr.eps")
gs = sc.pl.matrixplot (adataENcase, up150DIVcontrol, groupby='genotype_timepoint', categories_order= ("Case_70d", "Case_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols = None, dendrogram= True, cmap = 'bwr', save = "matrixplotcontroldeccase2_bwr.eps")

#%%
gs = sc.pl.matrixplot (adataENcontrol, up70divcontrol , groupby='genotype_timepoint', categories_order= ("Control_70d", "Control_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols = None, cmap = 'bwr', save = "matrixplotcontroldeccase_bwr.eps")
gs = sc.pl.matrixplot (adataENcontrol, up150DIVcontrol, groupby='genotype_timepoint', categories_order= ("Control_70d", "Control_150d"), standard_scale='var', swap_axes= True, figsize= (5,30), gene_symbols = None, cmap = 'bwr', save = "matrixplotcontroldeccase_bwr.eps")


#%% only top genes
    'up70DIV case': set(['TTR' , 'AL592463.1' , 'TP73' , 'NFIA' , 'IGFBP2' , 'ZNF208' , 'MSMO1' , 'LHX1' , 'MAB21L1' , 'CNTNAP2' , 'LHX1-DT' , 'KCNQ1OT1' , 'NNAT' , 'BCL11B' , 'SQLE' , 'SSTR2' , 'FDPS' , 'EBF3' , 'BCL11A' , 'ACAT2' , 'ANKRD36C' , 'KHDRBS3' , 'ZIM2' , 'SAMD3' , 'FDFT1'  , 'TBR1' , 'HMGCS1' , 'IGF2BP2' , 'EMX2' , 'MIMT1' ]),
    'up150DIVcase': set(['POU3F2' , 'PLCG2' , 'CADM2' , 'ID2' , 'FABP7' , 'NTM' , 'SATB2-AS1' , ' SATB2 ' , ' POU3F3 ' , ' DOK5 ' , ' MEF2C ' , ' NECTIN3 ' , ' ENC1 ' , ' ARPP21 ' , ' MEIS2 ' , ' LINC01102 ' , ' IRX3 ' , ' H1-4 ' , ' MIR100HG ' , ' BHLHE22 ' , ' STARD4-AS1 ' , ' TAFA1 ' , ' BCL6 ' , ' PBX1 ' , ' UACA ' , ' FAM126A ' , ' FRMD4B ' , ' ARL4C ' , ' BTG1 ' , ' MN1 ' ]),
}

var_namescontrol = {
   

gs = sc.pl.matrixplot(adataENcase, var_namescase, groupby='genotype_timepoint',  categories_order= ('Case_70d', 'Case_150d'), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotDEGcase70150dtop_bwr.eps")
gs = sc.pl.matrixplot(adataENcontrol, var_namescontrol, groupby='genotype_timepoint',  categories_order= ('Control_70d', 'Control_150d'), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotDEGcontrol70150top_bwr.eps")
gs = sc.pl.matrixplot(adataENcase, var_namescontrol, groupby='genotype_timepoint',  categories_order= ('Case_70d', 'Case_150d' ), standard_scale='var', swap_axes= True, figsize= (5,30), vmin= -2, vmax=2, cmap = 'bwr', save = "matrixplotcontrolDEGinCase70150top_bwr.eps")

# %%
import matplotlib
from matplotlib import pyplot as plt
import numpy as np
from matplotlib_venn import venn2
from matplotlib_venn import venn3
venn3 ([(up70Dcontrol['up70Dcontrol'].to_list()), 
       (up150Dcontrol ['up150Dcontrol'].to_list()), 
       (unchangedcontrol ['unchangedcontrol'].to_list()), 
       (up70Dcase['up70Dcase'].to_list()), 
       (up150Dcase ['up150Dcase'].to_list()), 
       (unchangedcase ['unchangedcase'].to_list()), 
    ],
       set_labels=('Up70Dcontrol', 'Up150Dcontrol', 'Unchanged control', 'Up70Dcase', 'Up150Dcase', 'Unchangedcase')
     )

# %%
plotdata = pd.read_csv(data('genes70and150DIV.csv'), skip_blank_lines=True, na_values="", na_filter= True)
plotdata
plotdata_transposed = plotdata.T
plotdata_transposed


# %%
