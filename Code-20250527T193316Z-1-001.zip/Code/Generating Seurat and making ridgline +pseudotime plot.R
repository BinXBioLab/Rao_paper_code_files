setwd ("E:/Sneha/RNAseq/ScSeq/wgcna")


# # Load libraries
# library(liger)
library(Seurat)
library(ggplot2)
library(cowplot)
# library(arrow)
# library(feather)
# library(scWGCNA)
# library(WGCNA)
# library(tidyverse)
# library (dplyr)
# library(WGCNA)
# enableWGCNAThreads(20)
# # feather library became obsolete during the project
# # it got replaced by arrow library that provides the updated
# # `read_feather()` function
library(arrow)
# theme_set(theme_cowplot())

# Uncomment the line corresponding to the dataset to batch-correct with LIGER

prefix <- 'AGGR01'


### Generate seurat Object from coutns matrix

# Load counts matrix exrtacted from adata
data <- as.data.frame(read_feather("C:/Users/Sneha/Desktop/Manuscript files/Code and supp files/scSeq code-20230221T012528Z-001/scSeq code/AGGR01_mapped.counts.fth"))
rownames(data) <- data[,1]
data <- data[,-1]

data <- read.csv("C:/Users/Sneha/Desktop/Manuscript files/Code and supp files/scSeq code-20230221T012528Z-001/scSeq code/AGGR01_mapped.counts.fth")
rownames(data) <- data[,1]
data <- data[,-1]
# Load cell annotations
meta.data <- read.table(
  sep=',',
  header=TRUE,
  check.names=FALSE,
  paste('E:/Sneha/RNAseq/ScSeq/wgcna/obs.csv'),
  row.names=1,
)

# Create Seurat object from counts matrix
sdata <- CreateSeuratObject(
  t(data),
  project=prefix,
  assay='RNA',
  meta.data=meta.data,
)

saveRDS(sdata, file=paste(prefix, '.seurat.rds', sep='')) 
# Finad variable features: 

sdata <- FindVariableFeatures(sdata, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(sdata), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sdata)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 + plot2


# # Scale the data
# all.genes <- rownames(sdata)
# sdata <- ScaleData(sdata, features = all.genes)
# 
# #Plot PCA
# sdata <- RunPCA(sdata, features = VariableFeatures(object = sdata))
# print(sdata[["pca"]], dims = 1:5, nfeatures = 5)
# VizDimLoadings(sdata, dims = 1:2, reduction = "pca")
# DimPlot(sdata, reduction = "pca")
# 
# # #set idents from metadata (equivalent to obs in anndata)
# colnames(sdata[[]])
# Idents (sdata) <- 'nowakowski.fine.noglyc_unmapped'
# levels(sdata)
# # # SetIdent(sdata, save.name= "umap", value = "leiden_final" )
# # # levels(sdata)
# # # head(Idents(sdata))

head(Idents(sdata), 5)

sdata <- RunUMAP(sdata, dims = 1:10)
DimPlot(sdata, reduction = "umap")


saveRDS(sdata, file=paste(prefix, '.seurat.final.rds', sep='')) 
#sdata = readRDS(file=paste(prefix, '.seurat.final.rds', sep=''))

#subset by timepoint
timepoint = "70d"

sdata_sub<- subset(x = sdata, subset = timepoint == "70d")
DimPlot(sdata_sub, reduction = "umap")

saveRDS(sdata_sub, file=paste(prefix, timepoint, '.seurat.final.rds', sep='.')) 


# Load pseudotime infor for cells

pseudo= read.csv ("E:/Sneha/RNAseq/ScSeq/Ridge plot/monocle.6.pseudotime.csv", header= TRUE, row.names = 1)

# add pseudotime to Seurat metadata
sdata <- AddMetaData(
  object = sdata,
  metadata = pseudo,
  col.name = 'pseudotime'
)
head(x = sdata[[]])



saveRDS(sdata, "AGGr01.seurat.final.pseudo.70D.rds")


# extract only EN lineage

sdata_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
(DimPlot(sdata_sub, reduction = "umap")+ scale_color_manual(values= colors))

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)

# subset case and control separately and run above analysis
sdata_case = subset(x = sdata, subset = genotype == "Case")
sdata_control = subset(x = sdata, subset = genotype == "Control")

# prefix = sdata_case
prefix= sdata_case

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)
