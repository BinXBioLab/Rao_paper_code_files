# install.packages('BiocManager', dependencies=TRUE, repos='http://cran.rstudio.com/')
# install.packages('BiocStyle')
# BiocManager::install(version = '3.11')
# BiocManager::install('MAST') 
# install.packages('feather', dependencies=TRUE, repos='http://cran.rstudio.com/')

setwd ('C:/Users/Nikon/Desktop/Sneha/MAST')


rm(list=ls())
library(MAST)
library(feather)
options(mc.cores=1)



#args <- commandArgs(trailingOnly=TRUE)

args_script_1<- 'mat.fth'
args_script_2 <- 'cdat(1).csv'
args_script_3 <- 'condition'
args_script_4 <- '~group + n_genes + batch'

print(paste('Reading matrix', args_script_1, sep=' '))
mat <- as.data.frame(read_feather(args_script_1))
rownames(mat) <- mat[,1]
mat <- mat[,-1]

print(paste('Reading cdat', args_script_2, sep=' '))
cdat <- read.csv(args_script_2, check.names=FALSE, row.names=1)
fdat <- as.data.frame(colnames(mat))
row.names(fdat) <- fdat[,1]

raw <- FromMatrix(t(mat), cdat, fdat)
rm(mat)

de <- NULL
print(paste('Testing', args_script_3, sep=' '))
test <- cdat[,args_script_3]
for (g in factor(sort(unique(test)))) {
  print(paste('Analyzing group', g, sep=' '))
  group <- test
  levels(group) <- factor(c(levels(group), 'REST'))
  group[group != g] = 'REST'
  group <- as.factor(group)
  group <- relevel(group, 'REST')
  colData(raw)$group <- group
  
  #    zlmCond <- zlm(~group + n_genes, raw)
  print(paste('Model:', args_script_4, sep=' '))
  zlmCond <- zlm(as.formula(args_script_4), raw)
  
  print('Preparing results')
  summaryCond <- summary(zlmCond, doLRT=paste('group', g, sep=''))
  summaryDT <- summaryCond$datatable
  fcHurdle <- merge(
    summaryDT[
      contrast==paste('group', g, sep='')
      & component=='H',.(primerid, `Pr(>Chisq)`)
    ],
    summaryDT[
      contrast==paste('group', g, sep='')
      & component=='logFC', .(primerid, coef, ci.hi, ci.lo)
    ],
    by='primerid'
  )
  fcHurdle[,fdr:=p.adjust(`Pr(>Chisq)`, 'fdr')]
  g_de <- fcHurdle[, c(
    'primerid', 'coef', 'ci.hi', 'ci.lo', 'Pr(>Chisq)', 'fdr'
  )]
  colnames(g_de) <- c(
    'primerid', paste(g, 'coef', sep='_'), paste(g, 'ci.hi', sep='_'),
    paste(g, 'ci.lo', sep='_'), paste(g, 'pval', sep='_'),
    paste(g, 'fdr', sep='_')
  )
  if (is.null(de)) {
    de <- g_de
  } else {
    de <- merge(de, g_de, by='primerid')
  }
}
print(paste('Writing result', args_script_5, sep=' '))
write.csv(de, "de-condition+batch.csv", quote=FALSE, row.names=FALSE)

