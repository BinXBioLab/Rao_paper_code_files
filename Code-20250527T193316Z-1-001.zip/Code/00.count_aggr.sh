# Using cellranger 5.0.1 from fbrundu/cellranger:5.0.1
docker pull fbrundu/cellranger:5.0.1

# Download reference
curl -O https://cf.10xgenomics.com/supp/cell-exp/refdata-gex-GRCh38-2020-A.tar.gz
gunzip refdata-gex-GRCh38-2020-A.tar.gz
tar xvf refdata-gex-GRCh38-2020-A.tar

# For each sample to recount

## Download the fastqs
aws s3 cp s3://fb2505-2019-xu-org/data/raw/190906_JOSEPH_SNEHA_6_HUMAN_10X/JS001/fastqs.tar ./
## Run cellranger count
docker run -v $(pwd):/opt/data --entrypoint /bin/bash -it fbrundu/cellranger:5.0.1
### Within the container (for each sample - modify sample name accordingly)
cd /opt/data
cellranger count --id=JS001 --fastqs=/opt/data/JS001_old/fastqs --transcriptome=/opt/data/refdata-gex-GRCh38-2020-A
## Upload recounted samples
aws s3 sync JS001 s3://fb2505-2019-xu-org/data/raw/190906_JOSEPH_SNEHA_6_HUMAN_10X/JS001_cellranger_5.0.1

# Prepare data for aggregation
for s in 1 2 3 4 5 6
do aws s3 cp s3://fb2505-2019-xu-org/data/raw/190906_JOSEPH_SNEHA_6_HUMAN_10X/JS00"$s"_cellranger_5.0.1/molecule_info.h5 JS00"$s".molecule_info.h5
done

for s in 1 2 3 4 5 6
do
    aws s3 cp s3://fb2505-2019-xu-org/data/raw/201124_JOSEPH_SNEHA_6_HUMAN_10X/JS300"$s"/analysis/201124_JOSEPH_SNEHA_6_HUMAN_10X-JS300"$s"-cellranger-count-default/JS300"$s"_cellranger_count_outs.tar - | tar x JS300"$s"_cellranger_count_outs/molecule_info.h5
    mv JS300"$s"_cellranger_count_outs/molecule_info.h5 JS300"$s".molecule_info.h5
done

echo 'library_id,molecule_h5,timepoint,genotype,pair,sample_id
JS001,/opt/data/JS001.molecule_info.h5,70d,Control,1,Q2
JS002,/opt/data/JS002.molecule_info.h5,70d,Case,1,Q1
JS003,/opt/data/JS003.molecule_info.h5,70d,Control,2,Q5
JS004,/opt/data/JS004.molecule_info.h5,70d,Case,2,Q6
JS005,/opt/data/JS005.molecule_info.h5,70d,Control,3,QR20
JS006,/opt/data/JS006.molecule_info.h5,70d,Case,3,QR27
JS3001,/opt/data/JS3001.molecule_info.h5,150d,Control,1,Q2
JS3002,/opt/data/JS3002.molecule_info.h5,150d,Case,1,Q1
JS3003,/opt/data/JS3003.molecule_info.h5,150d,Control,2,Q5
JS3004,/opt/data/JS3004.molecule_info.h5,150d,Case,2,Q6
JS3005,/opt/data/JS3005.molecule_info.h5,150d,Control,3,QR20
JS3006,/opt/data/JS3006.molecule_info.h5,150d,Case,3,QR27' > aggr.csv

# Save MD5 for future testing
md5sum *h5 *csv > input.md5

# mapped (default): For each library type, subsample reads from higher-depth GEM wells until they all have, on average, an equal number of reads per cell that are confidently mapped to the transcriptome (Gene Expression) or assigned to known features (Feature Barcode Technology). If Targeted Gene Expression libraries are included, then normalization is performed on the basis of average reads per cell mapped confidently to the targeted transcriptome. The subsampling rates for Targeted Gene Expression libraries are all multiplied by 2 (provided all samples can achieve that depth). This is consistent with sequencing depth recommendations and is also done to avoid removing large fractions of reads from targeted libraries whenever they are combined with whole transcriptome libraries.

## Within the container
## Aggregate and normalize each cell sequencing depth
cellranger aggr --id=AGGR01_mapped --csv=aggr.csv --normalize=mapped
## Aggregate without normalizing each cell sequencing depth
cellranger aggr --id=AGGR01_unmapped --csv=aggr.csv --normalize=none

# Save results
aws s3 sync AGGR01_mapped s3://fb2505-2019-xu-org/data/raw/210107_AGGR01_mapped
aws s3 sync AGGR01_unmapped s3://fb2505-2019-xu-org/data/raw/210107_AGGR01_unmapped