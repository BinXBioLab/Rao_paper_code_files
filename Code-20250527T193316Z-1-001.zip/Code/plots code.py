#%%
from email import header
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

#%%

data = pd.DataFrame({'Timepoint': ['70d', '150d'],
                    "EN": [0.23, 0.15],
                    "RG-early": [0.22, 0.01],
                    "IPC-nEN": [0.14, 0.05],
                    "Choroid": [0.08, 0.01],
                    "IN-STR": [0.07, 0.10],
                    "nEN-early": [0.06, 0.03],
                    "RG-div": [0.05, 0.04],
                    "RG-late": [0.05, 0.12],
                    "MGE-RG": [0.03, 0.02],
                    "IPC-div": [0.02, 0.00],
                    "IN-CTX": [0.01, 0.19],
                    "nIN": [0.01, 0.05],
                    "nEN-late": [0.01, 0.04],
                    "MGE-IPC": [0.01, 0.05],
                    "MGE-RG_IPC-div": [0.00, 0.03],
                    "Astrocyte": [0.00,	0.09]})




# %%
# plot data in stack manner of bar type
comp= data.plot(x= "Timepoint", kind='bar', stacked=True,
        title='Cell type composition')
plt.savefig("composition.pdf", format= "pdf")


# %%
import scanpy as sc
#adata = sc.read("E:/Sneha/RNAseq/scseq/AGGR01_mapped/AGGR01_mapped.preqc.h5ad")
adata = sc.read("E:/Sneha/RNAseq/scseq/AGGR01_mapped/AGGR01_mapped.final.h5ad")

# %%
sc.pl.violin(
    adata,
    keys=[
            'percent_ribo_p'],
    groupby='batch',
    stripplot= False,
    cut=0,
    save= 'percentribo.pdf',
)

# %%
sc.pl.umap(
    adata,
    color=[
        'hallmark_apoptosis',
    ],
    cmap='viridis',
    save='.hallmarks.pdf',
    ncols=5,
)

#%%
sc.pl.violin(
    adata,
    keys=[
            'hallmark_apoptosis'],
   groupby= 'timepoint',
   stripplot= False,
        save='violintimepoint.apoptosis.hallmarks.pdf',
)

#%%
#%%
sc.pl.violin(
    adata,
    keys=[
            'hallmark_hypoxia'],
   groupby= 'timepoint',
   stripplot= False,
        save='violintimepoint.hypoxia.hallmarks.pdf',
)

# %%

import seaborn as sns
import matplotlib.pyplot as plt

# %%
hypoxia = adata.obs
hypoxia
# %%
hypo
# %%
sns.distplot(a=hypoxia, hist=False)
# %%
rp = sns.FacetGrid(hypoxia, hue="timepoint", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_apoptosis', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allapoptosis.timepoint.ridge.pdf", format = "pdf")

# %%
rp = sns.FacetGrid(hypoxia, hue="timepoint", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_hypoxia', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allhypoxia.timepoint.ridge.pdf", format = "pdf")

# %%
rp = sns.FacetGrid(hypoxia, row="timepoint", hue="genotype", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_apoptosis', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allapoptosis.timepoint.genotype.ridge.pdf", format = "pdf")


# %%
rp = sns.FacetGrid(hypoxia, row="timepoint", hue="genotype", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_hypoxia', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allhypoxia.timepoint.genotype.ridge.pdf", format = "pdf")

# %%
# %%
rp = sns.FacetGrid(hypoxia, hue="genotype", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_apoptosis', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allapoptosis.genotype.ridge.pdf", format = "pdf")

# %%
rp = sns.FacetGrid(hypoxia, hue="genotype", aspect=5, height=1.25)
  
rp.map(sns.kdeplot, 'hallmark_hypoxia', clip_on=False,
       shade=True, alpha=0.7, lw=4, bw=.2)
  
rp.map(plt.axhline, y=0, lw=4, clip_on=False)
plt.savefig ("allhypoxia.genotype.ridge.pdf", format = "pdf")

# %%
# Plot clustering with selected resolution through UMAP
sc.pl.umap(
    adata,
    color= hypoxia[["leiden_final"]],
    save='.leiden.UMAP.pdf',
    legend_loc='on data',
)

# %%
del_genes = 'DGCR6 PRODH DGCR2 ESS2 TSSK2 GSC2 SLC25A1 CLTCL1 HIRA MRPL40 C22orf39 UFD1 CDC45 CLDN5 SEPTIN5 GP1BB TBX1 COMT GNB1L RTL10 TXNRD2 DGCR8 TRMT2A mir-4761 mir-1286 ARVCF USP41 TANGO2 LOC101927859 RTN4R DGCR6L mir-185 mir-6816 RANBP1 ZDHHC8 CCDC188 LINC00896 mir-1306 mir-3618 ZNF74 SCARF2 KLHL22 MED15 SERPIND1 PI4KA SNAP29 CRKL AIFM3 LZTR1 THAP7 P2RX6 SLC7A4 mir-649 LRRC74B HIC2'.split()
#%%
# Check which genes are missing in our data
not_found = list(set(del_genes) - set(adata.raw.var_names))

#%%
# Remove missing genes keeping the original order
del_genes = [g for g in del_genes if g in adata.raw.var_names]
sc.pl.dotplot(
    adata,
    var_names=del_genes,
    color_map='viridis',
    use_raw=True,
    save='.22q11.del_genes.batch.pdf',
    groupby='batch',
    mean_only_expressed=True,
)
# %%
# Set annotation name
key = 'nowakowski.fine.noglyc_unmapped' 

#%%
# Define color palette for cell type annotation
import seaborn as sns
palette = sns.color_palette('Set2') + '#235b54 #3998f5 #991919 #c56133 #2f2aa0 #b732cc #f07cab #d30b94 #c3a5b4 #5d4c86'.split()
sns.palplot(palette)


#%%
sc.pl.umap(
    adata,
    color= adata.obs[['nowakowski.fine.noglyc_unmapped' ]],
    palette= palette,
    save='.annotation.UMAP.pdf',
    legend_loc='right',
)


# %%
# Plot annotations UMAPs
sc.pl.umap(
    adata,
    color=list(refs.keys()),
    cmap='viridis',
    ncols=1,
    # save='.annotation.unmapped.pdf',
)

# %%
from natsort import natsorted
nmarkers = natsorted(list(set(['Q1', 'Q2', 'Q5', 'Q6', 'QR20', 'QR27'
]) & set(adata.obs["sample_id"])))

# %%
sc.pl.umap(
    adata,
    color= nmarkers,
    save='.leiden.pdf',
    legend_loc='toright',
)
# %%
