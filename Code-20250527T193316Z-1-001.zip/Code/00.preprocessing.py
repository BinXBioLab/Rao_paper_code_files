#%%
# Load modules
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
from scipy import sparse
import seaborn as sns
import sys

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Define samples
samples = ['AGGR01_mapped', 'AGGR01_unmapped']
prefix = samples[1]
prefix

#%%
# Not used, custom functions added to code
# os.chdir('../..')
# sys.path.append(os.path.abspath('..'))
# from fbrundu_sclib import *

#%%
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

#%%
# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = 'data'
out_dir = os.path.join('results', 'v01', prefix)

data = fullpath_closure(data_dir)
out = fullpath_closure(out_dir)

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

#%%
# Load h5 file from cellranger output
adata = sc.read_10x_h5(
    data(f'{prefix}.filtered_feature_bc_matrix.h5'),
)

#%%
# Some gene symbols might not be unique. Add a suffix to each
# occurrence of them
adata.var_names_make_unique()
adata.var

#%%
# Update gene symbols with different Ensembl version
mapping = pd.read_csv(
    data('hs.GRCh38.102.ens_hgnc.txt'), sep='\t', index_col=0, header=None,
)
mapping.index.name = 'ENS'
mapping.columns = ['SYMBOL']
mapping.head()

#%%
# Check which genes have no mapping in the current annotation
unmapped = (set(adata.var['gene_ids'].values) - set(mapping.index))
print(len(unmapped))
adata.var.loc[adata.var['gene_ids'].isin(list(unmapped))].to_csv(
    data(f'{prefix}.genes_to_check.csv')
)

#%%
# If a gene has no mapping in the current Ensembl version, add suffix
adata.var['symbol_ensembl_102'] = [
    mapping.loc[adata.var.loc[g, 'gene_ids'], 'SYMBOL']
    if adata.var.loc[g, 'gene_ids'] in mapping.index else f'{g}.retired'
    for g in adata.var.index
]

#%%
# Use new symbol as main gene index
adata.var = adata.var.reset_index().set_index('symbol_ensembl_102')
adata.var.columns = ['symbol_original'] + list(adata.var.columns[1:])
adata.var_names_make_unique()

#%%
# Save gene data
adata.var.to_csv(out('interim_data/qc/var.mapped.ensembl_102.csv'))
adata.var

#%%
# Optional: transform raw counts matrix from sparse to dense matrix
# adata.X = adata.X.todense()

#%%
adata

#%%
# Save current AnnData as h5ad file (first snapshot)
adata.write(data(f'{prefix}.raw.h5ad'))

#%%
# Load h5ad file
adata = sc.read(data(f'{prefix}.raw.h5ad'))
adata

#%%
# Add additional cell annotation (i.e., batch, pair, genotype, timepoint
# and sample ID)
if prefix in ['AGGR01_mapped', 'AGGR01_unmapped']:
    adata.obs['batch'] = adata.obs_names.str.split('-').str[1].map({
        '1': 'JS001',
        '2': 'JS002',
        '3': 'JS003',
        '4': 'JS004',
        '5': 'JS005',
        '6': 'JS006',
        '7': 'JS3001',
        '8': 'JS3002',
        '9': 'JS3003',
        '10': 'JS3004',
        '11': 'JS3005',
        '12': 'JS3006',
     })
    adata.obs['pair'] = adata.obs_names.str.split('-').str[1].map({
        '1': '1',
        '2': '1',
        '3': '2',
        '4': '2',
        '5': '3',
        '6': '3',
        '7': '1',
        '8': '1',
        '9': '2',
        '10': '2',
        '11': '3',
        '12': '3',
    })
    adata.obs['genotype'] = adata.obs_names.str.split('-').str[1].map({
        '1': 'Control',
        '2': 'Case',
        '3': 'Control',
        '4': 'Case',
        '5': 'Control',
        '6': 'Case',
        '7': 'Control',
        '8': 'Case',
        '9': 'Control',
        '10': 'Case',
        '11': 'Control',
        '12': 'Case',
    })
    adata.obs['timepoint'] = adata.obs_names.str.split('-').str[1].map({
        '1': '70d',
        '2': '70d',
        '3': '70d',
        '4': '70d',
        '5': '70d',
        '6': '70d',
        '7': '150d',
        '8': '150d',
        '9': '150d',
        '10': '150d',
        '11': '150d',
        '12': '150d',
    })
    adata.obs['sample_id'] = adata.obs_names.str.split('-').str[1].map({
        '1': 'Q2',
        '2': 'Q1',
        '3': 'Q5',
        '4': 'Q6',
        '5': 'QR20',
        '6': 'QR27',
        '7': 'Q2',
        '8': 'Q1',
        '9': 'Q5',
        '10': 'Q6',
        '11': 'QR20',
        '12': 'QR27',
    })

#%%
# Update first snapshot (raw h5ad)
adata.write(data(f'{prefix}.raw.h5ad'))

#%%
adata.obs

#%%
# Plot genes with highest expression in the dataset
sc.pl.highest_expr_genes(adata, n_top=40, save='.raw_top40.pdf');

#%%
from typing import List
def adata_var_get(
    _adata: sc.AnnData,
    prefix_l: List[str] = None,
    gene_l: List[str] = None,
) -> sc.AnnData:
    """Returns AnnData containing genes indexed by prefix
       or exact gene symbol.
    """
    if prefix_l is None:
        prefix_l = []
    if gene_l is None:
        gene_l = []
    vars_l = set()
    for prefix in prefix_l:
        vars_l |= set(_adata.var.index[_adata.var.index.str.startswith(prefix)])
    vars_l |= set(_adata.var.index[_adata.var.index.isin(gene_l)])
    if vars_l:
        return _adata[:, list(vars_l)].copy()
    else:
        return None

#%%
# Get AnnData for ribosomal protein genes
ribo_p = adata_var_get(adata, prefix_l=['RPL', 'RPS', 'MRPL', 'MRPS'])
# ribo_r = adata_var_get(adata, gene_l=['RN45S', 'RN4.5S'])
ribo_p.shape
# ribo_r.shape

#%%
# Compute QC metric: counts deriving from ribosomal protein genes
adata.obs['n_counts_ribo_p'] = ribo_p.X.sum(axis=1)

#%%
# Check if there are counts associated with spike-ins
spike_prefix = 'ercc-'
adata.var_names[adata.var_names.str.lower().str.startswith(spike_prefix)]

#%%
# Check presence of genes in mitochondrial chromosome
mito_prefix = 'mt-'
adata.var_names[adata.var_names.str.lower().str.startswith(mito_prefix)]

# %%
# In case spike-ins are present
# spike_prefix = 'ercc-'
# spike = adata.var_names[
#     adata.var_names.str.lower().str.startswith(spike_prefix)
# ]

# Compute several QC metrics for each cell:
# - percentage of mitochondrial counts over total number of counts
# - percentage of ribosomal protein counts over total number of counts
# - total number of counts
# - number of genes detected
mito_prefix = 'mt-'
mito = adata.var_names[adata.var_names.str.lower().str.startswith(mito_prefix)]
adata.obs['percent_mito'] = np.sum(adata[:, mito & adata.var_names].X, axis=1) / np.sum(adata.X, axis=1)
adata.obs['percent_ribo_p'] = adata.obs['n_counts_ribo_p'] / np.ravel(np.sum(adata.X, axis=1))
# adata.obs['percent_spike'] = np.sum(adata[:, spike & adata.var_names].X, axis=1) / np.sum(adata.X, axis=1)
# adata = adata_var_filter(adata, gene_l=spike)
adata.obs['n_counts'] = adata.X.sum(axis=1)
adata.obs['n_genes'] = (adata.X > 0).sum(axis=1)

# %%
# Optional: distribution of QC metrics over all cells
# sc.pl.violin(
#     adata,
#     [
#         'n_genes',
#         'n_counts',
#         'percent_mito',
#         'n_counts_ribo_p',
#         'percent_ribo_p',
#     ],
#     jitter=0.4,
#     multi_panel=True,
#     save='.qc.pdf',
#     cut=0,
# )

#%%
# Plot distribution of QC metrics, splitting by different cell annotations
for gb in ['batch', 'genotype', 'pair', 'sample_id', 'timepoint']:
    sc.pl.violin(
        adata,
        [
            'n_genes',
            'n_counts',
            'percent_mito',
            'n_counts_ribo_p',
            'percent_ribo_p',
        ],
        jitter=0.4,
        save=f'.qc.{gb}.pdf',
        groupby=gb,
        rotation=45,
        wspace=.4,
        cut=0,
    )

#%%
# Save h5ad snapshot (interim data pre-QC filtering)
adata.write(out(f'interim_data/qc/{prefix}.preqc.h5ad'))

#%%
# Reload from previous snapshot
adata = sc.read(out(f'interim_data/qc/{prefix}.preqc.h5ad'))

#%%
# Optional tuning for figure size
sc.set_figure_params(figsize=(5,5))

#%%
# Plot joint scatter plot of QC metrics
sc.pl.scatter(
    adata,
    color='percent_mito',
    x='n_counts',
    y='n_genes',
    frameon=True,
    save='.qc.lib_detect_mito.pdf',
    color_map='viridis',
)
sc.pl.scatter(
    adata,
    color='percent_ribo_p',
    x='n_counts',
    y='n_genes',
    frameon=True,
    save='.qc.lib_detect_ribo_p.pdf',
    color_map='viridis',
)

#%%
# Do the actual QC filtering, this should be tuned depending on 
# the dataset features
# - Mitochondrial percentage
# AGGR01_mapped/unmapped: < .2
adata = adata[adata.obs['percent_mito'] < .2, :]
# - Number of detected genes
# AGGR01_mapped/unmapped: >= 200
adata = adata[adata.obs['n_genes'] >= 200, :]
# adata = adata[adata.obs['n_genes'] <= 8000, :]
# - Number of counts
# AGGR01_mapped/unmapped: <= 1e5 
adata = adata[adata.obs['n_counts'] <= 1e5, :]

#%%
# Plot QC metric joint scatter plot after filtering
sc.pl.scatter(
    adata,
    color='percent_mito',
    x='n_counts',
    y='n_genes',
    frameon=True,
    save='.qc.lib_detect_mito.filter.pdf',
    color_map='viridis',
)
sc.pl.scatter(
    adata,
    color='percent_ribo_p',
    x='n_counts',
    y='n_genes',
    frameon=True,
    save='.qc.lib_detect_ribo_p.filter.pdf',
    color_map='viridis',
)

#%%
# Plot similar plot to the previous ones but using
# batch identity as color for each cell in the
# distribution
sc.pl.scatter(
    adata,
    color='batch',
    x='n_counts',
    y='n_genes',
    frameon=True,
    save='.qc.lib_detect_batch.filter.pdf',
    color_map='viridis',
)

#%%
# Filter out genes that are not expressed in the
# cells that passed the previous QC filtering
sc.pp.filter_genes(adata, min_cells=1)

#%%
# NOTE cell and gene quantification after QC filtering
# AGGR1_mapped: 59523 cells, 32260 genes
# AGGR1_unmapped: 59499 cells, 32679 genes
adata

#%%
# Save snapshot of AnnData after QC filtering
adata.write(out(f'interim_data/qc/{prefix}.qc.h5ad'))

#%%
adata = sc.read(out(f'interim_data/qc/{prefix}.qc.h5ad'))

#%%
# Plot top expressed genes after filtering
sc.pl.highest_expr_genes(adata, n_top=40, save='.filter_top40.pdf');

#%%
# SCRAN normalization. Requires scran to be installed on a concurrent
# R distribution. Also, rpy2 should be installed in python among the
# other scientific computing packages.
def scran_normalize(adata: sc.AnnData) -> sc.AnnData:
    """Normalize raw counts using the approach described in
       Lun, Aaron TL, Karsten Bach, and John C. Marioni. "Pooling across cells to normalize single-cell RNA sequencing data with many zero counts." Genome biology 17.1 (2016): 1-14.
    """
    import numpy as np
    import rpy2.robjects as ro
    from rpy2.robjects import numpy2ri
    from rpy2.robjects.packages import importr
    from scipy import sparse
    importr('scran')
    numpy2ri.activate()
    adata.layers['counts'] = adata.X.copy()
    print('Densifying matrix...')
    adata.X = adata.X.todense()
    ro.r.assign('mat', adata.X.T)
    # qclust_params = f'mat, min.size={min_size}, max.size={max_size}'
    ro.reval('cl <- quickCluster(mat)')
    # csf_params = f'mat, clusters=cl, min.mean={min_mean}' 
    sf = np.asarray(ro.reval('calculateSumFactors(mat, clusters=cl)'))
    adata.obs['sf'] = sf   
    adata.X /= adata.obs['sf'].values[:, None]
    print('Reconverting matrix to sparse format...')
    adata.X = sparse.csr.csr_matrix(adata.X)
    numpy2ri.deactivate()
    return adata

#%%
# Normalize data using the R scran package (pooling normalization)
adata = scran_normalize(adata)

#%%
# Log-transform the normalized data
# (non-log-transformed data is saved in "sf" layer and X matrix)
sc.pp.log1p(adata)
# Save the log-normalized data on a separate layer "sf_log1p"
adata.layers['sf_log1p'] = adata.X 

#%%
# Plot of library size against computed size factor for each cell
sc.pl.scatter(
    adata,
    x='n_counts',
    y='sf',
    color='n_genes',
    color_map='viridis',
    save='.sf.pdf',
)

#%%
# Save final h5ad after QC control
adata.write(out(f'{prefix}.final.h5ad'))

#%%
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Prepare data for LIGER batch correction
adata.X = adata.layers['counts']
adata.to_df().reset_index().to_feather(
    out(f'interim_data/qc/{prefix}.qc.fth')
)
sc.get.obs_df(adata, keys=adata.obs_keys()).to_csv(
    out(f'interim_data/qc/{prefix}.qc.metadata.csv')
)

#%%
# Start from here after you execute LIGER on the counts matrix
# saved in the lines above
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Read LIGER results
usage_norm_liger = pd.read_csv(
    out(f'interim_data/qc/{prefix}.liger.usage_norm.csv'), index_col=0,
)
weights_shared_liger = pd.read_csv(
    out(f'interim_data/qc/{prefix}.liger.weights_shared.csv'), index_col=0,
)
adata.obsm['X_liger_H'] = usage_norm_liger.loc[adata.obs_names, :].values
adata.varm['X_liger_W'] = weights_shared_liger.reindex(columns=adata.var_names).fillna(0.0).T.loc[adata.var_names, :].values

#%%
# Optional: reconstructed matrix from factorization
# adata.layers['liger'] = sparse.csr_matrix(
#     np.matmul(adata.obsm['X_liger_H'], adata.varm['X_liger_W'].T)
# )

#%%
adata.obsm['X_liger_H'].shape

#%%
# Finalize AnnData after pre-processing
adata.write(out(f'{prefix}.final.h5ad'))

#%%
