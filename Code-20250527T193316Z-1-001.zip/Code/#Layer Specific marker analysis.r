#Layer Specific marker analysis


#%% Layer specific cell type
nmarkers = natsorted(list(set([
  'RELN', 'CUX1', 'POU3F2', 'BRN2', 'NECAB1', 'CTIP2', 'CNTC6', 'PCP4', 'BCL11B', 'FOXP2', 'CTGF', 'TBR1', 'SATB2', 'CUX2',
]) & set(adata.raw.var_names)))

#%%
#%%
#Maturity markers
matmarkers = natsorted(list(set([
  'DCX', 'EOMES', 'SLC17A7', 'SLC17A6', 'MAP2', 'RBFOX3',
]) & set(adata.raw.var_names)))

#%%
#%%
# Plot clustering with selected resolution through UMAP
sc.pl.umap(
    adata,
    color=nmarkers,
    save = 'layermarkers4.pdf',
    legend_loc='on data',
)
#%%
# %%
dataEN = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="EN"]
dataEN70d = dataEN[dataEN.obs["timepoint"]=="70d"]
dataEN150d = dataEN[dataEN.obs["timepoint"]=="150d"]

#%%
#%%
(adata[adata.obs['nowakowski.fine.noglyc_unmapped'].isin([EN]),:][:,'TBR1'].X > 0).mean(0)

#%%
#%%
sc.pl.dotplot (dataEN70d, nmarkers, groupby= "genotype", save= "E:/Sneha/RNAseq/scSeq/AGGR01_mapped/fig_supp/layer markers 70d")
sc.pl.dotplot (dataEN150d, nmarkers, groupby= "genotype", save= "E:/Sneha/RNAseq/scSeq/AGGR01_mapped/fig_supp/layer markers 150d")

#%%
# %%
sc.pl.dotplot (dataEN70d, matmarkers, groupby= "genotype", save= "mature markers 70d")
sc.pl.dotplot (dataEN150d, matmarkers, groupby= "genotype", save= "mature markers 150d")

#%%
#%%
sc.pl.dotplot (dataEN70d, "DCX",  groupby= "genotype", save= "DCX EN 70d")
sc.pl.dotplot (dataEN70d, "EOMES", groupby= "genotype", save="EOMES EN 70d")
sc.pl.dotplot (dataEN70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 EN 70d")
sc.pl.dotplot (dataEN70d, "SLC17A6", groupby= "genotype", save= "SL17A6 EN 70d")
sc.pl.dotplot (dataEN70d, "MAP2", groupby= "genotype", save= "MAP2 EN 70d") 
sc.pl.dotplot (dataEN70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 EN 70d")

#%%
# %%
sc.pl.dotplot (dataEN150d, "DCX", groupby= "genotype", save= "DCX EN 150d")
sc.pl.dotplot (dataEN150d, "EOMES", groupby= "genotype",save= "EOMES EN 150d")
sc.pl.dotplot (dataEN150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 EN 150d")
sc.pl.dotplot (dataEN150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 EN 150d")
sc.pl.dotplot (dataEN150d, "MAP2", groupby= "genotype",save= "MAP2 EN 150d")
sc.pl.dotplot (dataEN150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 EN 150d")

#%%
# %%
datanEN_early = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="nEN-early"]
datanEN_early70d = datanEN_early[datanEN_early.obs["timepoint"]=="70d"]
datanEN_early150d = datanEN_early[datanEN_early.obs["timepoint"]=="150d"]

#%%
# %%
sc.pl.dotplot (datanEN_early70d, nmarkers, groupby= "genotype", save= "layer markers nen_early 70d")
sc.pl.dotplot (datanEN_early150d, nmarkers, groupby= "genotype", save= "layer markers nEN_early 150d")

#%%
# %%
sc.pl.dotplot (datanEN_early70d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 70d")
sc.pl.dotplot (datanEN_early150d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 150d")

#%%
# %%
sc.pl.dotplot (datanEN_early70d, "DCX",  groupby= "genotype", save= "DCX earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "EOMES", groupby= "genotype", save="EOMES earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "SLC17A6", groupby= "genotype", save= "SL17A6 earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "MAP2", groupby= "genotype", save= "MAP2 earlynen 70d") 
sc.pl.dotplot (datanEN_early70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 earlynen 70d")

#%%
# %%
sc.pl.dotplot (datanEN_early150d, "DCX", groupby= "genotype", save= "DCX earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "EOMES", groupby= "genotype",save= "EOMES earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "MAP2", groupby= "genotype",save= "MAP2 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 earlynen 150d")

#%%
#%%

datanEN_late = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="nEN-late"]
datanEN_late70d = datanEN_early[datanEN_early.obs["timepoint"]=="70d"]
datanEN_late150d = datanEN_early[datanEN_early.obs["timepoint"]=="150d"]

#%%
# %%
sc.pl.dotplot (datanEN_late70d, nmarkers, groupby= "genotype", save= "layer markers nen_late 70d")
sc.pl.dotplot (datanEN_late150d, nmarkers, groupby= "genotype", save= "layer markers nEN_late 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, "DCX",  groupby= "genotype", save= "DCX latenen 70d")
sc.pl.dotplot (datanEN_late70d, "EOMES", groupby= "genotype", save="EOMES latenen  70d")
sc.pl.dotplot (datanEN_late70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 latenen  70d")
sc.pl.dotplot (datanEN_late70d, "SLC17A6", groupby= "genotype", save= "SL17A6 latenen  70d")
sc.pl.dotplot (datanEN_late70d, "MAP2", groupby= "genotype", save= "MAP2 latenen 70d") 
sc.pl.dotplot (datanEN_late70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 latenen  70d")

#%%
# %%
sc.pl.dotplot (datanEN_late150d, "DCX", groupby= "genotype", save= "DCX latenen 150d")
sc.pl.dotplot (datanEN_late150d, "EOMES", groupby= "genotype",save= "EOMES latenen 150d")
sc.pl.dotplot (datanEN_late150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "MAP2", groupby= "genotype",save= "MAP2 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 latenen 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 70d")
sc.pl.dotplot (datanEN_late150d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, nmarkers, groupby= "genotype", save= "layer markers nen_late 70d")
sc.pl.dotplot (datanEN_late150d, nmarkers, groupby= "genotype", save= "layer markers nEN_late 150d")

#%%
# %% Subset layer specific cells
adata_subset = adata[adata[: , 'TBR1'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL6 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL6 150d")


#%%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL6 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL6 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL6  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL6 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2  ENL6 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL6 70d")

#%%
# %%
sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL6 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL6 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL6 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL6 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL6 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL6 150d")

#%%
# %%
adata_subset = adata.raw[adata.raw[: , 'SATB2'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL2 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL2 150d")

# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL2 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL2 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL2  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL2 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2  ENL2 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL2 70d")


#%%
# %%
sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL2 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL2 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL2 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL2 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL2 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL2 150d")

#%%
# %%
adata_subset = adata[adata[: , 'BCL11B'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL56 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL56 150d")
# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL56 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL56 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL56  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL56 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2 ENL5670d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL56 70d")


sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL56 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL56 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL56 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL56 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL56 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL56 150d")

#%%
# %%
adata_subset = adata[adata[: , 'CUX1'].X > 0.5, :]
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]


#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL23 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL23 150d")

# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL23 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL23 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL23  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL23 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2 ENL23 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL23 70d")


sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL23 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL23 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL23 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL23 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL23 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL23 150d")
# %%
