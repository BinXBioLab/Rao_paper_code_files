# %% [markdown]
# # Gene Regulatory Network analysis
# ### Step 1: Generating count matrix

# %%
# Import modules
import loompy as lp
import matplotlib.pyplot as plt
from natsort import natsorted
import numpy as np
import os
import pandas as pd
import seaborn as sns
import sys

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

# Define sample prefix
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join('data')
data = fullpath_closure(data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

# %%
# Load main AnnData snapshot
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

# %% [markdown]
# ### Step 2: Pyscenic execution

#%%
# We are using raw counts as initial data
adata.X = adata.layers['counts']
adata.X

#%%
# For memory and time constraints we only consider
# genes expressed in at least 30 cells
sc.pp.filter_genes(adata, min_cells=30)
adata.X

#%%
# In particular, we get genes expressed in at least
# 30 cells, in at least one condition (WT or Mutant)
subset = {}
for g in ['Case', 'Control']:
    subset[g], _ = sc.pp.filter_genes(
        adata[adata.obs['genotype'] == g].X,
        inplace=False,
        min_cells=30,
    )

#%%
# We identify these genes
subset['Case'].sum(), subset['Control'].sum()
(subset['Case'] & subset['Control']).sum()
genes = adata.var_names[subset['Case'] | subset['Control']]
genes, len(genes)

#%%
# We subset the original dataset keeping only these genes
adata = adata[:, genes].copy()
adata.X

#%%
# We create the loom dataset to use with pySCENIC
row_attrs = { 
    "gene": np.array(adata.var.index),
}
col_attrs = { 
    "cell": np.array(adata.obs.index),
}
lp.create(
    out(f'interim_data/tf/{prefix}.counts.loom'),
    adata.X.transpose(),
    row_attrs,
    col_attrs,
)

#%%
### NOTE using Docker for pyscenic 0.11.0 (optional: add --sparse flag)
## Infer regulon modules: Execute n times
# docker run -it --rm \
#     -v /home/ubuntu/proj/org:/scenicdata \
#     -p 8787:8787 \
#     aertslab/pyscenic:0.11.0 pyscenic grn \
#         --num_workers 8 \
#         --cell_id_attribute cell \
#         --gene_attribute gene \
#         -o /scenicdata/AGGR01_mapped.adj.tsv \
#         /scenicdata/AGGR01_mapped.counts.loom \
#         /scenicdata/hs_hgnc_curated_tfs.22q11.txt

## Refine regulons: Execute n times
# docker run -it --rm \
#     -v /home/ubuntu/proj/org:/data \
#     -p 8788:8787 \
#     aertslab/pyscenic:0.11.0 pyscenic ctx \
#         /data/AGGR01_mapped.adj.tsv \
#         /data/hg38__refseq-r80__10kb_up_and_down_tss.mc9nr.feather \
#         /data/hg38__refseq-r80__500bp_up_and_100bp_down_tss.mc9nr.feather \
#         --annotations_fname /data/motifs-v9-nr.hgnc-m0.001-o0.0.tbl \
#         --expression_mtx_fname /data/AGGR01_mapped.counts.loom \
#         --mode "dask_multiprocessing" \
#         --output /data/AGGR01_mapped.regulons.csv \
#         --num_workers 4 \
#         --gene_attribute gene \
#         --cell_id_attribute cell

## Open container with below command and executed following code below
## within the container
# docker run -it --rm \
#     -v /home/ubuntu/proj/hpc/scenic:/data \
#     aertslab/pyscenic:0.11.0 bash

#%%
# Load modules
from collections import Counter
import pandas as pd
from pyscenic.utils import load_motifs
from pyscenic.transform import df2regulons

# Load motifs
motifs = []
for i in range(1, 4):
    motifs.append(load_motifs(f'{prefix}.regulons.{i}.csv'))

# Collect regulons
regulons = []
for regulons_l in map(df2regulons, motifs):
    single = None
    for r in regulons_l:
        ks = []
        for k, v in r.gene2weight.items():
            ks += [k]
        single = pd.concat([single, pd.DataFrame({r.name: ks})], axis=1)
    regulons.append(single.fillna(''))

# Get regulons identified at least in 2 runs (out of 3)
columns = Counter([
    e for l in map(lambda x: list(x.columns), regulons) for e in l
])
columns = [e for e in columns if columns[e] > 1]

# Get target genes identified at least in 2 runs for each regulons
stable_regulons = None
for c in columns:
    targets = []
    for r in regulons:
        if c in r.columns:
           targets.extend(filter(lambda x: x != '', r[c]))
    targets = Counter(targets)
    targets = [e for e in targets if targets[e] > 1] 
    stable_regulons = pd.concat([
        stable_regulons, pd.DataFrame({c: targets})
    ], axis=1) 

# List of target genes per stable regulons
stable_regulons.to_csv(f'{prefix}.regulons.final.csv', index=False)

# Input data for AUCell
with open(f'{prefix}.regulons.final.gmt', 'wt') as gmt:
    for c in stable_regulons.columns:
        genes = '\t'.join(stable_regulons.loc[:, c].dropna())
        gmt.write(f'{c}\tRegulon_{c}\t{genes}\n')

#%%
## Exit the container

#%%
## Run AUCCell with the final regulons on the merged dataset counts
# docker run -it --rm \
#     -v /home/ubuntu/proj/org:/data \
#     aertslab/pyscenic:0.11.0 pyscenic aucell \
#         /data/AGGR01_mapped.counts.loom \
#         /data/AGGR01_mapped.regulons.final.gmt \
#         -o /data/AGGR01_mapped.auc_mtx.csv \
#         --num_workers 4 \
#         --gene_attribute gene \
#         --cell_id_attribute cell

#%%

# %% [markdown]
# ## Analysis Post-PYSCENIC

# %%
# Import modules
import matplotlib.pyplot as plt
from natsort import natsorted
import numpy as np
import os
import pandas as pd
from scipy import stats as ss, sparse
import seaborn as sns
from sklearn.metrics import silhouette_score
import sys

sns.set(style='white')

samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

# Helper closures for path generation
# Out dir is the folder where results will be saved
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

res_prefix = {
    'AGGR01_mapped': 'final',
}
res = res_prefix[prefix]
prefix, res

# %%
# Load main data
adata = sc.read(out(f'{prefix}.final.h5ad'))

#%%
# Set color palette
palette = sns.color_palette('Set2') + '#235b54 #3998f5 #991919 #c56133 #2f2aa0 #b732cc #f07cab #d30b94 #c3a5b4 #5d4c86'.split()
sns.palplot(palette)

#%%
# Set cell type annotation key
key = 'nowakowski.fine.noglyc_unmapped'

#%%
# Load inferred TF activity
tf_df = pd.read_csv(
    out(f'interim_data/tf/{prefix}.auc_mtx.csv'),
    index_col=0,
)
tf_df.columns = [t[:-3] for t in tf_df.columns] 
tf_df

# %%
# Transform matrix into AnnData
adata_tf = sc.AnnData(tf_df, obs=adata.obs.loc[tf_df.index, :])
adata_tf.X = sparse.csr.csr_matrix(adata_tf.X)
adata_tf.layers['auc_score'] = adata_tf.X
adata_tf

# %%
# Scale TF activity and compute PCA
adata_tf.X = adata_tf.layers['auc_score']
sc.pp.scale(adata_tf)
sc.tl.pca(adata_tf, random_state=42)

#%%
# Plot PC variance explained by the top components
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.pl.pca_variance_ratio(adata_tf, n_pcs=50)

#%%
# Compute neighbors and UMAP on the top principal components
sc.pp.neighbors(adata_tf, n_pcs=20, random_state=42)
sc.tl.umap(adata_tf, random_state=42)

#%%
# Plot cell type annotation using UMAP computed on TF activity
sc.pl.umap(
    adata_tf,
    color=key,
    palette=list(palette),
    save=f'.tf.{key}.pdf',
    legend_fontsize=7,
)

#%%
# Plot QC matrix on TF activity UMAP
sc.pl.umap(
    adata_tf,
    color=['batch', 'genotype', 'timepoint', 'pair'],
    save=f'.tf.qc.pdf',
    legend_fontsize=7,
    ncols=2,
)

# %%
# Save TF activity on disk
adata_tf.write(out(f'interim_data/tf/{prefix}.tf.h5ad'))

# %%
# Plot activity UMAPs for some TFs
sc.pl.umap(
    adata_tf,
    color=[
        'SOX2', 'SOX9', 'DLX1', 'DLX5', 'DLX6',
        'NEUROG1', 'NEUROG2', 'NEUROD1', 'NEUROD2',
    ],
    color_map='viridis',
    save='.tf.markers.pdf',
    ncols=3,
)

#%%
# Compute differential TF activity
# NOTE this is the first version, see also the version on the 
# NOTE hpc project for an updated (and probably better) version
# NOTE since it also uses the Regulon Specificity Score
import pandas as pd
from typing import Dict, List, Set, Tuple

def mann_whitney_tfs(
    data: pd.DataFrame,
    obs: pd.DataFrame,
    gb: str,
    fdr: float = .05,
    subset: Set = None,
    by: str = None,
) -> Tuple[Dict[str, pd.DataFrame], Dict[str, List]]:
    import os
    import pandas as pd
    de_tf = {}
    top = {}
    obs = obs.copy()
    if by is None:
        k = 'Sheet0'
        de_tf[k], top[k] = _mann_whitney_tfs_in(
            data, obs, gb, fdr=fdr, subset=subset,
        )
    else:
        ccounts = obs[by].value_counts()
        keep = list(ccounts[ccounts > 1].index)
        for k in keep:
            # print(f'Analyzing {k}')
            obs_k = obs.loc[obs[by] == k].copy()
            data_k = data.loc[obs_k.index, :]
            # by_prefix = f'.{by}.{str(k).lower().replace(" ", "_")}'
            de_tf[k], top[k] = _mann_whitney_tfs_in(
                data_k, obs_k, gb, fdr=fdr, subset=subset,
            )
    return de_tf, top

def _mann_whitney_tfs_in(
    data: pd.DataFrame,
    obs: pd.DataFrame,
    gb: str,
    fdr: float = .05,
    subset: Set = None,
) -> Tuple[Dict[str, pd.DataFrame], Dict[str, List]]:
    import os
    import pandas as pd
    de_tf = _mann_whitney_tfs_compute(data, obs[gb], subset=subset)
    top = _mann_whitney_tfs_filter(de_tf, obs[gb], fdr=fdr, subset=subset)
    return de_tf, top

def _mann_whitney_tfs_compute(
    data: pd.DataFrame,
    groups: pd.Series,
    subset: Set = None,
) -> Dict[str, pd.DataFrame]:
    import pandas as pd
    from scipy.stats import mannwhitneyu
    from statsmodels.stats.multitest import fdrcorrection
    de_tf = None
    data = data.loc[:, data.var() > 0].copy()
    for g in groups.cat.categories:
        if subset is not None and g in subset:
            # print(f'Testing {g}')
            g_samples = groups[groups == g].index
            r_samples = groups[~(groups == g)].index

            mw = data.apply(
                lambda col: mannwhitneyu(
                    col.loc[g_samples],
                    col.loc[r_samples], 
                    alternative='greater',
                ),
                axis='index',
            ).T
            mw.columns = ['U', 'pvalue']
            median_d = data.apply(
                lambda col: 
                    col.loc[g_samples].median()
                    - col.loc[r_samples].median(),
                axis='index',
            ).to_frame()
            median_d.columns = ['median_diff']
            mw['qvalue'] = fdrcorrection(mw['pvalue'], method='negcorr')[1]
            de_tf = pd.concat([
                    de_tf, pd.concat(
                        [median_d, mw], axis=1, sort=True,
                    ).add_prefix(f'{g}_')
                ],
                axis=1,
                sort=True,
            )
    return de_tf

def _mann_whitney_tfs_filter(
    de_tf: pd.DataFrame,
    groups: pd.Series,
    p: float = .75,
    fdr: float = .05,
    subset: Set = None,
) -> Dict[str, List]:
    top = {}
    for g in groups.cat.categories:
        if subset is not None and g in subset:
            de_tf = de_tf.sort_values(by=f'{g}_U', ascending=False)
            thr = de_tf[f'{g}_median_diff'].quantile(p)
            top[g] = de_tf.loc[
                (de_tf[f'{g}_median_diff'] > thr)
                & (de_tf[f'{g}_qvalue'] < fdr)
            ].index.tolist()
    return top

# %%
# Save TF background list (might be useful for over-representation tests)
adata_tf.var_names.to_series().to_csv(
    out(f'interim_data/tf/background.csv'),
    index=False,
    header=None,
)

# %%
# Extract differential TF activity between different
# conditions, or across different cell types
fdr = 0.05
for gb, exclude, n in [
        # ('condition', [], 25),
        # (f'leiden_{res}', [], 10),
        (key, [], 10),
    ]:
    obs = adata.obs.copy()
    obs[gb] = obs[gb].astype('category')
    subset = obs[gb].cat.categories.symmetric_difference(exclude)
    de_tf, top = mann_whitney_tfs(tf_df, obs, gb, fdr=fdr, subset=subset)
    fname = out(f'interim_data/tf/dtf.{gb}') 
    tl_rank_excel(de_tf, fname, top=top)


# %%
# Extract differential TF activity between different
# cell types, each timepoint independently
for tp in ['70d', '150d']:
    gb = 'genotype'
    for by, exclude in [
            # (f'leiden_{res}', []),
            (key, []),
        ]:
        obs = adata.obs.copy()
        obs = obs[obs['timepoint'] == tp].copy()
        tf_df_t = tf_df.loc[obs.index, :].copy()
        obs[gb] = obs[gb].astype('category')
        subset = obs[gb].cat.categories.symmetric_difference(exclude)
        de_tf, top = mann_whitney_tfs(
            tf_df_t, obs, gb, fdr=fdr, subset=subset, by=by,
        )
        fname = out(f'interim_data/tf/dtf.timepoint_{tp}.{by}.{gb}') 
        tl_rank_excel(de_tf, fname, top=top)

# %%
# Get TF differential between cell types
markers_df = pd.read_excel(out(f'interim_data/tf/dtf.{key}.top.xlsx'))
markers = markers_df.head(5).to_dict(orient='list')
markers

# %%
# Compute differential TFs
# NOTE: This is probably obsolete: see similar code in hpc project for
# revised method
n_top = 5
zval = 1
qval = 1e-10
markers = {}
markers_df = pd.read_excel(out(f'interim_data/tf/dtf.{key}.xlsx'), index_col=0)
for p in adata.obs[key].cat.categories:
    rr = markers_df.loc[markers_df[f'{p}_qvalue'] < qval].copy()
    rr.loc[:, f'{p}_median_diff_Z'] = ss.zscore(rr[f'{p}_median_diff'])
    rr = rr.loc[rr[f'{p}_median_diff_Z'] > zval]
    markers[p] = list(
        rr.sort_values(f'{p}_U', ascending=False).head(n_top).index
    )

#%%
# Set colors for annotations
adata_tf.uns[f'{key}_colors'] = palette
adata_tf.uns['genotype_colors'] = ['#ca3c25', '#393e41']

# %%
# Plot heatmap of differential TFs
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.tl.dendrogram(adata_tf, groupby=key, linkage_method='complete')
ax = sc.pl.heatmap(
    adata_tf, markers, groupby=key, cmap='YlGnBu',
    layer='auc_score', standard_scale='var',
    dendrogram=True, show_gene_labels=True, swap_axes=True,
    save=f'.dtf.{key}.pdf',
)

# %%
# Compute differential TFs for each timepoint, cell type
# NOTE see note above for possible update to this code
n_top = 5
zval = 1
qval = 1e-10
for tp in ['70d', '150d']:
    markers_df = pd.read_excel(
        out(f'interim_data/tf/dtf.timepoint_{tp}.{key}.genotype.xlsx'),
        sheet_name=None, index_col=0,
    )
    for k, r in markers_df.items():
        markers = {}
        if k in adata_tf.obs[key].cat.categories:
            for p in ['Case', 'Control']:
                rr = r.loc[r[f'{p}_qvalue'] < qval]
                rr.loc[:, f'{p}_median_diff_Z'] = ss.zscore(rr[f'{p}_median_diff'])
                rr = rr.loc[rr[f'{p}_median_diff_Z'] > zval]
                markers[p] = list(
                    rr.sort_values(f'{p}_U', ascending=False).head(n_top).index
                )
            # print(k, markers)
            if len(markers['Case']) + len(markers['Control']) > 0:
                adata_tf_t = adata_tf[
                    (adata_tf.obs[key] == k)
                    & (adata_tf.obs['timepoint'] == tp)
                ].copy()
                sc.pl.heatmap(
                    adata_tf_t, markers, groupby='genotype', cmap='YlGnBu',
                    dendrogram=False, layer='auc_score',
                    standard_scale='var', show_gene_labels=True, swap_axes=True,
                    save=f'.dtf.timepoint_{tp}.{key}.{k}.pdf',
                )

# %%
# Save TF data snapshot
adata_tf.write(out(f'interim_data/tf/{prefix}.tf.h5ad'))

# %% [markdown]
# ### Enrichment of top regulons' target genes

# %%
from gprofiler import GProfiler
gp = GProfiler(return_dataframe=True)

# %%
# Read TF data snapshot
adata_tf = sc.read(out(f'interim_data/tf/{prefix}.tf.h5ad'))

# %%
# Read regulons results (TF + target genes)
regulons = pd.read_csv(
    out(f'interim_data/tf/{prefix}.regulons.final.csv'),
)
regulons.columns = [c[:-3] for c in regulons.columns]
regulons

#%%
# Define cell type annotation label
from scipy import stats
key = 'nowakowski.fine.noglyc_unmapped'

# %%
# For each timepoint, identify top regulons, get the union
# of their target genes and compute the GO term enrichment
# of such target genes
# NOTE: also this part might be considered obsolete and
# updated as previous part
for tp in ['70d', '150d']:
    targets_sheet = {}
    n_top = 10
    zval = 1
    qval = 0.05
    markers_df = pd.read_excel(
        out(f'interim_data/tf/dtf.timepoint_{tp}.{key}.genotype.xlsx'),
        sheet_name=None,
        index_col=0,
    )
    for k, r in markers_df.items():
        markers = {}
        targets_df = {}
        targets = {}
        res = {}
        if k in adata_tf.obs[key].cat.categories:
            for p in ['Case', 'Control']:
                rr = r.loc[r[f'{p}_qvalue'] < qval].copy()
                rr.loc[:, f'{p}_median_diff_Z'] = stats.zscore(
                    rr[f'{p}_median_diff']
                )
                rr = rr.loc[rr[f'{p}_median_diff_Z'] > zval]
                markers[p] = list(
                    rr.sort_values(f'{p}_U', ascending=False).head(n_top).index
                )
                targets[p] = set()
                for mm in markers[p]:
                    targets[p] |= set(regulons[mm].dropna().values)
                genes = list(targets[p])
                print(f'{k}, {p}: {len(genes)} final genes.')
                targets_df[p] = genes
                if len(genes) > 0:
                    res[p] = gp.profile(
                        organism='hsapiens',
                        query=genes,
                        all_results=False,
                        ordered=False,
                        no_iea=False,
                    )
            folder = out(f'interim_data/tf/gprof/{tp}/{key}')
            os.makedirs(folder, exist_ok=True)
            if len(res) > 0: 
                fname = f'gprof.{k}.genotype.targets'
                tl_gprof_excel(res, os.path.join(folder, fname))
        targets_sheet[k] = pd.DataFrame.from_dict(
            targets_df, orient='index'
        ).T.fillna('')
    fname = f'gprof.genotype.targets.genes'
    tl_rank_excel(targets_sheet, os.path.join(folder, fname))


# %% [markdown]
# ### Identify genes selected of top N enriched terms

# %%
# This part identifies the target genes that contribute to
# the enrichment of top results in GO enrichment.
# NOTE: this part can be replaced in the previous code
# by passing the argument `no_evidences=False` to the gprofiler
# function. It is left here because it was necessary on this
# version of the code.
for tp in ['70d', '150d']:
    folder = out(f'interim_data/tf/gprof/{tp}/{key}')
    targets_sheet = pd.read_excel(
        os.path.join(folder, 'gprof.genotype.targets.genes.xlsx'),
        sheet_name=None, index_col=0
    )
    for k in targets_sheet.keys():
        res_final = {}
        targets_df = targets_sheet[k]
        try:
            res = pd.read_excel(
                os.path.join(folder, f'gprof.{k}.genotype.targets.xlsx'),
                sheet_name=None, index_col=0,
            )
            for p in ['Case', 'Control']:
                genes = set(targets_df[p].dropna())
                if p in res.keys():
                    # Take top 20 BPs
                    res_p = res[p][
                        res[p].index.str.startswith('GO:BP')
                    ].head(20)
                    res_p = res_p.reset_index().set_index('native')
                    for i in res_p.index:
                        # Genes in BP
                        go_genes = gp.convert(
                            organism='hsapiens', query=[i],
                            target_namespace='ENSG',
                            numeric_namespace='ENTREZGENE_ACC',
                        ).loc[:, ['converted', 'name']]
                        # Genes that are targets of differential TFs
                        ensg_genes = gp.convert(
                            organism='hsapiens', query=list(genes),
                            target_namespace='ENSG',
                            numeric_namespace='ENTREZGENE_ACC',
                        ).loc[:, ['converted', 'name']]
                        # Intersection: which target genes contributes to
                        # enrichment
                        intsect = list(
                            set(ensg_genes.loc[
                                ensg_genes['converted'].isin(
                                    go_genes['converted']
                                ), 'name'
                            ]))
                        n_intsect = len(intsect)
                        res_p.loc[i, 'is_len'] = str(n_intsect)
                        res_p.loc[i, 'is_genes'] = ';'.join(intsect)
                        res_final[p] = res_p
            if len(res_final) > 0:
                tl_gprof_excel(
                    res_final, os.path.join(
                        folder, f'gprof.{k}.condition.targets.isect_genes'
                    )
                )
                print(f'{k} done')
            else:
                print(f'{k} done (empty)')
        except FileNotFoundError:
            pass

#%%
