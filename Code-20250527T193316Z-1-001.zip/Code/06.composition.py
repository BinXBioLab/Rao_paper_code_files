#%%
# Setup
import warnings
import matplotlib
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap
warnings.filterwarnings("ignore")

import arviz as az
import pandas as pd
import pickle as pkl

from sccoda.util import comp_ana as mod
from sccoda.util import cell_composition_data as dat
from sccoda.util import data_visualization as viz

#%%
# Set visual style
import seaborn as sns
sns.set(style='white')


# %%
# Set prefix for dataset
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

# %%
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

# Helper closures for path generation
# Root data dir is the folder containing raw data
# Out dir is the folder where results will be saved
root_data_dir = os.path.join('data')
root_data = fullpath_closure(root_data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

# %%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

#%%
# Set annotation name
key = 'nowakowski.fine.noglyc_unmapped' 

# %%
# Read data
adata = sc.read(out(f'{prefix}.final.h5ad'))
adata

#%%
# Generate data for scCODA from main data
covariates = ['pair', 'genotype', 'timepoint']
data = dat.from_scanpy(
    adata, cell_type_identifier=key, sample_identifier='batch',
    covariate_df=adata.obs.groupby('batch')[covariates].first(),
)
data

# %%
# Save data for scCODA to disk
data.write(out('interim_data/composition/data.h5ad'))

#%%
# Reload data from disk (start from here if data has been
# already generated)
data = sc.read('composition/data.h5ad')
data
#%%
# Set color palette for cell type annotation
palette = sns.color_palette('Set2') + '#235b54 #3998f5 #991919 #c56133 #2f2aa0 #b732cc #f07cab #d30b94 #c3a5b4 #5d4c86'.split()
cmap = ListedColormap(palette)
sns.palplot(palette)

# %%
# Stacked barplot for each sample
viz.stacked_barplot(data, feature_name='samples', cmap=cmap, dpi=150)
plt.legend(prop={'size': 7}, bbox_to_anchor=(1.05, .85), frameon=False)
plt.xticks(rotation=90)
plt.savefig(
    out(f'fig_supp/composition/sbplot.batch.{key}.pdf'), bbox_inches='tight',
)

# Stacked barplot for the levels of "genotype"
viz.stacked_barplot(data, feature_name='genotype', cmap=cmap, dpi=150)
plt.legend(prop={'size': 7}, bbox_to_anchor=(1.05, .85), frameon=False)
plt.xticks(rotation=0)
plt.savefig(
    out(f'fig_supp/composition/sbplot.genotype.{key}.pdf'), bbox_inches='tight',
)

# %%
# Identify which cell type to use as reference
viz.rel_abundance_dispersion_plot(
    data=data,
    abundant_threshold=0.9,
    dpi=150,
)

# %%
# Set up model with condition and covariates 
model = mod.CompositionalAnalysis(
    data,
    formula='C(genotype, Treatment("Control")) + pair + timepoint',
    reference_cell_type='automatic',
)

# %%
# Sample posterior from the model
results = model.sample_hmc()

#%%
# Print results
results

# %%
# Print results summary
results.summary_extended()

#%%
# Identify credible effects in difference between genotypes
inter, effect = results.summary_prepare()
inter.to_csv('composition/intercept.csv')
effect.to_csv('composition/effects.csv')
results.credible_effects().to_csv('composition/credible.csv')
effect.loc[results.credible_effects()].to_csv('composition/credible_effects.csv'
)

# %%
# Plot trace of sampling
az.plot_trace(
    results,
    divergences=False,
    var_names=["alpha", "beta"],
    coords={"cell_type": results.posterior.coords["cell_type_nb"]},
)

# %%
# Plot boxplot of genotype distribution within cell types
viz.boxplots(
    data, feature_name='genotype', dpi=150, cmap=['#393e41', '#ca3c25'],
    figsize=(10,10), args_boxplot={'hue_order': ['Control', 'Case']},
    add_dots=True, args_swarmplot={'hue_order': ['Control', 'Case']},
)
plt.savefig('fig_supp/composition/bxplot.genotype.pdf', bbox_inches='tight', format= 'eps'
)

#%%
# NOTE Rerun the previous analysis but here for each timepoint separately
for tp in ['70d', '150d']:
    # Get data of a single timepoint
    data_m = data[data.obs['timepoint'] == tp].copy()
    # The timepoint covariate is not needed anymore
    model = mod.CompositionalAnalysis(
        data_m,
        formula='C(genotype, Treatment("Control")) + pair',
        reference_cell_type='automatic',
    )
    # Sample
    results = model.sample_hmc()
    # Print summary
    results.summary_extended()
    # Identify credible effects
    inter, effect = results.summary_prepare()
    inter.to_csv(f'composition/{tp}.intercept.csv')
    effect.to_csv(f'composition/{tp}.effects.csv')
    results.credible_effects().to_csv(f'composition/{tp}.credible.csv')
    
    effect.loc[results.credible_effects()].to_csv(f'composition/{tp}.credible_effects.csv')
    
    # Plot traces
    az.plot_trace(
        results,
        divergences=False,
        var_names=["alpha", "beta"],
        coords={"cell_type": results.posterior.coords["cell_type_nb"]},
    )
    # %%
    #  Plot distribution of boxplots for genotypes across cell types
    viz.boxplots(
        data_m, feature_name='genotype', dpi=150, cmap=['#393e41', '#ca3c25'],
        figsize=(10,10), args_boxplot={'hue_order': ['Control', 'Case']},
        add_dots=True, args_swarmplot={'hue_order': ['Control', 'Case']},
    )
    plt.savefig(f'composition/{tp}.bxplot.genotype.eps', bbox_inches='tight', format= "eps"
    )

# %%
for EN in ["EN"]
data_mm = data_m[data_m.obs[EN== "EN"]]
data_mm.var

# %%
