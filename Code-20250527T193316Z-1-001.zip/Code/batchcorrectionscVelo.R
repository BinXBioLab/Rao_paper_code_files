# Clear workspace
rm(list=ls())
setwd ("E:/Sneha/RNAseq/ScSeq/scVelo")

#install.packages('rliger')

# Load libraries
library(liger)
library(Seurat)
library(ggplot2)
library(cowplot)
library(arrow)
library (rliger)
# feather library became obsolete during the project
# it got replaced by arrow library that provides the updated
# `read_feather()` function
# library(feather)
theme_set(theme_cowplot())

# Uncomment the line corresponding to the dataset to batch-correct with LIGER
#prefix <- 'spliced'
prefix <- 'unspliced'

# Load counts matrix after QC
data <- as.data.frame(read.csv("E:/Sneha/RNAseq/ScSeq/scVelo/unspliced.csv", header= TRUE,))
rownames(data) <- data[,1]
data <- data[,-1]

# Load cell annotations
meta.data <- read.table(
    sep=',',
    header=TRUE,
    check.names=FALSE,
    paste('E:/Sneha/RNAseq/ScSeq/scVelo/AGGR01_mapped.qc.metadata.csv', sep=''),
    row.names=1,
)

# Create Seurat object from counts matrix
sdata <- CreateSeuratObject(
    t(data),
    project=prefix,
    assay='RNA',
    meta.data=meta.data,
)

# Remove temporary data
rm(data)
rm(meta.data)

# Convert to LIGER object and remove Seurat object
ldata <- seuratToLiger(sdata, combined.seurat=T, meta.var='batch',remove.missing = FALSE)
rm(sdata)

# LIGER pre-processing: counts normalization, top variable genes
# selection, scaling (but not centering) of each gene distribution
ldata <- normalize(ldata)
ldata@var.genes <-rownames(ldata@raw.data[[1]])
#ldata <- selectGenes(ldata)
ldata <- scaleNotCenter(ldata)

# Save data snapshot
saveRDS(ldata, file=paste(prefix, '.liger.rds', sep=''))
ldata <- readRDS(paste(prefix, '.liger.rds', sep=''))

# # Compute integration on various k values
# pdf('k.pdf')
# suggestK(ldata, k.test=seq(20,70,5), num.cores=56)
# dev.off()

# Select k value (see downstream analyses to check the final k value)
    k <- 45 #UT OPTIMAL K VAL HERE


# This step might help choosing lambda but due to a bug
# it fails most of the time without results
# Resorting to choosing lambda with default value (lines below)
# pdf('lambda.pdf')
# suggestLambda(ldata, k=k, rand.seed=42, num.cores=4)
# dev.off()
# if (prefix == 'AGGR01_mapped') {
    # lambda <- 6
# } else if (prefix == 'AGGR01_unmapped') {
    # lambda <- 10
# }

# Set lambda to default value-
lambda <- 5

# Align and quantile normalize batches
ldata <- optimizeALS(ldata, k=k, lambda=lambda)
ldata <- quantile_norm(ldata)

# Save data snapshot
saveRDS(ldata, file=paste(prefix, '.liger.rds', sep=''))
ldata <- readRDS(paste(prefix, '.liger.rds', sep=''))

# Save usage matrix
write.table(
    as.data.frame(ldata@H.norm),
    file=paste(prefix, '.liger.usage_norm.csv', sep=''),
    sep=',',
    quote=FALSE,
    col.names=NA,
)

# Save factor loadings matrix
write.table(
    as.data.frame(ldata@W),
    file=paste(prefix, '.liger.weights_shared.csv', sep=''),
    sep=',',
    quote=FALSE,
    col.names=NA,
)

rm(ldata)

# save matrices to add to loom file

spliced = readRDS("E:/Sneha/RNAseq/scSeq/scVelo/spliced.liger.rds")
spliced.liger.mat<-(spliced@H.norm)%*%(spliced@W)
                   rownames(spliced.liger.mat)<-rownames(spliced@H.norm)
                   colnames(spliced.liger.mat)<-colnames(spliced@W)


#library(data.table) fwrite(spliced.liger.mat,"spliced.liger.mat.csv")
#write.csv(spliced.liger.mat,"spliced.liger.mat.csv")
spliced.liger.mat= lapply(spliced.liger.mat, as.integer)
str(spliced.liger.mat)
spliced.liger.mat = as.data.frame(spliced.liger.mat)
library("dplyr")
copy <- spliced.liger.mat
copy <- tibble::rownames_to_column(copy, "CellID")


spliced_mat= read.csv("spliced.liger.mat.csv")                    
unspliced = readRDS("E:/Sneha/RNAseq/scSeq/scVelo/unspliced.liger.rds")
unspliced.liger.mat<-(unspliced@H.norm)%*%(unspliced@W)
                    rownames(unspliced.liger.mat)<-rownames(unspliced@H.norm)
                    colnames(unspliced.liger.mat)<-colnames(unspliced@W)
write.csv(unspliced.liger.mat,"unspliced.liger.mat.csv")
                    