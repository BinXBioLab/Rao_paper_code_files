
#DESeq2 pipeline from expression matrix
# Details here: https://bioconductor.org/packages/release/workflows/vignettes/rnaseqGene/inst/doc/rnaseqGene.html#preparing-quantification-input-to-deseq2

library("DESeq2")

#Define input data
countdata <-read.csv(file.path("C:/Users/Nikon/Desktop/Sneha/RNAseq/Bulk Seq/Sep-Oct2019/fullorganoid/FullGeneCount.csv"), header = TRUE, stringsAsFactors=FALSE, row.names = 1)

coldata <- read.table(file.path("C:/Users/Nikon/Desktop/Sneha/RNAseq/Bulk Seq/Sep-Oct2019/fullorganoid/samplekeyfull.txt"), header = TRUE, stringsAsFactors=FALSE)

#Build DESeq object
ddsMat <- DESeqDataSetFromMatrix(countData = countdata,
                                 colData = coldata,
                                 design = ~ condition)
nrow(ddsMat)
keep <- rowSums(counts(ddsMat)) > 1
ddsMat <- ddsMat[keep,]
nrow(ddsMat)


vsd <- vst(ddsMat, blind = FALSE)
head(assay(vsd), 3)
colData(vsd)


rld <- rlog(ddsMat, blind = FALSE)
head(assay(rld), 3)


library("dplyr")
library("ggplot2")

ddsMat <- estimateSizeFactors(ddsMat)

df <- bind_rows(
  as_data_frame(log2(counts(ddsMat, normalized=TRUE)[, 1:2]+1)) %>%
    mutate(transformation = "log2(x + 1)"),
  as_data_frame(assay(vsd)[, 1:2]) %>% mutate(transformation = "vst"),
  as_data_frame(assay(rld)[, 1:2]) %>% mutate(transformation = "rlog"))

colnames(df)[1:2] <- c("x", "y")  

ggplot(df, aes(x = x, y = y)) + geom_hex(bins = 80) +
  coord_fixed() + facet_grid( . ~ transformation)  


sampleDists <- dist(t(assay(vsd)))
sampleDists
library("pheatmap")
library("RColorBrewer")
sampleDistMatrix <- as.matrix( sampleDists )
rownames(sampleDistMatrix) <- paste( vsd$dex, vsd$cell, sep = " - " )
colnames(sampleDistMatrix) <- NULL
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
pheatmap(sampleDistMatrix,
         clustering_distance_rows = sampleDists,
         clustering_distance_cols = sampleDists,
         col = colors)

plotPCA(vsd, intgroup = "condition")
pcaData <- plotPCA(vsd, intgroup = "condition", returnData = TRUE)
pcaData
percentVar <- round(100 * attr(pcaData, "percentVar"))

ggplot(pcaData, aes(x = PC1, y = PC2, color = condition)) +
  geom_point(size =3) +
  xlab(paste0("PC1: ", percentVar[1], "% variance")) +
  ylab(paste0("PC2: ", percentVar[2], "% variance")) +
  coord_fixed() +
  ggtitle("PCA with VST data")


dds <- DESeq(ddsMat)
res <- results(dds)
res
summary(res)


res.05 <- results(dds, alpha = 0.05)
table(res.05$padj < 0.05)
summary(res.05)


resLFC1 <- results(dds, lfcThreshold=0.5)
table(resLFC1$padj < 0.1)
sum(res$pvalue < 0.05, na.rm=TRUE)
sum(!is.na(res$pvalue))
summary(resLFC1)
#Hence, if we consider a fraction of 10% false positives acceptable,
# we can consider all genes with an adjusted p value below 10% = 0.1 as significant. 
sum(res$padj < 0.1, na.rm=TRUE)
#We subset the results table to these genes and then sort it by the log2 fold change estimate to get the significant genes
resSig <- subset(res, padj < 0.1)
summary(resSig)
#..with the strongest downregulation
head(resSig[ order(resSig$log2FoldChange), ])

#..with the strongest upregulation
head(resSig[ order(resSig$log2FoldChange, decreasing = TRUE), ])

#plot individual genes: Normalized counts for a single gene over treatment group.
topGene <- rownames(res)[which.min(res$padj)]
plotCounts(dds, gene = topGene, intgroup=c("condition"))

#ggplot
library("ggbeeswarm")
geneCounts <- plotCounts(dds, gene = topGene, intgroup = c("condition", "sample"),
                         returnData = TRUE)
ggplot(geneCounts, aes(x = condition, y = count, color = sample)) +
  scale_y_log10() +  geom_beeswarm(cex = 3)

#MA plot

resultsNames(dds)
res <- lfcShrink(dds, coef="condition_control_vs_case", type="apeglm")
plotMA(res, ylim = c(-5, 5))


#MA plot of changes induced by treatment
res.noshr <- results(dds, name="condition_control_vs_case")
plotMA(res.noshr, ylim = c(-5, 5))

# individual genes on MA plot
plotMA(res, ylim = c(-5,5))
topGenes <- rownames(res)[which.min(res$padj)]
with(res[topGene, ], {
  points(baseMean, log2FoldChange, col="dodgerblue", cex=2, lwd=2)
  text(baseMean, log2FoldChange, topGene, pos=2, col="dodgerblue")
})

# the histogram of the p values 
hist(res$pvalue[res$baseMean > 1], breaks = 0:20/20,
     col = "grey50", border = "white")

# Heatmap

library("genefilter")
topVarGenes <- head(order(rowVars(assay(rld)), decreasing = TRUE), 100)
mat  <- assay(rld)[ topVarGenes, ]
mat  <- mat - rowMeans(mat)
anno <- as.data.frame(colData(rld)[, c("condition","sample")])
pheatmap(mat, annotation_col = anno)


##volcano plot
library(EnhancedVolcano)
EnhancedVolcano(res,
                lab = rownames(res),
                x = 'log2FoldChange',
                y = 'pvalue',
                xlim = c(-7.5, 7.5), title = 'Control versus Case', pCutoff = 0.05, FCcutoff = 1.0, pointSize = 3.0, 
                labSize = 5.0, 
                legendPosition = 'right', legendLabSize = 16,
                legendIconSize = 12.0)


# #annotation
# library("AnnotationDbi")
# library("org.Hs.eg.db")
# columns(org.Hs.eg.db)
# ens.str <- substr(rownames(res), 1,50)
# res$symbol <- mapIds(org.Hs.eg.db,
#                      keys=ens.str,
#                      column="SYMBOL",
#                      keytype="ENSEMBL",
#                      multiVals="first")
# 
# 
# res$entrez <- mapIds(org.Hs.eg.db,
#                      keys=ens.str,
#                      column="ENTREZID",
#                      keytype="GENENAME",
#                      multiVals="first")
# 
# resOrdered <- res[order(res$pvalue),]
# head(resOrdered)
# 
# #export data
# resOrderedDF <- as.data.frame(resOrdered)
# write.csv(resOrderedDF, file = "12-26results.csv")

# OR use biomart


## biomart alone for annotation
res$ensembl <- sapply( strsplit( rownames(res), split="\\+" ), "[", 1 )
library( "biomaRt" )
ensembl = useMart( "ensembl", dataset = "hsapiens_gene_ensembl" )
genemap <- getBM( attributes = c("ensembl_gene_id", "hgnc_symbol", "chromosome_name",'strand','band'),
                  filters = "ensembl_gene_id",
                  values = res$ensembl,
                  mart = ensembl )
idx <- match( res$ensembl, genemap$ensembl_gene_id )
# res$entrez <- genemap$entrezgene[ idx ]
res$hgnc_symbol <- genemap$hgnc_symbol[ idx ]
res$chromosome_name <- genemap$chromosome_name [idx]
res$strand <- genemap$strand [idx]
res$band <- genemap$band [idx]
res$description <- genemap$description [idx]
head(res,4)
write.csv(res, file="annotated_results.csv")


# ## copy the column with symbol(gene ids) into a csv file no need to do this if using the above biomart script
# DS = read.csv("C:/Users/Nikon/Desktop/Sneha/RNAseq/Bulk Seq/Sep-Oct2019/STAR_Alignment/12-26_STARDEG_results.csv")
# DT= read.csv ("C:/Users/Nikon/Desktop/Sneha/RNAseq/Bulk Seq/Sep-Oct2019/STAR_Alignment/t2g.csv")
# library(dplyr)
# 
# GENE_ENS <-merge(x=DS, y=DT, by='GeneID', all.x=TRUE) ## then use this file to attach to the resOrdered or res file that was previously annotated
# 
# write.csv(GENE_ENS, file = "GENE_ENS_STARDEG.csv")

##volcano plot
STAR_DEG = read.csv("C:/Users/Nikon/Desktop/Sneha/RNAseq/Bulk_Seq/Sep-Oct2019/STAR_Alignment/DEGvolcano.csv", header = TRUE)
library(EnhancedVolcano)
EnhancedVolcano(DS,
                lab = rownames(DS),
                x = 'log2FoldChange',
                y = 'pvalue',
                xlim = c(-7.5, 7.5), title = 'Control versus Case', pCutoff = 0.05, FCcutoff = 1.0, pointSize = 3.0, 
                labSize = 5.0, 
                legendPosition = 'right', legendLabSize = 16,
                legendIconSize = 12.0)

### result heatmaps
downdeg <- read.csv (file.path ("C:/Users/Sneha/Desktop/DownDEG.csv"), header = TRUE, stringsAsFactors=FALSE, row.names = 2)
res0.05 <- subset(downdeg, downdeg$log2FoldChange > 1)
sigGenes <- rownames(res0.05)
rows <- match(sigGenes, row.names(rld))
mat <- assay(rld)[rows,]
anno <- as.data.frame(colData(rld)[, c("condition","sample")])
pheatmap(mat, annotation_col = anno)


DSdeg <- read.csv (file.path ("C:/Users/Sneha/Desktop/22qgfp.csv"), header = TRUE, stringsAsFactors=FALSE, row.names = 2)
# res0.05 <- subset(downdeg, downdeg$log2FoldChange > 1)
sigGenes <- rownames(DSdeg)
rows <- match(sigGenes, row.names(rld))
mat <- assay(rld)[rows,]
anno <- as.data.frame(colData(rld)[, c("condition","sample")])
pheatmap(mat, annotation_col = anno)


