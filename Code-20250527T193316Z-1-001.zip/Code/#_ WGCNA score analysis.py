#%% WGCNA score analysis
##rom gprofiler import GProfiler

#%%
from csv import writer
from distutils.file_util import write_file
from errno import ENOLCK
from importlib.resources import as_file
import matplotlib.pyplot as plt
import os
import pandas as pd
import seaborn as sns
import scanpy as sc
from typing import Dict, Sequence

#%%

adata= sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")

#%%
module1= (pd.read_csv("control.module.genes1.csv")).astype(str)
module2= (pd.read_csv("control.module.genes2.csv")).astype(str)
module3= (pd.read_csv("control.module.genes3.csv")).astype(str)

genes= {
 'module1': set(['STMN2','NEUROD6','NTS','LHX1','SCGN','CALB2','NNAT','CRABP1','TAC1','BHLHE22','MAB21L1','NEUROD2','RTN1','MT.ATP6','NHLH1','IGFBP5','CSRP2','SOX4','NRN1','SLA','ARPP21','MT.ND3','S100A10','LMO3','MT.CYB','SCG2','NFIB','DCX','MEF2C','GAP43','SYT1','MT.CO2','C11orf96','CADM2','SSTR2','RELN','FABP5','MT.CO3','LHX1.DT','PBX3','GRIA2','NEFL','CNTNAP2','ATF5','FEZF1','SOX11','ONECUT3','THSD7A','NFIA','NRXN1','MAB21L2','TUBB3','FEZF2','SLN','NTM','RASD1','DCLK2','GUCY1A1','AC004158.1','BCL11B','IGFBPL1','STMN4','PCSK1N','CAMK2N1','MT.CO1','NSG2','MYT1L','BCL11A','LHX5.AS1','NXPH1','CDH7','RUNX1T1','NEUROG2','ZEB2','MT.ND5','MT.ND2','FBXO2','SYNPR','ZBTB18','GPM6A','LHX9','PCDH9','RPH3A','CELF4','TP73','PRDM8','CD24','NRP2','ARL4D','SLC32A1','TUBB2A','SNCA','MT.ND4','VSTM2A','EBF3','UNCX','CRYM','OLFM1','LUZP2','MT.ND1','PLXNA2','TTC9B','SCG5','ANK3','NCAN','BEX1','MIAT','ACAT2','CA9','SHTN1','DIRAS3','GPR22','TMEFF2','SCG3','RIPOR2','FSTL5','PDZRN3','SEZ6L2','NPTX1','GLRA2','CALY','SAMD3','CARTPT','NEGR1','CPE','CAMKV','MLLT11','TBR1','TAGLN3','INA','EBF1','SERPINI1','NSG1','PDE1A','CRMP1','KHDRBS3','OPRM1','RALYL','MAPT','ONECUT2','CDKN2D','ELAVL4','SYT4','NELL2','CHODL','ZNF804A','MIR124-1HG','NECAB1','CNIH2','NEUROD1']),
 'module2': set(['VIM','ID4','FABP7','SFRP1','CLU','SOX2','TTYH1','METRN','MIR9-1HG','IGFBP2','B2M','ZFP36L1','GPM6B','HES1','PANTR1','ARX','QKI','EMX2','SYNE2','LHX2','GNG5','SOX3','ANXA2','RPS27L','ENO1','FGFBP3','AMBN','VCAN','DOK5','PAX6','CD99','PON2','ZFP36L2','SOX9','RPS6','IFI44L','NES','ANXA5','EMP3','TIMP1','POU3F3','PHGDH','HES4']),
 'module3': set(['ID1','UBE2C','PTN','CENPF','TOP2A','HES5','MKI67','NEAT1','HMGB2','PCP4','NUSAP1','CDC20','ASPM','PTTG1','HES6','CCNB1','CCNB2','LDHA','BCAN','H1.5','MEIS2','H3C2','TPX2','BIRC5','HOPX','PCLAF','AIF1','NUF2','SCRG1','SFRP2','H3C4','LGALS1','SIX3','DLGAP5','ASCL1','IER2','CD9','PBK','CALB1','NR2F2','CDK1','H1.3','CENPE','NDUFA4L2','PIMREG','JUN','GTSE1','PLK1','C1QL1','SLC1A3','DCT','NEK2','PIF1','CENPA','TYMS','AURKB','SNTG1','NMU','AC025171.3','HMGN2','PRC1','SMC4','FAM181B','DBI','H2AX','TSHZ2','SGO2','PURPL','NEUROD4','H1.2','CCNA2','H2AC11','POU3F2','CDCA3','LUM','MXD3','TUBA1B','TCF4','AURKA','GPNMB','OLFM3','ARL4C','ALDH1A1','RRM2','GAS1','ZNF503','BNIP3','CDK2AP1','SPC25','LINC01551','KIF2C','ZNF704','KNL1','CKS2','MAD2L1','CENPW','GINS2','DDIT3','SERPINF1','H1.4','EZR','GPC3','EMX1','CENPU','UBB','SULF1','PALMD','CKS1B','HMMR','CDCA8','TMEM123','MIS18BP1','GAS2L3','IQGAP2','DLL1','ETV1','HELLS','NDC80','CLSPN','TCIM','CKAP2L','LINC01965','HEY1','TUBA1C','MFNG','H2AC20','LINC00461','KRT8','TROAP','LIX1','SEMA5A','RPS20','PCSK9','H2AC16','KIF11','TACC3','MDK','NR4A2','RASGRP1','H2BC9','GATM','MIR99AHG','B3GAT2','ATAD2','PHLDA1','TRIB3','SGO1','MSMO1','HERPUD1','ESCO2','ZWINT','PLPP3','KIFC1','RAD51AP1','AL139246.5','KIF23','SOX6','FTL','KIF15','HMGA2'])
}
# %%


#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]

    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)

#%%
data = adata[adata.obs["timepoint"]=="70d"]

# %%
sc.pl.violin(
   data,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'violinwgcna.pdf',
)


#%%

adata.obs.to_csv("WGCNAscores.csv")

# %%
#En lineage WGCNA analysis 


genes= {
 'module2': set(['UBE2C','CENPF','TOP2A','MKI67','NUSAP1','CDC20','ASPM','PENK','CCNB1','CCNB2','H1.5','H3C2','TPX2','BIRC5','PCLAF','NUF2','SFRP2','DLGAP5','ASCL1','PBK','CDK1','H1.3','CENPE','PIMREG','GTSE1','PLK1','C1QL1','NEK2','PIF1','CENPA','AURKB','HSPA6','PRC1','SMC4','SGO2','CCNA2','H2AC11','CDCA3','MXD3','TUBA1B','AURKA','CCN1','RRM2','LINC01840','SPC25','KIF2C','KNL1','CKS2','MAD2L1','CENPW','AC011461.1','H1.4','CENPU','HMMR','CDCA8','AC126175.2','MIS18BP1','GAS2L3','IQGAP2','NDC80','CLSPN','CKAP2L','UBE2S','TUBA1C','TROAP','RPS20','KIF11','TACC3','ST6GAL2.IT1','ATAD2','ZNF878','SGO1','ESCO2','ZWINT','KIFC1','RAD51AP1','LINC02513','KIF23','SOX6','KIF15' ]),
 'module3': set(['NEUROD6','NTS','NNAT','BHLHE22','NEUROD2','IGFBP5','CSRP2','SOX4','NRN1','SLA','ARPP21','NFIB','SYT1','C11orf96','SSTR2','GRIA2','NEFM','NFIA','NRXN1','GUCY1A1','AC004158.1','BCL11B','IGFBPL1','STMN4','NSG2','BCL11A','CDH7','RUNX1T1','ZEB2','FBXO2','ZBTB18','CELF4','NRP2','CRYM','OLFM1','PLXNA2','SCG5','ANK3','NCAN','SHTN1','SCG3','SEZ6L2','NPTX1','CALY','CPE','CAMKV','TAGLN3','SERPINI1','PDE1A','KHDRBS3','ELAVL4','SYT4','NELL2','MIR124-1HG','NEUROD1']),
 'module4': set(['STMN2','CALB2','RTN1','DCX','GAP43','CNTNAP2','THSD7A','TUBB3','PCSK1N','CAMK2N1','MYT1L','GPM6A','CD24','TUBB2A','SNCA','TTC9B','BEX1','MLLT11','TBR1','INA','NSG1','CRMP1','MAPT','CDKN2D','CNIH2']),
 'module7': set(['RSPO3','TPBG','RSPO2','MSX1','PLS3','ZNF503','GJA1','ADRA2A','NDNF','NR4A2']),
 'module9': set(['VIM','ID4','FOS','PTN','HES5','FABP7','SFRP1','CLU','HMGB2','SOX2.OT','SOX2','TTYH1','PTTG1','SAT1','METRN','MIR9-1HG','IGFBP2','EGR1','LDHA','BCAN','MEIS2','HOPX','B2M','ZFP36L1','F3','IER2','GPM6B','HES1','PANTR1','PTPRZ1','JUN','SLC1A3','FAM107A','ARX','TYMS','QKI','HMGN2','IFITM3','BST2','EMX2','DBI','SYNE2','H2AX','H1.2','LHX2','HTRA1','SPARC','GNG5','CRABP2','SOX3','ANXA2','TCF4','RPS27L','ENO1','OLFM3','TKTL1','FGFBP3','AMBN','VCAN','GAS1','BNIP3','DOK5','CDK2AP1','LINC01551','PAX6','GINS2','BTG2','BTG1','CD99','PON2','EZR','CCND1','ZFP36L2','GPC3','SP8','SOX9','CKS1B','RPS6','FAM162A','TMEM123','IFI44L','NES','HELLS','TCIM','LINC01965','HEY1','LINC00461','LIX1','CD63','SEMA5A','ANXA5','PCSK9','CDO1','SNCG','MDK','EMP3','TIMP1','RASGRP1','TXNIP','GATM','MIR99AHG','B3GAT2','P4HA1','MASP1','POU3F3','PHLDA1','ZFHX4','PLPP3','PHGDH','AL139246.5','HES4','CASC15','HMGA2']),
 'module10':set(['MT.ATP6','MT.ND3','LMO3','MT.CYB','MT.CO2','RELN','FABP5','MT.CO3','ATF5','NTM','MT.CO1','LHX5.AS1','MT.ND5','MT.ND2','SYNPR','MT.ND4','VSTM2A','UBB','MT.ND1','IFI6','MIAT','ACAT2','DIRAS3','GPR22','FSTL5','SMOC1','SAMD3','CARTPT','NEGR1','KCNQ5.IT1.retired','NECAB1']),
}



#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)



# %%
data = adata[adata.obs["timepoint"]=="70d"]

# %%
ENdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin(["RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"])]


# %%
sc.pl.violin(
   ENdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'ENlinviolinwgcna.pdf',
)


# %%
ENdata.obs.to_csv("ENlin_WGCNAscores.csv")

# %%
# Only nEN and EN clusters

#%%
adata= sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")

#%%
genes= {
 'module7': set(['STMN2','MT.ATP6','MT.ND3','MT.CYB','GAP43','MT.CO2','FABP5','MT.CO3','TUBB3','PCSK1N','CAMK2N1','MT.CO1','MT.ND5','MT.ND2','TUBA1B','GPM6A','TUBB2A','MT.ND4','MT.ND1','TUBB4B','TTC9B','BEX1','MLLT11','CRMP1','CDKN2D','MT.ND6','CNIH2']),
 'module1': set(['NEUROD6','NEUROD2','CSRP2','SOX4','SLA','NFIB','SSTR2','CNTNAP2','NFIA','FEZF2','AC004158.1','BCL11B','BCL11A','NEUROG2','ZEB2','ZBTB18','LINC01551','HEY1','PDE1A']),
}

#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)

#%%
data = adata[adata.obs["timepoint"]=="70d"]
ENdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin([ "nEN-early", "nEN-late", "EN"])]



# %%
sc.pl.violin(
   ENdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'ENl70Dviolinwgcna.pdf',
)


# %%
ENdata.obs.to_csv("EN70D_WGCNAscores.csv")



###################################################

#%%
#150D EN lineage
adata= sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")

#%%
genes= {
 'module2': set(['UBE2C','CENPF','TOP2A','MKI67','NUSAP1','CDC20','ASPM','CCNB1','CCNB2','TPX2','BIRC5','NUF2','ZFP36L1','SFRP2','DLGAP5','PBK','CDK1','CENPE','PIMREG','GTSE1','PLK1','NEK2','PIF1','CENPA','AURKB','NMU','PRC1','SGO2','CCNA2','CDCA3','MXD3','SOX3','ANXA2','AURKA','CCN1','RRM2','CDKN3','SPC25','KIF2C','KNL1','CENPW','CD99','HMMR','LINC01896','CDCA8','MIS18BP1','IQGAP2','NDC80','CKAP2L','TROAP','KIF11','TACC3','OLIG1','SGO1','PLPP3','KIFC1','KIF23','KIF15']),
 'module3': set(['NEUROD6','BHLHE22','NEUROD2','CSRP2','SOX4','SLA','NFIB','DCX','SSTR2','SOX11','NTM','AC004158.1','IGFBPL1','ENC1','MYT1L','NEUROG2','ZEB2','ZBTB18','GPM6A','TCF4','PRDM8','CD24','POU3F1','SEMA3C','PALMD','PLXNA2','ADRA2A','MIAT','MIR100HG','TBR1','MIR124-1HG']),
 'module5': set(['SYT1','GRIA2','CNTNAP2','THSD7A','NEFM','BCL11B','STMN4','CAMK2N1','RUNX1T1','CELF4','NRP2','SNCA','OLFM1','TTC9B','SCG5','ANK3','BEX1','SEZ6L2','CALY','INA','NSG1','MAPT','CDKN2D','SYT4']),
 'module10': set(['STMN2','ID2','RTN1','GAP43','CADM2','GADD45G','TUBB3','PCSK1N','NSG2','BCL11A','ARL4C','VCAN','TUBB2A','SCG3','CPE','MLLT11','CRMP1','ELAVL4']),
 'module15': set(['MALAT1','MEIS2','PLCG2','RND3','INSM1','ARL4D','ZNF704','LINC00461','TXNIP','TAGLN3','CASC15']),
 'module17': set(['ID3','PTN','HES5','NEAT1','SFRP1','CLU','PMP2','TTYH1','MIR9-1HG','IGFBP2','CTSH','BCAN','H4C3','H3C2','DLX2','PCLAF','B2M','ANXA1','LGALS1','SIX3','MSX1','CD9','GPM6B','HES1','FABP5','PTPRZ1','ATP1A2','JUN','SLC1A3','TMEM78','MSX2','NTRK2','S100A11','NFIA','TYMS','TNC','QKI','FAM181B','DBI','SYNE2','GNG5','H2AC11','RPS27L','GSX2','ENO1','CDK2AP1','PRRX1','SHISA3','PAX6','CEBPD','TSC22D4','EZR','ZFP36L2','NUDT4','AL356113.1','SOX9','CENPU','RPS6','TMEM123','SOCS3','ZFP36','ETV1','CLSPN','ACAT2','HEY1','ACTC1','LIX1','CD63','SEMA5A','RPS20','CDO1','H2AC16','PDZRN3','EMP3','TIMP1','CXCL2','B3GAT2','ATAD2','CDK6','MASP1','ESCO2','ZWINT','RAD51AP1','PHGDH','TPM2','HES4','SOX6','AC005954.2','NOG','HMGA2']),
}

#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)



# %% Subset EN lineage

data = adata[adata.obs["timepoint"]=="150d"]

# %%
ENdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin(["RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"])]



# %%
sc.pl.violin(
   ENdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'ENlin150Dviolinwgcna.pdf',
)


# %%
ENdata.obs.to_csv("ENlin150_WGCNAscores.csv")

# %%

######################################


#%%
#150D IN lineage
adata= sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")

#%%
genes= {
 'module2': set(['ID3','ID1','ID4','AQP4','FOS','PTN','NEAT1','FABP7','ID2','CLU','LGALS3','PMP2','TTYH1','AGT','METRN','MIR9-1HG','IGFBP2','BCAN','IGFBP5','HOPX','B2M','SFRP2','ANXA1','CD9','GPM6B','HES1','PANTR1','PTPRZ1','ATP1A2','JUN','C1QL1','SLC1A3','NTRK2','FAM107A','TNC','CA2','FAM181B','DBI','LHX2','GNG5','ANXA2','ENO1','CCN1','TNFRSF12A','DOK5','CDK2AP1','PRRX1','CD99','TSC22D4','CRYM','EZR','HEPN1','GJA1','NUDT4','SOX9','LINC01896','RPS6','IFI6','IQGAP2','NES','ZFP36','NCAN','LINC01965','HEY1','CD63','SEMA5A','ANXA5','CDO1','EMP3','P4HA1','TIMP3','FGFR3','PLPP3','SPHK1','FTL']),
 'module3': set(['UBE2C','CENPF','TOP2A','MKI67','NUSAP1','CDC20','AC009682.1','ASPM','CCNB1','CCNB2','H3C2','TPX2','BIRC5','PCLAF','NUF2','DLGAP5','PBK','CDK1','CENPE','PIMREG','GTSE1','NEK2','PIF1','CENPA','TYMS','AURKB','HELT','PRC1','SGO2','H2AC11','MXD3','AURKA','GSX2','RRM2','GAS1','CDKN3','SPC25','KIF2C','KNL1','MAD2L1','CENPW','GINS2','CENPU','H19','AC079209.2','HMMR','CDCA8','MIS18BP1','LMO1','HELLS','NDC80','CLSPN','CKAP2L','MFNG','TROAP','H2AC16','KIF11','TACC3','H2BC9','ATAD2','SGO1','ESCO2','ZWINT','KIFC1','RAD51AP1','KIF23','KIF15']),
 'module5': set(['CRH','IGFBP7','PTGDS','APOE','CHCHD2','SOX2','CST3','EGR1','LDHA','MT2A','CSRP2','CCL2','SCRG1','LGALS1','IER2','FABP5','MSX2','EMX2','SYNE2','JUNB','SYNM','RPS27L','HLA.DRA','BNIP3','SHISA3','DDIT4','PRPH','BTG2','PON2','TUBB4B','FAM162A','SOCS3','TCIM','TUBA1C','GADD45A','LIX1','SERPINE2','B3GAT2','LRRC10B','MSMO1','PHGDH']),
 'module10': set(['CTSH','EDNRB','S100B','FRZB','SPARC','DAAM2','CEBPD','IFI44L','S100A16','TIMP1','NQO1','BBOX1','MASP1']),
 'module11': set(['SFRP1','SAT1','MT-ATP6','MT-ND3','ASCL1','MT-CYB','MT-CO2','MT-CO3','MT-CO1','PPP1R17','MT-ND5','MT-ND4','SERPINF1','CCND1','ETV1','CXCR4','AL139246.5','HES4','MT-ND6']),
 'module13': set(['CRYAB','CXCL14','VIM','SPARCL1','GFAP','HES5','NPY','MT3','ZFP36L1','RGS16','QKI','NMU','GADD45B','HTRA1','PMEL','GPNMB','ISG15','DDIT3','ZFP36L2','UBB','AC012181.2','PLAAT3','GATM','MIR99AHG','BAMBI','PHLDA1','LMO4','TPM2','RAMP1','NOG','PLP1']),
 'module16': set(['DLX6-AS1','MALAT1','DLX5','SCGN','SOX2-OT','GAD2','SOX4','DLX2','DLX1','RBP1','LMO3','NFIB','DCX','SP9','C11orf96','NR2F2','H1-3','PLCG2','LAMP5','SOX11','GADD45G','ARX','TUBB3','SNTG1','RND3','DLX6','DCLK2','AC004158.1','BCL11B','H1-2','CAMK2N1','LINC01305','BCL11A','AC017053.1','ZEB2','INSM1','TCF4','ST8SIA5','RPH3A','GAD1','ARL4C','KLHL35','CD24','ARL4D','SLC32A1','ZNF704','TUBB2A','POU3F4','SEMA3C','AUXG01000058.1','MAFB','H1-4','BTG1','NRXN3','SP8','TMEM123','PROX1','GAS2L3','ADRA2A','MIAT','SHTN1','LINC00461','AC007405.2','SCG3','RIPOR2','PDZRN3','GLRA2','TXNIP','POU3F3','MLLT11','TAGLN3','CRMP1','CASC15','ELAVL4','ROBO2','CCDC88A','MIR124-1HG']),
 'module17': set(['STMN2','RTN1','KCNQ1OT1','MEIS2','SCG2','MEF2C','SYT1','SSTR2','RELN','GRIA2','NRXN1','RPRM','STMN4','PCSK1N','NSG2','MYT1L','SPOCK3','SYNPR','GPM6A','CELF4','PAX6','VSTM2A','LUZP2','PLXNA2','TTC9B','SCG5','ANK3','STXBP6','BEX1','CACNA2D3','PNOC','SEZ6L2','NEGR1','CPE','INA','NSG1','RALYL','MAPT','ONECUT2','CDKN2D','ZNF385D']),
}

#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)



# %% Subset IN lineage

data = adata[adata.obs["timepoint"]=="150d"]

# %%
INdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin(["MGE-RG", "RG-late", "MGE-IPC", "MGE-RG_IPC-div", "nIN", "IN-STR", "IN-CTX"])]



# %%
sc.pl.violin(
   INdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'INlin150Dviolinwgcna.pdf',
)


# %%
INdata.obs.to_csv("INlin150_WGCNAscores.csv")


# %%
### score some random modules
import random

#%%
genes= {
 'r1': set(random.choices(adata.var_names, k=100)),
 'r2': set(random.choices(adata.var_names, k=100)), 
 'r3': set(random.choices(adata.var_names, k=100)),
 'r4':set(random.choices(adata.var_names, k=100)),
 'r5': set(random.choices(adata.var_names, k=100)),
 'r6': set(random.choices(adata.var_names, k=100)),
 'r7': set(random.choices(adata.var_names, k=100)),
  'r8': set(random.choices(adata.var_names, k=100)),}


#%%
r= pd.DataFrame ({
 'r1':(random.choices(adata.var_names, k=100)),
 'r2':(random.choices(adata.var_names, k=100)), 
 'r3':(random.choices(adata.var_names, k=100)),
 'r4':(random.choices(adata.var_names, k=100)),
 'r5':(random.choices(adata.var_names, k=100)),
 'r6':(random.choices(adata.var_names, k=100)),
 'r7':(random.choices(adata.var_names, k=100)),
'r8':(random.choices(adata.var_names, k=100)),
})

#%%
r.to_csv("E:/Sneha/RNAseq/Scseq/wgcna/ENlin/randomcodules.csv")
#%%

i=0
for i in range (10):

 r[i]= pd.DataFrame(random.choices(adata.var_names, k=100))


# %%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)
# %%
# %% Subset EN lineage

data = adata[adata.obs["timepoint"]=="70d"]

# %%
ENdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin(["RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"])]



# %%
sc.pl.violin(
   ENdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'ENlin170DRANDOMmoduleDviolinwgcna.pdf',
)


# %%
ENdata.obs.to_csv("ENlin70RANDOM_WGCNAscores.csv")


# %%
#or 70DIV IN
genes= {
"module2": set(['VIM','ID4','FOS','HES5','FABP7','CLU','SOX2','TTYH1','METRN','MIR9.1HG','EGR1','ZFP36L1','IER2','NFIB','GPM6B','PANTR1','PTPRZ1','SLC1A3','NFIA','QKI','FEZF2','EMX2','DBI','SYNE2','LHX2','GNG5','SOX3','ANXA2','RPS27L','FGFBP3','VCAN','CD99','PON2','EZR','EMX1','RPS6','EMP3','P4HA1','FGFR3','PHGDH','HES4']),
"module 12": set(['STMN2','NNAT','RTN1','SOX4','DCX','GAP43','PBX3','GRIA2','NEFL','SOX11','NEFM','NRXN1','TUBB3','STMN4','PCSK1N','CAMK2N1','NSG2','RUNX1T1','GPM6A','CELF4','CD24','NRP2','TUBB2A','SNCA','OLFM1','ANK3','BEX1','SCG3','SEZ6L2','CALY','CPE','MLLT11','TAGLN3','INA','NSG1','CRMP1','MAPT','CDKN2D','ELAVL4','ROBO2','CCDC88A','CNIH2'])
}

#%%%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


    # %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)



# %% Subset IN lineage

data = adata[adata.obs["timepoint"]=="70d"]

# %%
INdata = data[data.obs["nowakowski.fine.noglyc_unmapped"].isin(["MGE-RG", "RG-late", "MGE-IPC", "MGE-RG_IPC-div", "nIN", "IN-STR", "IN-CTX"])]



# %%
sc.pl.violin(
   INdata,
    keys= genes,
    groupby="genotype",
    cut=0,
    save= 'INlin70Dviolinwgcna.pdf',
)


# %%
INdata.obs.to_csv("INlin70_WGCNAscores.csv")
# %%
