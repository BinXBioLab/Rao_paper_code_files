#%%
# Import modules
##rom gprofiler import GProfiler
from errno import ENOLCK
import matplotlib.pyplot as plt
import os
import pandas as pd
import seaborn as sns
from typing import Dict, Sequence

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Define samples to analyze
samples = ['AGGR01_mapped',]
prefix = samples[0]
prefix

#%%
# Workdir is root workspace dir
os.chdir('/Sneha/RNAseq/ScSeq/wgcna')
current = os.getcwd()
current

#%%
# Helper closures for path generation
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

#%%
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = ('E:/Sneha/RNAseq/ScSeq/AGGR01_mapped')
data = fullpath_closure(data_dir) 
out_dir = ('/Sneha/RNAseq/ScSeq/wgcna')
out = fullpath_closure(out_dir)

#%%
# Import scanpy and configure figure parameters
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150, figsize=(7,7), format ='eps')
sc.settings.figdir = out('fig_supp')

#%%
# Load main AnnData snapshot
adata = sc.read(data(f'{prefix}.final.h5ad'))
adata
# %%
adata.var_names

#%%
# Load key of cell type annotation
key = 'nowakowski.fine.noglyc_unmapped' 

#%%
# Set up g:Profiler, used to get genesets from GO terms
base_url = 'https://biit.cs.ut.ee/gprofiler_archive3/e98_eg45_p14/'
gp = GProfiler(base_url=base_url, return_dataframe=True)

#%%
# Define some genesets that are found in DEGs enrichment
genes = {
    'BP:neg_reg_neuro_diff:EN_Case_isect': set(['NR2F1', 'CNTN4', 'EPHA4', 'ENSG00000004478', 'ID3', 'HES4', 'LHX2', 'NTRK3', 'EFNB2', 'PPP3CA', 'ID1', 'SEMA6A', 'MAP4K4', 'TP73']),
    'BP:neg_reg_nerv_syst_dev:EN_Case_isect': set(['NR2F1', 'CNTN4', 'EPHA4', 'ENSG00000004478', 'ID3', 'HES4', 'LHX2', 'NTRK3', 'EFNB2', 'PPP3CA', 'ID1', 'SEMA6A', 'MAP4K4', 'TP73']),
    'CC:axon:EN_Control_isect': set(['RANBP1', 'COMT', 'RTN4R', 'ATP6AP2', 'GRIPAP1', 'GPM6A', 'AAK1', 'BSG', 'DYNC1H1', 'SYAP1', 'USP9X', 'GAD2', 'NRP2', 'FZD3', 'DMD', 'SCN9A', 'CD200', 'ANK3', 'SLC32A1', 'SCN1A', 'DST']),
    'CC:synapse:EN_Control_isect': set(['COMT', 'RPS4X', 'RTN4R', 'ATP6AP2', 'PAK3', 'GRIPAP1', 'GPM6A', 'CALY', 'AAK1', 'SYAP1', 'SYNPR', 'GAD2', 'GRIA2', 'NRP2', 'FZD3', 'DMD', 'NRXN2', 'ANK3', 'SLC32A1', 'NDFIP1', 'RTN4', 'ERBB4', 'SYT10', 'GRIA4', 'EFNB1']),
    'BP:cell_division:RGdiv_Case_isect': set(['CCNF', 'KIF20A', 'ASPM', 'PIMREG', 'SAPCD2', 'KIFC1', 'TUBA1C', 'SGO2', 'KIF18B', 'CENPE', 'HMGA2', 'TOP2A', 'MIS18BP1', 'SMC4', 'NCAPH', 'AURKA', 'CKAP2', 'CDCA2', 'NDC80', 'CCND2', 'KMT5A', 'CDC20']),
}
# Define other genesets identified from GO term (full gene set)
gos = {
    'BP:neg_reg_neuro_diff': 'GO:0045665',
    'BP:pos_reg_neuro_diff': 'GO:0045666',
    'CC:synapse': 'GO:0045202',
    'CC:dendrite': 'GO:0030425',
    'CC:axon': 'GO:0030424',
    'BP:cell_cycle': 'GO:0007049',
    'BP:mitotic_cell_cycle': 'GO:0000278',
}
# Collect gene set for each GO term defined above
for go_name, go_id in gos.items():
    genes[go_name] = set(
        gp.convert(
            organism='hsapiens', query=[go_id], target_namespace='ENSG',
        )['name'].values
    )


# %%
# Genes contains the gene sets to test
genes

#%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]
# - Deprecated methodology: for each cell, average z-score of genes in the
#   gene set. The z-score for each gene is computed on the distribution
#   along all cells
# def zscore_genes(
#     adata: sc.AnnData,
#     use_raw: bool = True, 
#     layer: str = None,
#     signatures: Dict[str, Sequence] = None,
# ):
#     """ Compute mean z-score of genesets. Only one between use_raw
#         and layer should be used. I.e. use_raw=True and layer=None
#         or use_raw=False and layer='layer_name'.
#     """
#     assert (use_raw and not layer) or (layer and not use_raw)
#     import numpy as np
#     import scanpy as sc
#     _adata = adata.copy()
#     keys = signatures.keys()
#     _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
#     if not layer:
#         _adata.X = adata.raw.X
#     else:
#         _adata.X = adata.layers[layer]
#     sc.pp.scale(_adata)
#     obs = None
#     for k in keys:
#         o = pd.DataFrame(
#             np.mean(
#                 _adata[:, list(signatures[k] & set(_adata.var_names))].X,
#                 axis=1,
#             ),
#             columns=[k],
#             index=_adata.obs_names,
#         )
#         obs = pd.concat([obs, o], axis=1)
#     return obs

# %%
# Compute score of gene sets (using log-normalized counts)
new_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=genes,
)

# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    new_obs
], axis=1)

# %%
# Save scores to file
new_obs.to_csv(
    #out(f'interim_data/monocle/genes/counts/{prefix}.score.go.csv')
out(f'{prefix}.score.go.csv')
)
# %%
# Load pseudotime indexes into AnnData
pseudotime_lin1 = pd.read_csv(out(
    'interim_data/monocle/genes/counts/'
    'cns_dev/by_lineage/monocle.lineage.1.6.pseudotime.csv'
), index_col=0)
pseudotime_lin2 = pd.read_csv(out(
    'interim_data/monocle/genes/counts/'
    'cns_dev/by_lineage/monocle.lineage.2.6.pseudotime.csv'
), index_col=0)
pseudotime_lin3 = pd.read_csv(out(
    'interim_data/monocle/genes/counts/'
    'cns_dev/by_lineage/monocle.lineage.3.6.pseudotime.csv'
), index_col=0)
pseudotime_lin4 = pd.read_csv(out(
    'interim_data/monocle/genes/counts/'
    'cns_dev/by_lineage/monocle.lineage.4.6.pseudotime.csv'
), index_col=0)
pseudotime_lin1.columns = ['pseudotime.lin1']
pseudotime_lin2.columns = ['pseudotime.lin2']
pseudotime_lin3.columns = ['pseudotime.lin3']
pseudotime_lin4.columns = ['pseudotime.lin4']
adata.obs = pd.concat([
    adata.obs,
    pseudotime_lin1, pseudotime_lin2, pseudotime_lin3, pseudotime_lin4,
], axis=1)

# %%
# Plot umap of the two pseudotime lineages
sc.pl.umap(
    adata,
    color=[
        'pseudotime.lin1', 'pseudotime.lin2',
        'pseudotime.lin3', 'pseudotime.lin4',
    ],
    cmap='viridis',
)

#%%
# Master palette for cell types
palette = ['#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc', '#f07cab', '#d30b94']

# %%
# Plot pseudotime evolution of gene set scores
for g in genes.keys():
    for x_lin in [1, 2]:
        x = f'pseudotime.lin{x_lin}'
        adata.obs[[x, g]].dropna()

        data = pd.concat([
            pd.cut(
                adata.obs[x], bins=100
            ).rename(f'{x}.bin').cat.rename_categories(
                lambda x: x.mid
            ),
            adata.obs[[g, 'genotype', key, x]]
        ], axis=1).dropna()

        grid = sns.relplot(
            data=data, x=f'{x}.bin', y=g, hue='genotype',
            palette=['#393e41', '#ca3c25'],
            hue_order=['Control', 'Case'], aspect=5,
            kind='line',
        )
        grid.map(
            sns.scatterplot, data=data, x=x, y=g, hue=key,
            palette=palette, size=1, legend='brief',
            hue_order=adata.obs[key].cat.categories,
        )
        grid.set_xlabels(x)
        grid.set_ylabels(g)
        grid.savefig(out(
            'interim_data/monocle/genes/counts/cns_dev/by_lineage/'
            f'{x}.{g}.pdf'.replace(':', '_')
        ), bbox_inches='tight')

# %%
# Check for difference in distributions of cells along pseudotime
from typing import List
# Plot cumulative distribution of cells (separately for each condition) 
# Check statistical difference using Kolgomorov-Smirnov (2 samples)
def pseudotime_curve(
    adata: sc.AnnData,
    grouping: str,
    cell_types: List[str],
    lineage: str,
    condition_lab: str = 'genotype',
    alab: str = 'Control',
    blab: str = 'Case',
):
    import numpy as np
    from matplotlib import pyplot as plt
    from scipy.stats import ks_2samp
    # Get pseudotime for cells in `cell_types`
    ptime = adata.obs.loc[
        adata.obs[grouping].isin(cell_types), lineage
    ].dropna()
    # Normalize pseudotime between 0 and 1
    ptime = (ptime - ptime.min())/(ptime.max() - ptime.min())
    # Get condition associated with each cell
    condition = adata[ptime.index].obs[condition_lab]
    step = 1 / condition.value_counts()

    yval_a = 0
    yval_b = 0
    x_a = []
    x_b = []
    y_a = []
    y_b = []

    for k, v in ptime.sort_values().items():
        if condition[k] == alab:
            x_a.append(v)
            yval_a = step[alab]
            y_a.append(yval_a)
        elif condition[k] == blab:
            x_b.append(v)
            yval_b = step[blab]
            y_b.append(yval_b)

    plt.plot(x_a, np.cumsum(y_a), c='#393e41', label=alab)
    plt.plot(x_b, np.cumsum(y_b), c='#ca3c25', label=blab)
    _, p = ks_2samp(x_a, x_b)
    plt.text(.8, 0, fr'$p =${p:.1e}')
    # plt.scatter(x, y, s=5, color=c)
    plt.xlabel('Pseudotime')
    plt.ylabel('Cumulative percentage of cells')
    plt.title(lineage)
    plt.legend()
    plt.grid(False)

# %%
# Plot diagonal trajectory
# When cell for condition a is found at a specific pseudotime,
# the trajectory moves along the x-axis (step proportional to the
# number of cells in condition a). Otherwise, the trajectory moves
# along the y-axis.
# In case of random distribution of cells along pseudotime, the trajectory
# is expected to move approximately as a diagonal line from the point (0,0)
# to the point (1,1).
from typing import List
def pseudotime_diag(
    adata: sc.AnnData,
    grouping: str,
    cell_types: List[str],
    lineage: str,
    condition_lab: str = 'genotype',
    alab: str = 'Control',
    blab: str = 'Case',
):
    import numpy as np
    from matplotlib import pyplot as plt
    # Get pseudotime for cells in `cell_types`
    ptime = adata.obs.loc[
        adata.obs[grouping].isin(cell_types), lineage
    ].dropna()
    # Normalize pseudotime between 0 and 1
    ptime = (ptime - ptime.min())/(ptime.max() - ptime.min())
    # Get condition associated with each cell
    condition = adata[ptime.index].obs[condition_lab]
    # Get step associated to each condition
    # Assumption: we are computing curve ignoring
    # differences in cell contribution between condition
    # The step is normalized depending on the number of
    # cells in each condition
    step = 1 / condition.value_counts()

    xval = 0
    yval = 0
    x = []
    y = []

    x.append(xval)
    y.append(yval)
    for k, _ in ptime.sort_values().items():
        if condition[k] == alab:
            xval += step[alab]
        elif condition[k] == blab:
            yval += step[blab]
        x.append(xval)
        y.append(yval)

    plt.plot(x, y)
    plt.plot([0,1], [0,1], 'k--')
    plt.xlabel(alab)
    plt.ylabel(blab)
    plt.title(lineage)
    plt.grid(False)

# %%
# Plot cumulative distribution curve for the two
# conditions in a specific cell type, along a specific
# lineage
pseudotime_curve(
    adata,
    grouping=key,
    cell_types=['EN'], 
    lineage='pseudotime.lin1',
)

# %%
# Plot diagonal trajectory for the two conditions in a
# specific cell type, along a specific lineage
pseudotime_diag(
    adata,
    grouping=key,
    cell_types=['EN'], 
    lineage='pseudotime.lin1',
)

# %%
# Plot cumulative distribution curve for the two
# timepoint for all cell types, along a specific
# lineage
pseudotime_curve(
    adata,
    grouping=key,
    cell_types=adata.obs[key].cat.categories, 
    lineage='pseudotime.lin1',
    condition_lab='timepoint',
    alab='70d',
    blab='150d',
)

# %%
# Plot point plot between two timepoints, of each gene set, for each
# condition and cell type separately
data = adata.obs.loc[:, ['timepoint', key, 'genotype'] + list(new_obs.columns)]
for cell_type in adata.obs[key].cat.categories:
    g = sns.PairGrid(
        data.loc[data[key].isin([cell_type]), :], y_vars=list(new_obs.columns), 
        x_vars='timepoint', height=5, aspect=1, hue='genotype',
        palette=['#393e41', '#ca3c25'], hue_order=['Control', 'Case'],
    )
    g.map(sns.pointplot, scale=1.3, errwidth=4)
    g.savefig(out(f'fig_supp/go_timepoint/pointplot.{cell_type}.pdf'))






# %%
#Define cell cycle genes from tirosh et. al. 2016
cell_cycle_genes = [x.strip() for x in open('regev_lab_cell_cycle_genes.txt')]

# %% #define cell cycle stages
genescellcycle ={
's_genes' : cell_cycle_genes[:43],
'g2m_genes': cell_cycle_genes[43:],
'cell_cycle_genes': [x for x in cell_cycle_genes if x in adata.var_names]}


# %% cellcyclge genes to test
genescellcycle


#%%
current

#%%
hallmark_G1= [x.strip() for x in open ("E:/Sneha/RNAseq/ScSeq/hallmark_reactome_G1.txt")]
#hallmark_G1_S = [x.strip() for x in open ("hallmark_reactome_G1-S.txt")]
#hallmark_G1andS = [x.strip() for x in open ("hallmark_SA_G1_and_S.txt")]
#hallmark_G2_M = [x.strip() for x in open ("E:/Sneha/RNAseq/ScSeq/hallmark_reactome_G2_G2-M.txt")]
#hallmark_M_G1 = [x.strip() for x in open ("hallmark_reactome_M-G1.txt")]
hallmark_Go_G1 = [x.strip() for x in open ("E:/Sneha/RNAseq/ScSeq/hallmark_reactome_Go-G1.txt")]
#hallmark_G1_SDNAdam = [x.strip() for x in open ("hallmark_reactome_G1-S_DNA_damage_checkpoint.txt")]
#hallmark_G2_MDNAdam = [x.strip() for x in open ("hallmark_reactome_G2-M_DNA_damage_checkpoint.txt")]
hallmark_cellcyclecontrol = [x.strip() for x in open ("E:/Sneha/RNAseq/ScSeq/hallmark_BP_positivereg_cellcycle.txt")]

#%%
hallmark_cellcycle ={
'hallmark_G1_genes' :[x for x in hallmark_G1 if x in adata.var_names],
#'hallmark_G1_S_genes' :[x for x in hallmark_G1_S if x in adata.var_names],
#'hallmark_G1andS_genes' :[x for x in hallmark_G1andS if x in adata.var_names],
#"hallmark_G2_M_genes" :[x for x in hallmark_G2_M if x in adata.var_names],
#"hallmark_M_G1_genes":[x for x in hallmark_M_G1 if x in adata.var_names],
"hallmark_Go-G1_genes" :[x for x in hallmark_Go_G1 if x in adata.var_names],
#"hallmarkG1_SDNAdam" :[x for x in hallmark_G1_SDNAdam if x in adata.var_names],
#"hallmarkG2_MDNAdam" :[x for x in hallmark_G2_MDNAdam if x in adata.var_names],
"hallmarkcellcyclecontrol" :[x for x in hallmark_cellcyclecontrol if x in adata.var_names]}

#%%

hallmark_cellcycle


#%%
# Two different ways of scoring gene sets:
# - Methodology defined in scanpy
def score_genes(
    adata: sc.AnnData,
    use_raw: bool = True, 
    layer: str = None,
    signatures: Dict[str, Sequence] = None,
):
    """ Score genesets. Only one between use_raw and layer should 
        be used. I.e. use_raw=True and layer=None or use_raw=False
        and layer='layer_name'.
    """
    assert (use_raw and not layer) or (layer and not use_raw)
    import scanpy as sc
    _adata = adata.copy()
    keys = signatures.keys()
    _adata.obs = _adata.obs.loc[:, ~_adata.obs.columns.isin(keys)] 
    if not layer:
        _adata.X = adata.raw.X
    else:
        _adata.X = adata.layers[layer]
    sc.pp.scale(_adata)
    for k in keys:
        sc.tl.score_genes(
            _adata,
            signatures[k],
            score_name=k,
            random_state=42,
        )
    return _adata.obs[keys]


# %%
# Compute score of gene sets (using log-normalized counts)
newcc_obs = score_genes(
    adata, use_raw=False, layer='sf_log1p', signatures=hallmark_cellcycle,
)
newcc_obs
# %%
# Add scores to AnnData 
adata.obs = pd.concat([
    adata.obs,
    newcc_obs
], axis=1)
adata
adata.obs


#%%



#%% Save scores to file
newcc_obs.to_csv(
    #out(f'interim_data/monocle/genes/counts/{prefix}.score.cellcyle.csv')
out(f'{prefix}.score.hallmarkcellcycle.csv')
)

# %%
# Plot point plot between two timepoints, of each gene set, for each
# condition and cell type separately
data = adata.obs.loc[:, ['timepoint', key, 'genotype'] + list(newcc_obs.columns)]
for cell_type in adata.obs[key].cat.categories:
    g = sns.PairGrid(
        data.loc[data[key].isin([cell_type]), :], y_vars=list(newcc_obs.columns), 
        x_vars='timepoint', height=5, aspect=1, hue='genotype',
        palette=['#393e41', '#ca3c25'], hue_order=['Control', 'Case'],
    )
    g.map(sns.pointplot, scale=1.3, errwidth=4)
    g.savefig(out(f'pointplot.{cell_type}.pdf'))



    # %%
    #  Plot violin of cell cycle score
    # apply subset only 70D cells
data = adata[adata.obs['timepoint']== "70d"]
data


#%%
#dataEN = data[data.obs["nowakowski.fine.noglyc_unmapped"]== "EN"]
#dataEN
for cell_type in adata.obs[key].cat.categories:
  g =  sc.pl.violin(
    data,
    keys=[
 "MEF2C"
    ],
    groupby="genotype",
    cut=0,
    save=f'MEF2C150.{cell_type}.pdf',
)
#%%
for cell_type in adata.obs[key].cat.categories:
 g = sc.pl.dotplot(
    data,
    var_names="MEF2C",
    groupby='genotype',
    color_map='viridis',
    save=f'.dotplotMEF270D.{cell_type}.pdf',
    use_raw=True,
)
#%%
dataRGdiv = data[data.obs["nowakowski.fine.noglyc_unmapped"]== "RG-div"]
dataRGdiv.obs
#%%
    sc.pl.violin(
    dataRGdiv,
    keys=[
        'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.RGdiv.pdf',
)

#%%
dataIPCdiv = data[data.obs["nowakowski.fine.noglyc_unmapped.aggr"]== "IPC-div"]
sc.pl.violin(
    dataIPCdiv,
    keys=[
            'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.IPCdiv.pdf',
)


#%%
dataRG_early =  data[data.obs["nowakowski.fine.noglyc_unmapped"]== "RG-early"]
sc.pl.violin(
    dataRG_early,
    keys=[
            'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.RGearly.pdf',
)



# %%
datanENearly =  data[data.obs["nowakowski.fine.noglyc_unmapped"]== "nEN-early"]
datanENearly.obs

sc.pl.violin(
    datanENearly,
    keys=[
            'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.nENearly.pdf',
)
# %%
# %%
dataEN =  data[data.obs["nowakowski.fine.noglyc_unmapped"]== "EN"]
dataEN.obs

sc.pl.violin(
    dataEN,
    keys=[
            'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.EN.pdf',
)

# %%

# %%
dataIPC_nEN =  data[data.obs["nowakowski.fine.noglyc_unmapped"]== "IPC-nEN"]
dataEN.obs

sc.pl.violin(
    dataIPC_nEN,
    keys=[
            'hallmark_G1_genes',
'hallmark_G1_S_genes',
'hallmark_G1andS_genes',
"hallmark_G2_M_genes",
"hallmark_M_G1_genes",
"hallmarkG1_SDNAdam",
"hallmarkG2_MDNAdam",
"hallmarkcellcyclecontrol"
    ],
    groupby="genotype",
    cut=0,
    save=f'hallmarkcellcyclescore.IPC-EN.pdf',
)



