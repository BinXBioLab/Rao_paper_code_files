setwd ("E:/Sneha/RNAseq/ScSeq/wgcna")


# # Load libraries
# library(liger)
library(Seurat)
 library(ggplot2)
 library(cowplot)
# library(arrow)
# library(feather)
# library(scWGCNA)
# library(WGCNA)
# library(tidyverse)
# library (dplyr)
# library(WGCNA)
# enableWGCNAThreads(20)
# # feather library became obsolete during the project
# # it got replaced by arrow library that provides the updated
# # `read_feather()` function
 library(feather)
# theme_set(theme_cowplot())

# Uncomment the line corresponding to the dataset to batch-correct with LIGER

prefix <- 'AGGR01'


### Generate seurat Object from coutns matrix

# Load counts matrix exrtacted from adata
#data <- as.data.frame(read_feather("E:/Sneha/RNAseq/ScSeq/wgcna/AGGR01_mapped.counts.fth"))
                      #rownames(data) <- data[,1]
                      #data <- data[,-1]

data <- read.csv("E:/Sneha/RNAseq/ScSeq/AGGR01_mapped/AGGR01.mapped.final.counts.2.csv")
                      rownames(data) <- data[,1]
                      data <- data[,-1]
# Load cell annotations
meta.data <- read.table(
  sep=',',
  header=TRUE,
  check.names=FALSE,
  paste('E:/Sneha/RNAseq/ScSeq/wgcna/obs.csv'),
  row.names=1,
)

# Create Seurat object from counts matrix
sdata <- CreateSeuratObject(
  t(data),
  project=prefix,
  assay='RNA',
  meta.data=meta.data,
)

saveRDS(sdata, file=paste(prefix, '.seurat.rds', sep='')) 
#sdata = readRDS(file=paste(prefix, '.seurat.rds', sep=''))

#normalize counts (no need to do this when starting from (adata)
# #NormalizeData
#   sdata,
#   assay = "RNA",
#   normalization.method = "LogNormalize",
#   scale.factor = 10000,
#   margin = 1,
#   verbose = TRUE,
# )

# Finad variable features: 

sdata <- FindVariableFeatures(sdata, selection.method = "vst", nfeatures = 2000)

# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(sdata), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(sdata)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 + plot2


# # Scale the data
# all.genes <- rownames(sdata)
# sdata <- ScaleData(sdata, features = all.genes)
# 
# #Plot PCA
# sdata <- RunPCA(sdata, features = VariableFeatures(object = sdata))
# print(sdata[["pca"]], dims = 1:5, nfeatures = 5)
# VizDimLoadings(sdata, dims = 1:2, reduction = "pca")
# DimPlot(sdata, reduction = "pca")
# 
# # #set idents from metadata (equivalent to obs in anndata)
# colnames(sdata[[]])
# Idents (sdata) <- 'nowakowski.fine.noglyc_unmapped'
# levels(sdata)
# # # SetIdent(sdata, save.name= "umap", value = "leiden_final" )
# # # levels(sdata)
# # # head(Idents(sdata))

head(Idents(sdata), 5)

sdata <- RunUMAP(sdata, dims = 1:10)
DimPlot(sdata, reduction = "umap")


saveRDS(sdata, file=paste(prefix, '.seurat.final.rds', sep='')) 
#sdata = readRDS(file=paste(prefix, '.seurat.final.rds', sep=''))

#subset by timepoint
timepoint = "70d"

sdata_sub<- subset(x = sdata, subset = timepoint == "70d")
DimPlot(sdata_sub, reduction = "umap")

saveRDS(sdata_sub, file=paste(prefix, timepoint, '.seurat.final.rds', sep='.')) 

#sdata_sub= readRDS(file=paste(prefix, timepoint, '.seurat.rds', sep='.')) 

sdata_sub<- subset(x = sdata_sub, subset= genotype == "Control")
DimPlot(sdata_sub, reduction = "umap")
saveRDS(sdata_sub, file=paste(prefix, timepoint, '.seurat.final.control.rds', sep='.')) 
#sdata_sub = readRDS(file=paste(prefix, timepoint, '.seurat.final.control.rds', sep='.'))


# # # construct metacells by ODC group, condition
# sdata_sub$metacell_group <- paste0(
# as.character(sdata_sub$nowakowski.fine.noglyc_unmapped.aggr)
# )
# 
# # 
# genes.keep <- FindVariableFeatures(sdata_sub)
# # 
# # # loop through each group and construct metacells
# seurat_list <- list()
# for(group in unique(sdata_sub$metacell_group)){
# print(group)
#   
# #   sda
# cur_seurat <- subset(sdata_sub, metacell_group == group)
# cur_seurat <- cur_seurat[genes.keep,]
# #   
# cur_metacell_seurat <- scWGCNA::construct_metacells(
# cur_seurat, name=group,
# k=100, reduction= "umap",
# assay='RNA', slot='data'
# )
# cur_metacell_seurat$nowakowski.fine.noglyc_unmapped.aggr <- as.character(unique(cur_seurat$nowakowski.fine.noglyc_unmapped.aggr))
# seurat_list[[group]] <- cur_metacell_seurat
#  }
# # 
# # # merge all of the metacells objects
# # metacell_seurat <- merge(seurat_list[[1]], seurat_list[2:length(seurat_list)])
# # saveRDS(metacell_seurat, file='data/metacell_seurat.rds')
# 
# 
# library(tidyverse)
# library(WGCNA)
# enableWGCNAThreads(8)
# 
# 
# # how many groups are there
# nclusters <- length(unique(cur_seurat$nowakowski.fine.noglyc_unmapped.aggr))
# 
# # # which genes are we using ?
# genes.keep <- FindVariableFeatures(datExpr)
# genes.use <- rownames(cur_seurat)
# length(genes.use)
# head(genes.use)
# # 
# # # cell meta-datsda table
# targets <- cur_seurat@meta.data
# head(targets)
# 
# # vector of cell conditions
# group <- as.factor(cur_seurat$genotype)
# length (group)
# 
# # format the expression matrix for WGCNA
# datExpr <- as.data.frame(GetAssayData(sdata_sub, assay='RNA', slot='data')[genes.use,])
# datExpr <- as.data.frame(t(datExpr))
# 
# # only keep good genes:
# datExpr <- datExpr[,goodGenes(datExpr)]
# 
# 
# 
# saveRDS(datExpr, file= (paste(prefix, timepoint, '.WGCNA.datExpr.Control.rds', sep=".")))
# datExpr= readRDS (file= (paste(prefix, timepoint, '.WGCNA.datExpr.Control.rds', sep=".")))
# 
# 
# # Choose a set of soft-thresholding powers
# powers = c(seq(1,10,by=1), seq(12,30, by=2));
# 
# # Call the network topology analysis function for each set in turn
# powerTable = list(
#   data = pickSoftThreshold(
#     datExpr,
#     powerVector=powers,
#     verbose = 100,
#     networkType="signed",
#     corFnc="bicor"
#   )[[2]]
# );
# 
# # Plot the results:
# pdf("figures/1_Power.pdf", height=10, width=18)
# 
# colors = c("blue", "red","black")
# # Will plot these columns of the returned scale free analysis tables
# plotCols = c(2,5,6,7)
# colNames = c("Scale Free Topology Model Fit", "Mean connectivity", "mean connectivity",
#              "Max connectivity");
# 
# # Get the minima and maxima of the plotted points
# ylim = matrix(NA, nrow = 2, ncol = 4);
# for (col in 1:length(plotCols)){
#   ylim[1, col] = min(ylim[1, col], powerTable$data[, plotCols[col]], na.rm = TRUE);
#   ylim[2, col] = max(ylim[2, col], powerTable$data[, plotCols[col]], na.rm = TRUE);
# }
# 
# # Plot the quantities in the chosen columns vs. the soft thresholding power
# par(mfcol = c(2,2));
# par(mar = c(4.2, 4.2 , 2.2, 0.5))
# cex1 = 0.7;
# 
# for (col in 1:length(plotCols)){
#   plot(powerTable$data[,1], -sign(powerTable$data[,3])*powerTable$data[,2],
#        xlab="Soft Threshold (power)",ylab=colNames[col],type="n", ylim = ylim[, col],
#        main = colNames[col]);
#   addGrid();
#   
#   if (col==1){
#     text(powerTable$data[,1], -sign(powerTable$data[,3])*powerTable$data[,2],
#          labels=powers,cex=cex1,col=colors[1]);
#   } else
#     text(powerTable$data[,1], powerTable$data[,plotCols[col]],
#          labels=powers,cex=cex1,col=colors[1]);
#   if (col==1){
#     legend("bottomright", legend = 'Metacells', col = colors, pch = 20) ;
#   } else
#     legend("topright", legend = 'Metacells', col = colors, pch = 20) ;
# }
# dev.off()
# 
# 

#another package
#https://github.com/CFeregrino/scWGCNA
#devtools::install_github("cferegrino/scWGCNA", ref="main")
setwd ("E:/Sneha/RNAseq/ScSeq/wgcna")
prefix = "AGGR01"
timepoint = "70d"
sdata = readRDS("AGGR01.70d..seurat.final.control.rds")

library(Seurat)
# sdata_sub = # S3 method for Seurat
#   NormalizeData(
#     sdata_sub,
#     assay = "RNA",
#     normalization.method = "LogNormalize",
#     scale.factor = 10000,
#     margin = 1,
#     verbose = TRUE,
#  )

#saveRDS(sdata_sub,'E:/Sneha/RNAseq/ScSeq/Raw/wgcna/AGGR01.70d.seurat.norm.final.control.rds')

#sdata_sub = readRDS('E:/Sneha/RNAseq/ScSeq/Raw/wgcna/AGGR01.70d.seurat.norm.final.control.rds')

library ("scWGCNA")

# Colors concordant with UMAP annotation in python
nowakowski.fine.noglyc.unmapped.colors <- c('#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc', '#f07cab', '#d30b94')
colors <- nowakowski.fine.noglyc.unmapped.colors


(DimPlot(sdata, reduction = "umap")+ scale_color_manual(values= colors))

sdata_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
(DimPlot(sdata_sub, reduction = "umap")+ scale_color_manual(values= colors))

FindVariableFeatures(sdata_sub)


sdata_sub

#calculate pseudocells

sdata_sub.pcells = calculate.pseudocells(s.cells = sdata_sub, # Single cells in Seurat object
                                          seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                          nn = 10, # Number of neighbors to aggregate
                                          reduction = "umap", # Reduction to use
                                          dims = 1:2) # The dimensions to use

#Run scWGCNA
sdata_sub.scWGCNA = run.scWGCNA(p.cells = sdata_sub.pcells, # Pseudocells (recommended), or Seurat single cells
                                 s.cells = sdata_sub, # single cells in Seurat format
                                 is.pseudocell = T, # We are using single cells twice this time
                                 features = VariableFeatures(sdata_sub, nfeatures=2000)) #rownames(sdata_sub)) # 


# Plot the gene / modules dendrogram
scW.p.dendro(scWGCNA.data = sdata_sub.scWGCNA)


#Look at the membership tables
names(sdata_sub.scWGCNA$modules)

#Let's look at the first module, "blue"
head(sdata_sub.scWGCNA$modules$'1_blue')


head(sdata_sub.scWGCNA$modules$`2_brown`)

head(sdata_sub.scWGCNA$modules$`3_turquoise`)

# Here we can see what is the expression of each co-expression module, per cell. This is in one of the list items
head(sdata_sub.scWGCNA[["sc.MEList"]]$averageExpr)

# If we want to see the average module expression per pseudocell instead of single cells, we find it here
head(sdata_sub.scWGCNA[["MEList"]]$averageExpr)


# Plot the expression of all modules at once
scW.p.expression(s.cells = sdata_sub, # Single cells in Seurat format
                 scWGCNA.data = sdata_sub.scWGCNA, # scWGCNA list dataset
                 modules = "all", # Which modules to plot?
                 reduction = "umap", # Which reduction to plot?
                 ncol=3) # How many columns to use, in case we're plotting several?

#Plot only the expression of the first module, "blue"
scW.p.expression(s.cells = sdata_sub,
                 scWGCNA.data =sdata_sub.scWGCNA,
                 modules = 10,
                 reduction = "umap")

# First generate the networks in the scWCGNA object
sdata_sub.scWGCNA = scWGCNA.networks(scWGCNA.data = sdata_sub.scWGCNA)


# Plot the module "blue" as a network
scW.p.network(sdata_sub.scWGCNA, module=10, save = 'module10ENlin.pdf')

saveRDS(sdata_sub.scWGCNA, "AGGR01.ControlENlin.70DIV.WGCNA.rds")
sdata_Enlin.WGCNA= readRDS ("ENlin/AGGR01.ControlENlin.70DIV.WGCNA.rds")



#load case data

# sdata= readRDS(file=paste(prefix, timepoint,'.seurat.final.rds', sep='.'))
# sdata_case_sub<- subset(x = sdata, subset= genotype == "Case")
# DimPlot(sdata_case_sub, reduction = "umap")
# saveRDS(sdata_case_sub, file=paste(prefix, timepoint, '.seurat.final.case.rds', sep='.')) 
sdata= readRDS(file=paste(prefix, timepoint, '.seurat.final.case.rds', sep='.')) 
sdata_case_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
DimPlot(sdata_sub, reduction = "umap")

#calculate case pseudocells
sdata_case_sub.pcells = calculate.pseudocells(s.cells = sdata_case_sub, # Single cells in Seurat object
                                         seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                         nn = 10, # Number of neighbors to aggregate
                                         reduction = "umap", # Reduction to use
                                         dims = 1:2) # The dimensions to use

#saveRDS(sdata_case_sub.pcells, "sdata_case_sub.pcells.rds")

# We then run the comparative analysis
scWGCNA.comparative = scWGNA.compare(scWGCNA.data = sdata_sub.scWGCNA,
                                   test.list = list(sdata_case_sub.pcells),
                                   test.names = c("Case"),
                                   #ortho = my.ortho, # not needed unless reference and tests have different gene names
                                   #ortho.sp = c(2)
)


# We can see how many genes are present in each module, at each category. In the misc slot of the scWGCNA comparative list object
scWGCNA.comparative$misc$modulefrac


# And the identity of the lost genes is found under the same slot
scWGCNA.comparative$misc$geneslost

# We can also plot these fractions as barplots, for each module we used for comparisons
scW.p.modulefrac(scWGCNA.comparative)


# Here we can plot the overall preservation and median rank.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("preservation", "median.rank"))

# We can also plot the preservation of density and connectivity.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("density", "connectivity"))

saveRDS(scWGCNA.comparative, "ENlin.scWGCNA.comparitive.rds")


write.csv(sdata_sub.scWGCNA$module.genes[[2]], "control.ENlinmodule.genes2.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[3]], "control.ENlinmodule.genes3.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[4]], "control.ENlinmodule.genes4.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[7]], "control.ENlinmodule.genes7.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[9]], "control.ENlinmodule.genes9.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[10]], "control.ENlinmodule.genes10.csv")




##ONly EN

setwd ("E:/Sneha/RNAseq/ScSeq/wgcna")
prefix = "AGGR01"
timepoint = "70d"
sdata = readRDS("AGGR01.70d..seurat.final.control.rds")


sdata_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("nEN-early", "nEN-late", "EN"))
DimPlot(sdata_sub, reduction = "umap")
FindVariableFeatures(sdata_sub)

sdata_sub

#calculate pseudocells

sdata_sub.pcells = calculate.pseudocells(s.cells = sdata_sub, # Single cells in Seurat object
                                         seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                         nn = 10, # Number of neighbors to aggregate
                                         reduction = "umap", # Reduction to use
                                         dims = 1:2) # The dimensions to use

#Run scWGCNA
sdata_sub.scWGCNA = run.scWGCNA(p.cells = sdata_sub.pcells, # Pseudocells (recommended), or Seurat single cells
                                s.cells = sdata_sub, # single cells in Seurat format
                                is.pseudocell = T, # We are using single cells twice this time
                                features = VariableFeatures(sdata_sub, nfeatures=2000)) #rownames(sdata_sub)) # 


# Plot the gene / modules dendrogram
scW.p.dendro(scWGCNA.data = sdata_sub.scWGCNA)


#Look at the membership tables
names(sdata_sub.scWGCNA$modules)

#Let's look at the first module, "blue"
head(sdata_sub.scWGCNA$modules$'1_blue')


head(sdata_sub.scWGCNA$modules$`2_brown`)

head(sdata_sub.scWGCNA$modules$`3_turquoise`)

# Here we can see what is the expression of each co-expression module, per cell. This is in one of the list items
head(sdata_sub.scWGCNA[["sc.MEList"]]$averageExpr)

# If we want to see the average module expression per pseudocell instead of single cells, we find it here
head(sdata_sub.scWGCNA[["MEList"]]$averageExpr)


# Plot the expression of all modules at once
scW.p.expression(s.cells = sdata_sub, # Single cells in Seurat format
                 scWGCNA.data = sdata_sub.scWGCNA, # scWGCNA list dataset
                 modules = "all", # Which modules to plot?
                 reduction = "umap", # Which reduction to plot?
                 ncol=3) # How many columns to use, in case we're plotting several?

#Plot only the expression of the first module, "black"
scW.p.expression(s.cells = sdata_sub,
                 scWGCNA.data =sdata_sub.scWGCNA,
                 modules = 2,
                 reduction = "umap")

# First generate the networks in the scWCGNA object
sdata_sub.scWGCNA = scWGCNA.networks(scWGCNA.data = sdata_sub.scWGCNA)


# Plot the module "blue" as a network
scW.p.network(sdata_sub.scWGCNA, module=7)

saveRDS(sdata_sub.scWGCNA, "AGGR01.ControlEN.70DIV.WGCNA.rds")

#load case data

# sdata= readRDS(file=paste(prefix, timepoint,'.seurat.final.rds', sep='.'))
# sdata_case_sub<- subset(x = sdata, subset= genotype == "Case")
# DimPlot(sdata_case_sub, reduction = "umap")
# saveRDS(sdata_case_sub, file=paste(prefix, timepoint, '.seurat.final.case.rds', sep='.')) 
sdata= readRDS(file=paste(prefix, timepoint, '.seurat.final.case.rds', sep='.')) 
sdata_case_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("nEN-early", "nEN-late", "EN"))
DimPlot(sdata_sub, reduction = "umap")

#calculate case pseudocells
sdata_case_sub.pcells = calculate.pseudocells(s.cells = sdata_case_sub, # Single cells in Seurat object
                                              seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                              nn = 10, # Number of neighbors to aggregate
                                              reduction = "umap", # Reduction to use
                                              dims = 1:2) # The dimensions to use

#saveRDS(sdata_case_sub.pcells, "sdata_case_sub.pcells.rds")

# We then run the comparative analysis
scWGCNA.comparative = scWGNA.compare(scWGCNA.data = sdata_sub.scWGCNA,
                                     test.list = list(sdata_case_sub.pcells),
                                     test.names = c("Case"),
                                     #ortho = my.ortho, # not needed unless reference and tests have different gene names
                                     #ortho.sp = c(2)
)


# We can see how many genes are present in each module, at each category. In the misc slot of the scWGCNA comparative list object
scWGCNA.comparative$misc$modulefrac


# And the identity of the lost genes is found under the same slot
scWGCNA.comparative$misc$geneslost

# We can also plot these fractions as barplots, for each module we used for comparisons
scW.p.modulefrac(scWGCNA.comparative)


# Here we can plot the overall preservation and median rank.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("preservation", "median.rank"))

# We can also plot the preservation of density and connectivity.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("density", "connectivity"))

saveRDS(scWGCNA.comparative, "EN70D.scWGCNA.comparitive.rds")


write.csv(sdata_sub.scWGCNA$module.genes[[1]], "control.EN70Dmodule.genes1.csv")
write.csv(sdata_sub.scWGCNA$module.genes[[7]], "control.EN70Dmodule.genes7.csv")




###150D
#another package
#https://github.com/CFeregrino/scWGCNA
#devtools::install_github("cferegrino/scWGCNA", ref="main")
setwd ("E:/Sneha/RNAseq/ScSeq/wgcna")
prefix = "AGGR01"
timepoint = "150d"
sdata = readRDS("AGGR01.seurat.final.rds")

library(Seurat)
# sdata_sub = # S3 method for Seurat
#   NormalizeData(
#     sdata_sub,
#     assay = "RNA",
#     normalization.method = "LogNormalize",
#     scale.factor = 10000,
#     margin = 1,
#     verbose = TRUE,
#  )

#saveRDS(sdata_sub,'E:/Sneha/RNAseq/ScSeq/Raw/wgcna/AGGR01.70d.seurat.norm.final.control.rds')

#sdata_sub = readRDS('E:/Sneha/RNAseq/ScSeq/Raw/wgcna/AGGR01.70d.seurat.norm.final.control.rds')

library ("scWGCNA")


sdata= subset(x = sdata,subset= timepoint == "150d") 
DimPlot(sdata, reduction = "umap")
FindVariableFeatures(sdata)

sdata_subEN= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
sdata_subIN= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("MGE-RG", "RG-late", "MGE-RG_IPC-div", "nIN", "IN-STR", "IN-CTX"))


saveRDS(sdata,file=paste(prefix, timepoint,'.seurat.final.rds', sep='.'))


###Enlineage

sdata_subEN= subset(x = sdata_subEN, subset = genotype== "Control")
sdata_subEN
DimPlot(sdata_subEN, reduction = "umap")
FindVariableFeatures(sdata_subEN)

#calculate pseudocells

sdata_subEN.pcells = calculate.pseudocells(s.cells = sdata_subEN, # Single cells in Seurat object
                                         seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                         nn = 10, # Number of neighbors to aggregate
                                         reduction = "umap", # Reduction to use
                                         dims = 1:2) # The dimensions to use

#Run scWGCNA
sdata_subEN.scWGCNA = run.scWGCNA(p.cells = sdata_subEN.pcells, # Pseudocells (recommended), or Seurat single cells
                                s.cells = sdata_subEN, # single cells in Seurat format
                                is.pseudocell = T, # We are using single cells twice this time
                                features = VariableFeatures(sdata_subEN, nfeatures=2000)) #rownames(sdata_sub)) # 


# Plot the gene / modules dendrogram
scW.p.dendro(scWGCNA.data = sdata_subEN.scWGCNA)


#Look at the membership tables
names(sdata_subEN.scWGCNA$modules)

# #Let's look at the first module, "blue"
# head(sdata_sub.scWGCNA$modules$'1_blue')
# 
# 
# head(sdata_sub.scWGCNA$modules$`2_brown`)
# 
# head(sdata_sub.scWGCNA$modules$`3_turquoise`)

# Here we can see what is the expression of each co-expression module, per cell. This is in one of the list items
head(sdata_subEN.scWGCNA[["sc.MEList"]]$averageExpr)

# If we want to see the average module expression per pseudocell instead of single cells, we find it here
head(sdata_subEN.scWGCNA[["MEList"]]$averageExpr)


# Plot the expression of all modules at once
scW.p.expression(s.cells = sdata_subEN, # Single cells in Seurat format
                 scWGCNA.data = sdata_subEN.scWGCNA, # scWGCNA list dataset
                 modules = "all", # Which modules to plot?
                 reduction = "umap", # Which reduction to plot?
                 ncol=3) # How many columns to use, in case we're plotting several?

#Plot only the expression of the first module, "blue"
scW.p.expression(s.cells = sdata_sub,
                 scWGCNA.data =sdata_sub.scWGCNA,
                 modules = 10,
                 reduction = "umap")

# First generate the networks in the scWCGNA object
sdata_subEN.scWGCNA = scWGCNA.networks(scWGCNA.data = sdata_subEN.scWGCNA)


# Plot the module "blue" as a network
scW.p.network(sdata_subEN.scWGCNA, module=4, save = 'module3_150DENlin.pdf')

saveRDS(sdata_subEN.scWGCNA, "ENlin150D/AGGR01.ControlENlin.150DIV.WGCNA.rds")
sdata_subEN.scWGCNA= readRDS("ENlin150D/AGGR01.ControlENlin.150DIV.WGCNA.rds")

#load case data


sdata_case_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))

sdata_case_subEN= subset(x = sdata_case_sub, subset = genotype== "Case")
DimPlot(sdata_case_subEN, reduction = "umap")
sdata_case_subEN

DimPlot(sdata_case_subEN, reduction = "umap")
FindVariableFeatures(sdata_case_subEN)

#calculate case pseudocells
sdata_case_subEN.pcells = calculate.pseudocells(s.cells = sdata_case_subEN, # Single cells in Seurat object
                                              seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                              nn = 10, # Number of neighbors to aggregate
                                              reduction = "umap", # Reduction to use
                                              dims = 1:2) # The dimensions to use

#saveRDS(sdata_case_sub.pcells, "sdata_case_sub.pcells.rds")

# We then run the comparative analysis
scWGCNA.comparative = scWGNA.compare(scWGCNA.data = sdata_subEN.scWGCNA,
                                     test.list = list(sdata_case_subEN.pcells),
                                     test.names = c("Case"),
                                     #ortho = my.ortho, # not needed unless reference and tests have different gene names
                                     #ortho.sp = c(2)
)


# We can see how many genes are present in each module, at each category. In the misc slot of the scWGCNA comparative list object
scWGCNA.comparative$misc$modulefrac


# And the identity of the lost genes is found under the same slot
scWGCNA.comparative$misc$geneslost

# We can also plot these fractions as barplots, for each module we used for comparisons
scW.p.modulefrac(scWGCNA.comparative)


# Here we can plot the overall preservation and median rank.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("preservation", "median.rank"))

# We can also plot the preservation of density and connectivity.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("density", "connectivity"))

saveRDS(scWGCNA.comparative, "ENlin150D/ENlin.scWGCNA.comparitive.rds")


write.csv(sdata_subEN.scWGCNA$module.genes[[2]], "ENlin150D/control.ENlinmodule.genes2.csv")
write.csv(sdata_subEN.scWGCNA$module.genes[[3]], "ENlin150D/control.ENlinmodule.genes3.csv")
write.csv(sdata_subEN.scWGCNA$module.genes[[5]], "ENlin150D/control.ENlinmodule.genes5.csv")
write.csv(sdata_subEN.scWGCNA$module.genes[[17]], "ENlin150D/control.ENlinmodule.genes17.csv")
write.csv(sdata_subEN.scWGCNA$module.genes[[15]], "ENlin150D/control.ENlinmodule.genes15.csv")
write.csv(sdata_subEN.scWGCNA$module.genes[[10]], "ENlin150D/control.ENlinmodule.genes10.csv")

saveRDS (sdata_case_subEN, file=paste(prefix, timepoint,'ENlincontrol.seurat.final.rds', sep='.'))


###Interneuron lineage

sdata_subIN= subset(x = sdata_subIN, subset = genotype== "Control")
sdata_subIN
DimPlot(sdata_subIN, reduction = "umap")
FindVariableFeatures(sdata_subIN)

#calculate pseudocells

sdata_subIN.pcells = calculate.pseudocells(s.cells = sdata_subIN, # Single cells in Seurat object
                                           seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                           nn = 10, # Number of neighbors to aggregate
                                           reduction = "umap", # Reduction to use
                                           dims = 1:2) # The dimensions to use

#Run scWGCNA
sdata_subIN.scWGCNA = run.scWGCNA(p.cells = sdata_subIN.pcells, # Pseudocells (recommended), or Seurat single cells
                                  s.cells = sdata_subIN, # single cells in Seurat format
                                  is.pseudocell = T, # We are using single cells twice this time
                                  features = VariableFeatures(sdata_subIN))       # nfeatures=2000 #rownames(sdata_sub)) # 


# Plot the gene / modules dendrogram
scW.p.dendro(scWGCNA.data = sdata_subIN.scWGCNA)


#Look at the membership tables
names(sdata_subIN.scWGCNA$modules)

# #Let's look at the first module, "blue"
# head(sdata_sub.scWGCNA$modules$'1_blue')
# 
# 
# head(sdata_sub.scWGCNA$modules$`2_brown`)
# 
# head(sdata_sub.scWGCNA$modules$`3_turquoise`)

# Here we can see what is the expression of each co-expression module, per cell. This is in one of the list items
head(sdata_subIN.scWGCNA[["sc.MEList"]]$averageExpr)

# If we want to see the average module expression per pseudocell instead of single cells, we find it here
head(sdata_subIN.scWGCNA[["MEList"]]$averageExpr)


# Plot the expression of all modules at once
scW.p.expression(s.cells = sdata_subIN, # Single cells in Seurat format
                 scWGCNA.data = sdata_subIN.scWGCNA, # scWGCNA list dataset
                 modules = "all", # Which modules to plot?
                 reduction = "umap", # Which reduction to plot?
                 ncol=3) # How many columns to use, in case we're plotting several?
# 
# #Plot only the expression of the first module, "blue"
# scW.p.expression(s.cells = sdata_sub,
#                  scWGCNA.data =sdata_sub.scWGCNA,
#                  modules = 10,
#                  reduction = "umap")

# First generate the networks in the scWCGNA object
sdata_subIN.scWGCNA = scWGCNA.networks(scWGCNA.data = sdata_subIN.scWGCNA)


# Plot the module "blue" as a network
scW.p.network(sdata_subIN.scWGCNA, module=17, save = 'module3_150DENlin.pdf')

saveRDS(sdata_subIN.scWGCNA, "INlin150D/AGGR01.ControlINlin.150DIV.WGCNA.rds")

#load case data


sdata_case_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("MGE-RG", "RG-late", "MGE-RG_IPC-div", "nIN", "IN-STR", "IN-CTX"))

sdata_case_subIN= subset(x = sdata_case_sub, subset = genotype== "Case")
DimPlot(sdata_case_subIN, reduction = "umap")
sdata_case_subIN

FindVariableFeatures(sdata_case_subIN)

#calculate case pseudocells
sdata_case_subIN.pcells = calculate.pseudocells(s.cells = sdata_case_subIN, # Single cells in Seurat object
                                                seeds=0.2, # Fraction of cells to use as seeds to aggregate pseudocells
                                                nn = 10, # Number of neighbors to aggregate
                                                reduction = "umap", # Reduction to use
                                                dims = 1:2) # The dimensions to use

#saveRDS(sdata_case_sub.pcells, "sdata_case_sub.pcells.rds")

# We then run the comparative analysis
scWGCNA.comparative = scWGNA.compare(scWGCNA.data = sdata_subIN.scWGCNA,
                                     test.list = list(sdata_case_subIN.pcells),
                                     test.names = c("Case"),
                                     #ortho = my.ortho, # not needed unless reference and tests have different gene names
                                     #ortho.sp = c(2)
)


# We can see how many genes are present in each module, at each category. In the misc slot of the scWGCNA comparative list object
scWGCNA.comparative$misc$modulefrac


# And the identity of the lost genes is found under the same slot
scWGCNA.comparative$misc$geneslost

# We can also plot these fractions as barplots, for each module we used for comparisons
scW.p.modulefrac(scWGCNA.comparative)


# Here we can plot the overall preservation and median rank.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("preservation", "median.rank"))

# We can also plot the preservation of density and connectivity.
scW.p.preservation(scWGCNA.comp.data = scWGCNA.comparative,
                   to.plot=c("density", "connectivity"))

saveRDS(scWGCNA.comparative, "INlin150D/INlin.scWGCNA.comparitive.rds")


write.csv(sdata_subIN.scWGCNA$module.genes[[2]],"INlin150D/control.module.genes2.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[3]],"INlin150D/control.module.genes3.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[5]],"INlin150D/control.module.genes5.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[10]],"INlin150D/control.module.genes10.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[11]],"INlin150D/control.module.genes11.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[13]],"INlin150D/control.module.genes13.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[16]],"INlin150D/control.module.genes16.csv")
write.csv(sdata_subIN.scWGCNA$module.genes[[17]],"INlin150D/control.module.genes17.csv")

saveRDS (sdata_case_subIN, file=paste(prefix, timepoint,'INlincontrol.seurat.final.rds', sep='.'))
