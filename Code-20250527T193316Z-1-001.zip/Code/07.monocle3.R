## The following can be run on the provided container with:
# docker run -v $(pwd):/data/ -it -p 8080:8080 --rm fbrundu/monocle3:0321

## Then, inside the container run the following commands on an R session
# Clear workspace
rm(list=ls())

# Load libraries
library(monocle3)
library(feather)
library(RColorBrewer)
library(ggplot2)
library(dplyr)
library(tibble)
library(purrr)
library(tidyr)

# Load data
data <- as.data.frame(
    read_feather(paste('AGGR01_mapped', 'counts.fth', sep='.'))
)
rownames(data) <- data[,1]
data <- data[,-1]

# Load cell annotations
cell.data <- read.table(
    sep=',',
    header=TRUE,
    check.names=FALSE,
    'AGGR01_mapped.obs.csv',
    row.names=1,
)

# Load gene annotations
gene.data <- read.table(
    sep=',',
    header=TRUE,
    check.names=FALSE,
    'AGGR01_mapped.var.csv',
    row.names=1,
)

# Keep only cells with annotations
cells <- intersect(rownames(data), rownames(cell.data))
data <- data[cells,]
cell.data <- cell.data[cells,]
cell.data <- droplevels(cell.data)

# Keep only genes with annotations
genes <- intersect(colnames(data), rownames(gene.data))
data <- data[,genes]
gene.data <- gene.data[genes,]

# Set gene symbol as gene short name for Monocle
gene.data['gene_short_name'] = rownames(gene.data)

# Create dataset for Monocle
cds <- new_cell_data_set(
    t(as(as.matrix(data), 'sparseMatrix')),
    cell_metadata=cell.data,
    gene_metadata=gene.data
)

# Remove temporary data
rm(data)

# Save data snapshot
saveRDS(cds, 'AGGR01_mapped.rds')
cds <- readRDS('AGGR01_mapped.rds')

# Load Central Nervous System GO term genes
cns.dev <- c(levels(
    read.csv('go_cns_dev.0321.csv', check.names=FALSE)$GO_CENTRAL_NERVOUS_SYSTEM_DEVELOPMENT
))
cns.dev <- intersect(rownames(cds), cns.dev)

# dev.allen <- c(levels(
    # read.csv('dev_allen.csv', check.names=FALSE)[['gene-symbol']]
# ))
# dev.allen <- intersect(rownames(cds), dev.allen)

# Define color coding for cell type annotations
nowakowski.fine.noglyc.unmapped.colors <- c('#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc', '#f07cab', '#d30b94')
nowakowski.fine.noglyc.unmapped.aggr.colors <- c('#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc')


# Generate Monocle representation for number of principal components
# from 3 to 20
for(n_pcs in 3:20) {
    cds <- preprocess_cds(
        cds,
        num_dim=n_pcs,
        use_genes=cns.dev,
        alignment_group='batch',
        residual_model_formula_str='~ n_genes + pair + percent_mito + percent_ribo_p',
    )
    cds <- reduce_dimension(
        cds,
        max_components=2,
        cores=1,
        preprocess_method='PCA',
    )

    # Plot Monocle representation with cell type annotation coding
    pdf(paste('cns_dev/eda_pca/monocle.notree.fine', n_pcs, 'pdf', sep='.'))
    print(plot_cells(
        cds,
        color_cells_by='nowakowski.fine.noglyc_unmapped',
        label_cell_groups=FALSE,
    ) + scale_color_manual(values=nowakowski.fine.noglyc.unmapped.colors))
    dev.off()
    pdf(paste('dev_allen/eda_pca/monocle.notree.fine.aggr', n_pcs, 'pdf', sep='.'))
    print(plot_cells(
        cds,
        color_cells_by='nowakowski.fine.noglyc_unmapped.aggr',
        label_cell_groups=FALSE,
    ) + scale_color_manual(values=nowakowski.fine.noglyc.unmapped.aggr.colors))
    dev.off()
}

# Choose cell type annotation and color coding
key <- 'nowakowski.fine.noglyc_unmapped'
colors <- nowakowski.fine.noglyc.unmapped.colors

# Choose number of principal components for selected representation
# and finalize Monocle representation
n_pcs <- 6
cds <- preprocess_cds(
    cds,
    num_dim=n_pcs,
    use_genes=cns.dev,
    alignment_group='batch',
    residual_model_formula_str='~ n_genes + pair + percent_mito + percent_ribo_p',
)
cds <- reduce_dimension(
    cds,
    max_components=2,
    cores=1,
    preprocess_method='PCA',
)
pdf(paste('cns_dev/full/monocle.notree.fine.aggr', n_pcs, 'pdf', sep='.'))
plot_cells(
    cds,
    color_cells_by=key,
    label_cell_groups=FALSE,
) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
dev.off()

# Cluster cells and learn pseudotime graph
cds <- cluster_cells(cds)
cds <- learn_graph(
    cds,
    use_partition=FALSE,
    learn_graph_control=list(
        minimal_branch_len=20,
        rann.k=NULL
    ),
)

# Plot Monocle tree representation with cell type color coding
pdf(paste('cns_dev/full/monocle.tree', n_pcs, 'pdf', sep='.'))
plot_cells(
    cds,
    color_cells_by=key,
    label_cell_groups=FALSE,
    label_branch_points=FALSE,
    label_leaves=FALSE,
    trajectory_graph_segment_size=0.5,
    labels_per_group=3,
) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
dev.off()

# Define function for finding the starting node of pseudotime
# - key parameter: cell type annotation label, e.g. 'nowakowski...'
# - label: cell type label, e.g. 'RG'
get_earliest_principal_node <- function(cds, key, label){
    cell_ids <- colnames(cds)[which(colData(cds)[, key] == label)]
    cwg <- cds@principal_graph_aux[['UMAP']]$pr_graph_cell_proj_tree
    cwg <- as.data.frame(igraph::get.edgelist(cwg))
    cwg <- cwg[-grep('Y_', cwg$V2),]
    allowed <- levels(droplevels(unique(cwg[grep('Y_', cwg$V1), 'V1'])))
    allowed <- as.numeric(substring(allowed, 3))
    closest_vertex <-
    cds@principal_graph_aux[["UMAP"]]$pr_graph_cell_proj_closest_vertex
    closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
    closest_vertex <- subset(closest_vertex, closest_vertex %in% allowed)
    closest_vertex <- subset(closest_vertex, rownames(closest_vertex) %in% cell_ids)
    root_pr_nodes <-
    igraph::V(principal_graph(cds)[["UMAP"]])$name[as.numeric(names(which.max(table(closest_vertex))))]
    root_pr_nodes
}

# Compute pseudotime starting from dividing radial glia in `key` labels
cds <- order_cells(
    cds, root_pr_nodes=get_earliest_principal_node(cds, key, 'RG-div')
)

# Plot pseudotime tree and super-imposed cell type annotation
pdf(paste('cns_dev/full/monocle', n_pcs, 'pdf', sep='.'))
plot_cells(
    cds,
    color_cells_by=key,
    label_cell_groups=FALSE,
    label_branch_points=FALSE,
    label_leaves=FALSE,
    trajectory_graph_segment_size=0.5,
    labels_per_group=3,
) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
dev.off()

# Plot pseudotime tree and super-imposed timepoint label
pdf(paste('cns_dev/full/monocle.timepoint', n_pcs, 'pdf', sep='.'))
plot_cells(
    cds,
    color_cells_by='timepoint',
    label_cell_groups=FALSE,
    label_branch_points=FALSE,
    label_leaves=FALSE,
    trajectory_graph_segment_size=0.5,
    labels_per_group=3,
) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
dev.off()

# Plot pseudotime tree and super-imposed genotype label
pdf(paste('cns_dev/full/monocle.genotype', n_pcs, 'pdf', sep='.'))
plot_cells(
    cds,
    color_cells_by='genotype',
    label_cell_groups=FALSE,
    label_branch_points=FALSE,
    label_leaves=FALSE,
    trajectory_graph_segment_size=0.5,
    labels_per_group=3,
) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)) 
dev.off()

# Run similar analysis on each genotype separately
# NOTE: the most prevalent genotype is randomly subsampled to the number
# of cells of the least prevalent
for (genotype in c('Case', 'Control')) {
    # Get number of cells of least prevalent genotype
    counts <- table(cds$genotype)
    n_cells <- min(counts)
    frac <- n_cells / counts[genotype]
    set.seed(42)
    cds.cond <- cds[,colnames(cds)[cds$genotype == genotype]]

    # Stratified random sampling (on Nowakowski) of most prevalent genotype
    cells <- rownames(as.data.frame(colData(cds.cond)) %>% rownames_to_column('Cell') %>% group_by("nowakowski.fine.noglyc_unmapped") %>% sample_frac(frac, replace=FALSE) %>% column_to_rownames('Cell'))

    # Print stats on the subsampled cells
    # print(genotype)
    # print(frac)
    # print(
        # table(colData(cds[,cells])$key)
        # / table(colData(cds.cond)$key)
    # )

    # Subset dataset using subsampled cells of current genotype
    cds.cond <- cds.cond[,cells]

    # Plot cells of current genotype super-imposed on tree computed
    # on full dataset
    pdf(paste('cns_dev/full/monocle', genotype, n_pcs, 'pdf', sep='.'))
    print(plot_cells(
        cds.cond,
        color_cells_by=key,
        label_cell_groups=FALSE,
        label_branch_points=FALSE,
        label_leaves=FALSE,
        trajectory_graph_segment_size=0.5,
        labels_per_group=3,
    ) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))) 
    dev.off()

    # Plot cells of current genotype colored by pseudotime
    pdf(paste('cns_dev/full/monocle', genotype, 'pseudotime', n_pcs, 'pdf', sep='.'))
    print(plot_cells(
        cds.cond,
        color_cells_by='pseudotime',
        label_cell_groups=TRUE,
        label_branch_points=FALSE,
        trajectory_graph_segment_size=0.5,
    ))
    dev.off()

    # Plot selected genes on pseudotime tree
    genes <- c('DCX', 'SLC17A7', 'SLC17A6', 'GAD1', 'GAD2', 'EOMES')
    pdf(paste('cns_dev/full/monocle', genotype, 'pseudotime.genes', n_pcs, 'pdf', sep='.'))
    print(plot_genes_in_pseudotime(
        cds.cond[genes,], color_cells_by=key, min_expr=.5
    ) + scale_color_manual(values=colors))
    dev.off()
    
    # Cluster cells and learn a new pseudotime tree (only on genotype
    # cells)
    cds.cond <- cluster_cells(cds.cond)
    cds.cond <- learn_graph(
        cds.cond,
        use_partition=FALSE,
        learn_graph_control=list(
            minimal_branch_len=20,
            rann.k=NULL
        ),
    )
    cds.cond <- order_cells(
        cds.cond, root_pr_nodes=get_earliest_principal_node(
            cds.cond, key, 'RG-div'
        )
    )

    # Plot cells of current genotype super-imposed on the tree learned
    # only on such cells
    pdf(paste('cns_dev/full/monocle', genotype, 'separate', n_pcs, 'pdf', sep='.'))
    print(plot_cells(
        cds.cond,
        color_cells_by=key,
        label_cell_groups=FALSE,
        label_branch_points=FALSE,
        label_leaves=FALSE,
        trajectory_graph_segment_size=0.5,
        labels_per_group=3,
    ) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)))
    dev.off()
}

# Save data snapshot
saveRDS(cds, 'cns_dev/full/monocle.rds')

## Within the container:
# docker run -v $(pwd):/data/ -it -p 8080:8080 --rm fbrundu/monocle3:0321
## Run the following commented commands on the terminal to install
## support for using the graphical UI while running Monocle on the
## container
# apt install xvfb xauth xfonts-base
# apt install xfonts-100dpi
# apt install xfonts-75dpi
## Then restart the container and run 
# Xvfb :0 -ac -screen 0 1960x2000x24 &
## And then, the following on the R session

# Useful to make R use the graphical user interface
Sys.setenv("DISPLAY"=":0.0")

# Load libraries
library(monocle3)
library(feather)
library(RColorBrewer)
library(ggplot2)
library(dplyr)
library(tibble)
library(purrr)
library(tidyr)

# Options to support the graphical user interface (at 127.0.0.1:8080, or
# similar addresses)
options(shiny.host='0.0.0.0')
options(shiny.port=8080)

# Define function for finding the starting node of pseudotime
# - key parameter: cell type annotation label, e.g. 'nowakowski...'
# - label: cell type label, e.g. 'RG'
get_earliest_principal_node <- function(cds, key, label){
    cell_ids <- colnames(cds)[which(colData(cds)[, key] == label)]
    cwg <- cds@principal_graph_aux[['UMAP']]$pr_graph_cell_proj_tree
    cwg <- as.data.frame(igraph::get.edgelist(cwg))
    cwg <- cwg[-grep('Y_', cwg$V2),]
    allowed <- levels(droplevels(unique(cwg[grep('Y_', cwg$V1), 'V1'])))
    allowed <- as.numeric(substring(allowed, 3))
    closest_vertex <-
    cds@principal_graph_aux[["UMAP"]]$pr_graph_cell_proj_closest_vertex
    closest_vertex <- as.matrix(closest_vertex[colnames(cds), ])
    closest_vertex <- subset(closest_vertex, closest_vertex %in% allowed)
    closest_vertex <- subset(closest_vertex, rownames(closest_vertex) %in% cell_ids)
    root_pr_nodes <-
    igraph::V(principal_graph(cds)[["UMAP"]])$name[as.numeric(names(which.max(table(closest_vertex))))]
    root_pr_nodes
}

# Define cell type label name
key <- 'nowakowski.fine.noglyc_unmapped'
# Define number of principal components of selected representation
n_pcs <- 6
# Define colors mapping for cell type annotations
nowakowski.fine.noglyc.unmapped.colors <- c('#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc', '#f07cab', '#d30b94')
nowakowski.fine.noglyc.unmapped.aggr.colors <- c('#66c2a5', '#fc8d62', '#8da0cb', '#e78ac3', '#a6d854', '#ffd92f', '#e5c494', '#b3b3b3', '#235b54', '#3998f5', '#991919', '#c56133', '#2f2aa0', '#b732cc')
# Select main color mapping to use
colors <- nowakowski.fine.noglyc.unmapped.colors

# Read full data and graphically select two different lineages
cds <- readRDS('cns_dev/full/monocle.rds')
cds.lin1 <- choose_graph_segments(cds)
cds.lin2 <- choose_graph_segments(cds)
cds.lin3 <- choose_graph_segments(cds)
cds.lin4 <- choose_graph_segments(cds)

# Save snapshots for the two lineages
cds.lin1 <- cds[, colnames(cds.lin1)]
saveRDS(cds.lin1, 'cns_dev/by_lineage/monocle.lin.1.rds')
cds.lin2 <- cds[, colnames(cds.lin2)]
saveRDS(cds.lin2, 'cns_dev/by_lineage/monocle.lin.2.rds')
cds.lin3 <- cds[, colnames(cds.lin3)]
saveRDS(cds.lin3, 'cns_dev/by_lineage/monocle.lin.3.rds')
cds.lin4 <- cds[, colnames(cds.lin4)]
saveRDS(cds.lin4, 'cns_dev/by_lineage/monocle.lin.4.rds')

# Read snapshots from disk
cds.lin1 <- readRDS('cns_dev/by_lineage/monocle.lin.1.rds')
cds.lin2 <- readRDS('cns_dev/by_lineage/monocle.lin.2.rds')
cds.lin3 <- readRDS('cns_dev/by_lineage/monocle.lin.3.rds')
cds.lin4 <- readRDS('cns_dev/by_lineage/monocle.lin.4.rds')

# Identify which cells are shared or not between the two lineages
cds$lineage <- 'other'
cds$lineage[colnames(cds) %in% colnames(cds.lin1)] <- 'lineage1'
cds$lineage[colnames(cds) %in% colnames(cds.lin2)] <- 'lineage2'
cds$lineage[colnames(cds) %in% colnames(cds.lin3)] <- 'lineage3'
cds$lineage[colnames(cds) %in% colnames(cds.lin4)] <- 'lineage4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin2))
] <- 'shared.1.2'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin3))
] <- 'shared.1.3'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.1.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin3))
] <- 'shared.2.3'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.2.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin3))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.3.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin3))
] <- 'shared.1.2.3'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.1.2.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin3))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.1.3.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin3))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared.2.3.4'
cds$lineage[
    (colnames(cds) %in% colnames(cds.lin1))
    & (colnames(cds) %in% colnames(cds.lin2))
    & (colnames(cds) %in% colnames(cds.lin3))
    & (colnames(cds) %in% colnames(cds.lin4))
] <- 'shared'

# And plot lineage annotation
pdf(paste('cns_dev/by_lineage/monocle.lineage', n_pcs, 'pdf', sep='.'))
print(plot_cells(
    cds,
    color_cells_by='lineage',
    label_cell_groups=FALSE,
    label_branch_points=FALSE,
    label_leaves=FALSE,
    trajectory_graph_segment_size=0.5,
    labels_per_group=3,
) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)))
dev.off()

# Learn pseudotime tree on each lineage
i <- 0
for (cds.curr in list(cds.lin1, cds.lin2, cds.lin3, cds.lin4)) {
    i <- i + 1
    cds.curr <- cluster_cells(cds.curr)
    cds.curr <- learn_graph(
        cds.curr,
        use_partition=FALSE,
        learn_graph_control=list(
            minimal_branch_len=20,
            rann.k=NULL
        ),
    )
    cds.curr <- order_cells(
        cds.curr,
        root_pr_nodes=get_earliest_principal_node(cds.curr, key, 'RG-div')
    )
    # And plot different cell type annotations (cell type, pseudotime)
    pdf(paste(
        'cns_dev/by_lineage/monocle.lineage', i,'separate', n_pcs, 'pdf',
        sep='.'
    ))
    print(plot_cells(
        cds.curr,
        color_cells_by=key,
        label_cell_groups=FALSE,
        label_branch_points=FALSE,
        label_leaves=FALSE,
        trajectory_graph_segment_size=0.5,
        labels_per_group=3,
    ) + scale_color_manual(values=colors) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)))
    dev.off()
    pdf(paste(
        'cns_dev/by_lineage/monocle.lineage', i, 'pseudotime', n_pcs, 'pdf',
        sep='.'
    ))
    print(plot_cells(
        cds.curr,
        color_cells_by='pseudotime',
        label_cell_groups=TRUE,
        label_branch_points=FALSE,
        trajectory_graph_segment_size=0.5,
    ))
    dev.off()
    saveRDS(
        cds.curr,
        paste('cns_dev/by_lineage/monocle.lin', i, '.rds', sep='.')
    )
}

# Save a snapshot of the full dataset
saveRDS(cds, 'cns_dev/full/monocle.rds')

# Plot selected genes on the two lineages
# genes <- c('SOX2', 'GFAP', 'EOMES', 'DCX', 'NEUROD1', 'NEUROG1', 'NEUROG2', 'SLC17A7', 'SLC17A6', 'GAD1', 'GAD2')
# pdf(paste('cns_dev/by_lineage/monocle.lineage.1.pseudotime.genes', n_pcs, 'pdf', sep='.'))
# print(plot_genes_in_pseudotime(
#     cds.lin1[genes,], color_cells_by=key, min_expr=.5
# ) + scale_color_manual(values=colors))
# dev.off()
# pdf(paste('cns_dev/by_lineage/monocle.lineage.2.pseudotime.genes', n_pcs, 'pdf', sep='.'))
# print(plot_genes_in_pseudotime(
#     cds.lin2[genes,], color_cells_by=key, min_expr=.5
# ) + scale_color_manual(values=colors))
# dev.off()

# # NOTE additional plots

# pdf(paste('cns_dev/by_lineage/monocle.lineage.1.timepoint', n_pcs, 'pdf', sep='.'))
# plot_cells(
#     cds.lin1,
#     color_cells_by='timepoint',
#     label_cell_groups=FALSE,
#     label_branch_points=FALSE,
#     label_leaves=FALSE,
#     trajectory_graph_segment_size=0.5,
#     labels_per_group=3,
# ) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
# dev.off()
# pdf(paste('cns_dev/by_lineage/monocle.lineage.2.timepoint', n_pcs, 'pdf', sep='.'))
# plot_cells(
#     cds.lin2,
#     color_cells_by='timepoint',
#     label_cell_groups=FALSE,
#     label_branch_points=FALSE,
#     label_leaves=FALSE,
#     trajectory_graph_segment_size=0.5,
#     labels_per_group=3,
# ) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7))
# dev.off()

# pdf(paste('cns_dev/by_lineage/monocle.lineage.1.genotype', n_pcs, 'pdf', sep='.'))
# plot_cells(
#     cds.lin1,
#     color_cells_by='genotype',
#     label_cell_groups=FALSE,
#     label_branch_points=FALSE,
#     label_leaves=FALSE,
#     trajectory_graph_segment_size=0.5,
#     labels_per_group=3,
# ) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)) 
# dev.off()
# pdf(paste('cns_dev/by_lineage/monocle.lineage.2.genotype', n_pcs, 'pdf', sep='.'))
# plot_cells(
#     cds.lin2,
#     color_cells_by='genotype',
#     label_cell_groups=FALSE,
#     label_branch_points=FALSE,
#     label_leaves=FALSE,
#     trajectory_graph_segment_size=0.5,
#     labels_per_group=3,
# ) + theme(legend.title=element_text(size=7), legend.text=element_text(size=7)) 
# dev.off()

# Write pseudotime compute on the two lineages to disk
write.csv(
    pseudotime(cds.lin1),
    paste(
        'cns_dev/by_lineage/monocle.lineage.1', n_pcs,
        'pseudotime.csv', sep='.'
    ),
)
write.csv(
    pseudotime(cds.lin2),
    paste(
        'cns_dev/by_lineage/monocle.lineage.2', n_pcs,
        'pseudotime.csv', sep='.'
    ),
)
write.csv(
    pseudotime(cds.lin3),
    paste(
        'cns_dev/by_lineage/monocle.lineage.3', n_pcs,
        'pseudotime.csv', sep='.'
    ),
)
write.csv(
    pseudotime(cds.lin4),
    paste(
        'cns_dev/by_lineage/monocle.lineage.4', n_pcs,
        'pseudotime.csv', sep='.'
    ),
) 
