# Clear workspace
rm(list=ls())

# Load libraries
library(liger)
library(Seurat)
library(ggplot2)
library(cowplot)
library(arrow)
# feather library became obsolete during the project
# it got replaced by arrow library that provides the updated
# `read_feather()` function
# library(feather)
theme_set(theme_cowplot())

# Uncomment the line corresponding to the dataset to batch-correct with LIGER
# prefix <- 'AGGR01_mapped'
# prefix <- 'AGGR01_unmapped'

# Load counts matrix after QC
data <- as.data.frame(read_feather(paste(prefix, '.qc.fth', sep='')))
rownames(data) <- data[,1]
data <- data[,-1]

# Load cell annotations
meta.data <- read.table(
    sep=',',
    header=TRUE,
    check.names=FALSE,
    paste(prefix, '.qc.metadata.csv', sep=''),
    row.names=1,
)

# Create Seurat object from counts matrix
sdata <- CreateSeuratObject(
    t(data),
    project=prefix,
    assay='RNA',
    meta.data=meta.data,
)

# Remove temporary data
rm(data)
rm(meta.data)

# Convert to LIGER object and remove Seurat object
ldata <- liger::seuratToLiger(sdata, combined.seurat=T, meta.var='batch')
rm(sdata)

# LIGER pre-processing: counts normalization, top variable genes
# selection, scaling (but not centering) of each gene distribution
ldata <- normalize(ldata)
ldata <- selectGenes(ldata)
ldata <- scaleNotCenter(ldata)

# Save data snapshot
saveRDS(ldata, file=paste(prefix, '.liger.rds', sep=''))
ldata <- readRDS(paste(prefix, '.liger.rds', sep=''))

# Compute integration on various k values
pdf('k.pdf')
suggestK(ldata, k.test=seq(20,70,5), num.cores=8)
dev.off()

# Select k value (see downstream analyses to check the final k value)
if (prefix == 'AGGR01_mapped') {
    k <- 45
} else if (prefix == 'AGGR01_unmapped') {
    k <- 45
}

# This step might help choosing lambda but due to a bug
# it fails most of the time without results
# Resorting to choosing lambda with default value (lines below)
# pdf('lambda.pdf')
# suggestLambda(ldata, k=k, rand.seed=42, num.cores=4)
# dev.off()
# if (prefix == 'AGGR01_mapped') {
    # lambda <- 6
# } else if (prefix == 'AGGR01_unmapped') {
    # lambda <- 10
# }

# Set lambda to default value
lambda <- 5

# Align and quantile normalize batches
ldata <- optimizeALS(ldata, k=k, lambda=lambda)
ldata <- quantile_norm(ldata)

# Save data snapshot
saveRDS(ldata, file=paste(prefix, '.liger.rds', sep=''))
ldata <- readRDS(paste(prefix, '.liger.rds', sep=''))

# Save usage matrix
write.table(
    as.data.frame(ldata@H.norm),
    file=paste(prefix, '.liger.usage_norm.csv', sep=''),
    sep=',',
    quote=FALSE,
    col.names=NA,
)

# Save factor loadings matrix
write.table(
    as.data.frame(ldata@W),
    file=paste(prefix, '.liger.weights_shared.csv', sep=''),
    sep=',',
    quote=FALSE,
    col.names=NA,
)
