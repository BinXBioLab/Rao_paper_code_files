#relavite cell types inc ontrol

#%%
# Setup
import warnings
import matplotlib
from matplotlib import pyplot as plt
from matplotlib.colors import ListedColormap
warnings.filterwarnings("ignore")

import arviz as az
import pandas as pd
import pickle as pkl

from sccoda.util import comp_ana as mod
from sccoda.util import cell_composition_data as dat
from sccoda.util import data_visualization as viz

#%%
# Set visual style
import seaborn as sns
sns.set(style='white')


# %%
# Set prefix for dataset
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

# %%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

#%%
# Set annotation name
key = 'nowakowski.fine.noglyc_unmapped' 

# %%
# Read data
adata = sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")
adata

#%%
# Generate data for scCODA from main data
covariates = ['pair', 'genotype', 'timepoint']
data = dat.from_scanpy(
    adata, cell_type_identifier=key, sample_identifier='batch',
    covariate_df=adata.obs.groupby('batch')[covariates].first(),
)
data
# %%
adata70= adata[adata.obs["timepoint"]=="70d"]

adata70Con = adata70[adata70.obs["genotype"]== "Control"]

adata150= adata[adata.obs["timepoint"]=="150d"]
adata150Con = adata150[adata150.obs["genotype"]== "Control"]


# %%
(adata70Con.obs['nowakowski.fine.noglyc_unmapped']=="EN").sum()/16087 * 100


# %%
celltype70 = (adata70Con.obs['nowakowski.fine.noglyc_unmapped']).value_counts(normalize=True)
celltype150 = (adata150Con.obs['nowakowski.fine.noglyc_unmapped']).value_counts(normalize=True)

# %%
celltypescontrol= pd.concat ([celltype70, celltype150], axis = 1, keys=["70d", "150d"])
# %%
celltypescontrol.to_csv("E:/Sneha/RNAseq/scSeq/Composition/Control_Composition.csv")