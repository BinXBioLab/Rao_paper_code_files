#Layer Specific marker analysis
#%%
# Import modules
##rom gprofiler import GProfiler
from errno import ENOLCK
import matplotlib.pyplot as plt
import os
import pandas as pd
import seaborn as sns
from typing import Dict, Sequence
import natsort
from natsort import natsorted
import scanpy as sc

#%% Layer specific cell type
nmarkers = natsorted(list(set([
  'RELN', 'CUX1', 'POU3F2', 'BRN2', 'NECAB1', 'CTIP2', 'CNTC6', 'PCP4', 'BCL11B', 'FOXP2', 'CTGF', 'TBR1', 'SATB2', 'CUX2',
]) & set(adata.raw.var_names)))

#%%
#Maturity markers
matmarkers = natsorted(list(set([
  'DCX', 'EOMES', 'SLC17A7', 'SLC17A6', 'MAP2', 'RBFOX3',
]) & set(adata.raw.var_names)))


#%%
# Plot clustering with selected resolution through UMAP
sc.pl.umap(
    adata,
    color=nmarkers,
    save = 'layermarkers4.pdf',
    legend_loc='on data',
)

# %%
dataEN = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="EN"]
dataEN70d = dataEN[dataEN.obs["timepoint"]=="70d"]
dataEN150d = dataEN[dataEN.obs["timepoint"]=="150d"]
adata70d = adata[adata.obs["timepoint"]=="70d"]
adata150d = adata[adata.obs["timepoint"]=="150d"]


#%%
TBR170= (adata70d[adata70d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB270= (adata70d[adata70d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B70= (adata70d[adata70d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX270= (adata70d[adata70d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


TBR1150= (adata150d[adata150d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB2150= (adata150d[adata150d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B150= (adata150d[adata150d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX2150= (adata150d[adata150d.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)

TBR170= pd.DataFrame(TBR170, columns =["TBR170"])
SATB270= pd.DataFrame(SATB270, columns =["SATB270"])
BCL11B70= pd.DataFrame(BCL11B70, columns =["BCL11B70"])
CUX270= pd.DataFrame(CUX270, columns =["CUX270"])
TBR1150= pd.DataFrame(TBR1150, columns =["TBR1150"])
SATB2150= pd.DataFrame(SATB2150, columns =["SATB2150"])
BCL11B150= pd.DataFrame(BCL11B150, columns =["BCL11B150"])
CUX2150= pd.DataFrame(CUX2150, columns =["CUX2150"])

layer_data = pd.concat((TBR170, SATB270, BCL11B70, CUX270, TBR1150, SATB2150, BCL11B150, CUX2150))
layer_data

layer_data.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data.csv")


#%%
adata70dcase = adata70d[adata70d.obs["genotype"]=="Case"]
adata70dcontrol = adata70d[adata70d.obs["genotype"]=="Control"]

#%%
TBR170case= (adata70dcase[adata70dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB270case= (adata70dcase[adata70dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B70case= (adata70dcase[adata70dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX270case= (adata70dcase[adata70dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


TBR170control= (adata70dcontrol[adata70dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB270control= (adata70dcontrol[adata70dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B70control= (adata70dcontrol[adata70dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX270control= (adata70dcontrol[adata70dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


#%%
TBR170case= pd.DataFrame(TBR170case, columns =["TBR170case"])
SATB270case= pd.DataFrame(SATB270case, columns =["SATB270case"])
BCL11B70case= pd.DataFrame(BCL11B70case, columns =["BCL11B70case"])
CUX270case= pd.DataFrame(CUX270case, columns =["CUX270case"])
TBR170control= pd.DataFrame(TBR170control, columns =["TBR170control"])
SATB270control= pd.DataFrame(SATB270control, columns =["SATB270control"])
BCL11B70control= pd.DataFrame(BCL11B70control, columns =["BCL11B70control"])
CUX270control= pd.DataFrame(CUX270control, columns =["CUX270control"])


#%%
layer_data70DEN = pd.concat((TBR170case, SATB270case, BCL11B70case, CUX270case, TBR170control, SATB270control, BCL11B70control, CUX270control))
layer_data70DEN

layer_data70DEN.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data70DEN.csv")

#%%
adata150dcase = adata[adata.obs["genotype"]=="Case"]
adata150dcontrol = adata[adata.obs["genotype"]=="Control"]

#%%
TBR1150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB2150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX2150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


TBR1150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB2150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX2150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


#%%
TBR1150case= pd.DataFrame(TBR1150case, columns =["TBR1150case"])
SATB2150case= pd.DataFrame(SATB2150case, columns =["SATB2150case"])
BCL11B150case= pd.DataFrame(BCL11B150case, columns =["BCL11B150case"])
CUX2150case= pd.DataFrame(CUX2150case, columns =["CUX2150case"])
TBR1150control= pd.DataFrame(TBR1150control, columns =["TBR1150control"])
SATB2150control= pd.DataFrame(SATB2150control, columns =["SATB2150control"])
BCL11B150control= pd.DataFrame(BCL11B150control, columns =["BCL11B150control"])
CUX2150control= pd.DataFrame(CUX2150control, columns =["CUX2150control"])


#%%
layer_data150DEN = pd.concat((TBR1150case, SATB2150case, BCL11B150case, CUX2150case, TBR1150control, SATB2150control, BCL11B150control, CUX2150control))
layer_data150DEN

layer_data150DEN.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data1500DEN.csv")
#%%
sc.pl.dotplot (dataEN70d, nmarkers, groupby= "genotype", save= "E:/Sneha/RNAseq/scSeq/AGGR01_mapped/fig_supp/layer markers 70d")
sc.pl.dotplot (dataEN150d, nmarkers, groupby= "genotype", save= "E:/Sneha/RNAseq/scSeq/AGGR01_mapped/fig_supp/layer markers 150d")

#%%
# %%
sc.pl.dotplot (dataEN70d, matmarkers, groupby= "genotype", save= "mature markers 70d")
sc.pl.dotplot (dataEN150d, matmarkers, groupby= "genotype", save= "mature markers 150d")

#%%
#%%
sc.pl.dotplot (dataEN70d, "DCX",  groupby= "genotype", save= "DCX EN 70d")
sc.pl.dotplot (dataEN70d, "EOMES", groupby= "genotype", save="EOMES EN 70d")
sc.pl.dotplot (dataEN70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 EN 70d")
sc.pl.dotplot (dataEN70d, "SLC17A6", groupby= "genotype", save= "SL17A6 EN 70d")
sc.pl.dotplot (dataEN70d, "MAP2", groupby= "genotype", save= "MAP2 EN 70d") 
sc.pl.dotplot (dataEN70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 EN 70d")

#%%
# %%
sc.pl.dotplot (dataEN150d, "DCX", groupby= "genotype", save= "DCX EN 150d")
sc.pl.dotplot (dataEN150d, "EOMES", groupby= "genotype",save= "EOMES EN 150d")
sc.pl.dotplot (dataEN150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 EN 150d")
sc.pl.dotplot (dataEN150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 EN 150d")
sc.pl.dotplot (dataEN150d, "MAP2", groupby= "genotype",save= "MAP2 EN 150d")
sc.pl.dotplot (dataEN150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 EN 150d")

# %%
datanEN_early = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="nEN-early"]
datanEN_early70d = datanEN_early[datanEN_early.obs["timepoint"]=="70d"]
datanEN_early150d = datanEN_early[datanEN_early.obs["timepoint"]=="150d"]

#%%
# %%
sc.pl.dotplot (datanEN_early70d, nmarkers, groupby= "genotype", save= "layer markers nen_early 70d")
sc.pl.dotplot (datanEN_early150d, nmarkers, groupby= "genotype", save= "layer markers nEN_early 150d")

#%%
# %%
sc.pl.dotplot (datanEN_early70d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 70d")
sc.pl.dotplot (datanEN_early150d, matmarkers, groupby= "genotype", save= "mature nEN_early markers 150d")

#%%
# %%
sc.pl.dotplot (datanEN_early70d, "DCX",  groupby= "genotype", save= "DCX earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "EOMES", groupby= "genotype", save="EOMES earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "SLC17A6", groupby= "genotype", save= "SL17A6 earlynen 70d")
sc.pl.dotplot (datanEN_early70d, "MAP2", groupby= "genotype", save= "MAP2 earlynen 70d") 
sc.pl.dotplot (datanEN_early70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 earlynen 70d")

#%%
# %%
sc.pl.dotplot (datanEN_early150d, "DCX", groupby= "genotype", save= "DCX earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "EOMES", groupby= "genotype",save= "EOMES earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "MAP2", groupby= "genotype",save= "MAP2 earlynen 150d")
sc.pl.dotplot (datanEN_early150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 earlynen 150d")

#%%
''' #%%#%%
TBR1150case= datanEN_early150d[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB2150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX2150case= (adata150dcase[adata150dcase.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)


TBR1150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'TBR1'].X > 0).mean(0) 
SATB2150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'BCL11B'].X > 0).mean(0)
CUX2150control= (adata150dcontrol[adata150dcontrol.obs['nowakowski.fine.noglyc_unmapped'].isin(["EN"]),:][:,'CUX2'].X > 0).mean(0)

#%%
TBR1150case= pd.DataFrame(TBR1150case, columns =["TBR1150case"])
SATB2150case= pd.DataFrame(SATB2150case, columns =["SATB2150case"])
BCL11B150case= pd.DataFrame(BCL11B150case, columns =["BCL11B150case"])
CUX2150case= pd.DataFrame(CUX2150case, columns =["CUX2150case"])
TBR1150control= pd.DataFrame(TBR1150control, columns =["TBR1150control"])
SATB2150control= pd.DataFrame(SATB2150control, columns =["SATB2150control"])
BCL11B150control= pd.DataFrame(BCL11B150control, columns =["BCL11B150control"])
CUX2150control= pd.DataFrame(CUX2150control, columns =["CUX2150control"])
layer_data150DENearly = pd.concat((TBR1150case, SATB2150case, BCL11B150case, CUX2150case, TBR1150control, SATB2150control, BCL11B150control, CUX2150control))
layer_data150DENearly
layer_data150DENearly.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data1500DENearly.csv") '''

#%%
#%%
layer_data70DENearly = pd.concat((TBR1150case, SATB2150case, BCL11B150case, CUX2150case, TBR1150control, SATB2150control, BCL11B150control, CUX2150control))
layer_data70DENearly
layer_data70DENearly.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data700DEN.csv")


#%%

datanEN_late = adata[adata.obs["nowakowski.fine.noglyc_unmapped"]=="nEN-late"]
datanEN_late70d = datanEN_early[datanEN_early.obs["timepoint"]=="70d"]
datanEN_late150d = datanEN_early[datanEN_early.obs["timepoint"]=="150d"]

#%%
# %%
sc.pl.dotplot (datanEN_late70d, nmarkers, groupby= "genotype", save= "layer markers nen_late 70d")
sc.pl.dotplot (datanEN_late150d, nmarkers, groupby= "genotype", save= "layer markers nEN_late 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, "DCX",  groupby= "genotype", save= "DCX latenen 70d")
sc.pl.dotplot (datanEN_late70d, "EOMES", groupby= "genotype", save="EOMES latenen  70d")
sc.pl.dotplot (datanEN_late70d, "SLC17A7", groupby= "genotype", save= "SLC17A7 latenen  70d")
sc.pl.dotplot (datanEN_late70d, "SLC17A6", groupby= "genotype", save= "SL17A6 latenen  70d")
sc.pl.dotplot (datanEN_late70d, "MAP2", groupby= "genotype", save= "MAP2 latenen 70d") 
sc.pl.dotplot (datanEN_late70d, "RBFOX3", groupby= "genotype", save= "RBFOX3 latenen  70d")

#%%
# %%
sc.pl.dotplot (datanEN_late150d, "DCX", groupby= "genotype", save= "DCX latenen 150d")
sc.pl.dotplot (datanEN_late150d, "EOMES", groupby= "genotype",save= "EOMES latenen 150d")
sc.pl.dotplot (datanEN_late150d, "SLC17A7", groupby= "genotype",save= "SLC17A7 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "SLC17A6", groupby= "genotype",save= "SLC17A6 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "MAP2", groupby= "genotype",save= "MAP2 latenen 150d")
sc.pl.dotplot (datanEN_late150d, "RBFOX3", groupby= "genotype",save= "RBFOX3 latenen 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, matmarkers, groupby= "genotype", save= "mature nEN_late markers 70d")
sc.pl.dotplot (datanEN_late150d, matmarkers, groupby= "genotype", save= "mature nEN_late markers 150d")

#%%
# %%
sc.pl.dotplot (datanEN_late70d, nmarkers, groupby= "genotype", save= "layer markers nen_late 70d")
sc.pl.dotplot (datanEN_late150d, nmarkers, groupby= "genotype", save= "layer markers nEN_late 150d")

#%%
# %% Subset layer specific cells
adata_subset = adata[adata[: , 'TBR1'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL6 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL6 150d")


#%%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL6 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL6 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL6  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL6 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2  ENL6 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL6 70d")

#%%
# %%
sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL6 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL6 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL6 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL6 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL6 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL6 150d")

#%%
# %%
adata_subset = adata.raw[adata.raw[: , 'SATB2'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL2 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL2 150d")

# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL2 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL2 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL2  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL2 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2  ENL2 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL2 70d")


#%%
# %%
sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL2 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL2 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL2 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL2 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL2 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL2 150d")

#%%
# %%
adata_subset = adata[adata[: , 'BCL11B'].X > 0.5, :]

#%%
#%%
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]

#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL56 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL56 150d")
# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL56 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL56 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL56  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL56 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2 ENL5670d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL56 70d")


sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL56 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL56 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL56 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL56 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL56 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL56 150d")

#%%
# %%
adata_subset = adata[adata[: , 'CUX1'].X > 0.5, :]
adata_subset70 = adata_subset[adata_subset.obs["timepoint"]=="70d"]
adata_subset150 = adata_subset[adata_subset.obs["timepoint"]=="150d"]


#%%
#%%
sc.pl.dotplot (adata_subset70, matmarkers, groupby= "genotype", save= "mature EN markersL23 70d")
sc.pl.dotplot (adata_subset150, matmarkers, groupby= "genotype", save= "mature EN markersL23 150d")

# %%
# %%
sc.pl.dotplot (adata_subset70, "DCX",  groupby= "genotype", save= "DCX ENL23 70d")
sc.pl.dotplot (adata_subset70, "EOMES", groupby= "genotype", save="EOMES ENL23 70d")
sc.pl.dotplot (adata_subset70, "SLC17A7", groupby= "genotype", save= "SLC17A7  ENL23  70d")
sc.pl.dotplot (adata_subset70, "SLC17A6", groupby= "genotype", save= "SL17A6  ENL23 70d")
sc.pl.dotplot (adata_subset70, "MAP2", groupby= "genotype", save= "MAP2 ENL23 70d") 
sc.pl.dotplot (adata_subset70, "RBFOX3", groupby= "genotype", save= "RBFOX3  ENL23 70d")


sc.pl.dotplot (adata_subset150, "DCX", groupby= "genotype", save= "DCX  ENL23 150d")
sc.pl.dotplot (adata_subset150, "EOMES", groupby= "genotype",save= "EOMES  ENL23 150d")
sc.pl.dotplot (adata_subset150, "SLC17A7", groupby= "genotype",save= "SLC17A7  ENL23 150d")
sc.pl.dotplot (adata_subset150, "SLC17A6", groupby= "genotype",save= "SLC17A6  ENL23 150d")
sc.pl.dotplot (adata_subset150, "MAP2", groupby= "genotype",save= "MAP2  ENL23 150d")
sc.pl.dotplot (adata_subset150, "RBFOX3", groupby= "genotype",save= "RBFOX3  ENL23 150d")


# %%

## Layer specific proportions of total timepoint dataset
TBR170case= (adata_subset70[adata_subset70.obs['genotype'].isin(["Case"]),:][:,'TBR1'].X > 0).mean(0) 
SATB270case=(adata_subset70[adata_subset70.obs['genotype'].isin(["Case"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B70case=(adata_subset70[adata_subset70.obs['genotype'].isin(["Case"]),:][:,'BCL11B'].X > 0).mean(0)
CUX270case= (adata_subset70[adata_subset70.obs['genotype'].isin(["Case"]),:][:,'CUX2'].X > 0).mean(0)


TBR170control= (adata_subset70[adata_subset70.obs['genotype'].isin(["Control"]),:][:,'TBR1'].X > 0).mean(0) 
SATB270control= (adata_subset70[adata_subset70.obs['genotype'].isin(["Control"]),:][:,'SATB2'].X > 0).mean(0)
BCL11B70control= (adata_subset70[adata_subset70.obs['genotype'].isin(["Control"]),:][:,'BCL11B'].X > 0).mean(0)
CUX270control= (adata_subset70[adata_subset70.obs['genotype'].isin(["Control"]),:][:,'CUX2'].X > 0).mean(0)


#%%
TBR170case= pd.DataFrame(TBR170case, columns =["TBR170case"])
SATB270case= pd.DataFrame(SATB270case, columns =["SATB270case"])
BCL11B70case= pd.DataFrame(BCL11B70case, columns =["BCL11B70case"])
CUX270case= pd.DataFrame(CUX270case, columns =["CUX270case"])
TBR170control= pd.DataFrame(TBR170control, columns =["TBR170control"])
SATB270control= pd.DataFrame(SATB270control, columns =["SATB270control"])
BCL11B70control= pd.DataFrame(BCL11B70control, columns =["BCL11B70control"])
CUX270control= pd.DataFrame(CUX270control, columns =["CUX270control"])


#%%
layer_data70DBygenotype = pd.concat((TBR170case, SATB270case, BCL11B70case, CUX270case, TBR170control, SATB270control, BCL11B70control, CUX270control))
layer_data70DBygenotype

layer_data70DBygenotype.to_csv ("E:/Sneha/RNAseq/scSeq/layer data/Layer_data70DByGenotype.csv")

# %%

adata= sc.read("E:/Sneha/RNAseq/scSeq/AGGR01_mapped/AGGR01_mapped.final.h5ad")
dataIN = adata[adata.obs["nowakowski.fine.noglyc_unmapped"].isin(["IN-STR", "IN-CTX", "nIN"])]
dataIN70d = dataIN[dataIN.obs["timepoint"]=="70d"]
dataIN150d = dataIN[dataIN.obs["timepoint"]=="150d"]

#%%
#Broad agabergic markers
gabamarkers = natsorted(list(set([
  'GAD1', 'GAD2'
]) & set(adata.raw.var_names)))



#%%
#%%
# Plot clustering with selected resolution through UMAP
sc.pl.umap(
    dataIN70d,
    color=gabamarkers,
    save = 'gaba markers 70D.pdf',
    legend_loc='on data',
)


# %%
sc.pl.umap(
    dataIN150d,
    color="nowakowski.fine.noglyc_unmapped",
    save = 'gaba markers ann 150D.pdf',
    legend_loc='on data',
)

# %%
