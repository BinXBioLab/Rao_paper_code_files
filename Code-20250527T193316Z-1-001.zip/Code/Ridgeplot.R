## Generate ridge plots of cells along pseudotime
setwd("E:/Sneha/RNAseq/SCSeq/Ridge plot")

library(Seurat)
# 1. Load seurat object
sdata = readRDS ('E:/Sneha/RNAseq/ScSeq/wgcna/AGGR01.70d..seurat.final.rds')



# Load pseudotime infor for cells

pseudo= read.csv ("E:/Sneha/RNAseq/ScSeq/Ridge plot/monocle.6.pseudotime.csv", header= TRUE, row.names = 1)

# 
# #Normalize seurat
# sdata = # S3 method for Seurat
#   NormalizeData(
#     sdata,
#     assay = "RNA",
#     normalization.method = "LogNormalize",
#     scale.factor = 10000,
#     margin = 1,
#     verbose = TRUE,
#   )

# add pseudotime to Seurat metadata
sdata <- AddMetaData(
  object = sdata,
  metadata = pseudo,
  col.name = 'pseudotime'
)
head(x = sdata[[]])



saveRDS(sdata, "AGGr01.seurat.final.pseudo.70D.rds")
#sdata = readRDS("E:/Sneha/RNAseq/ScSeq/Ridge plot/AGGr01.seurat.final.pseudo.70D.rds")

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  sdata,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# subset case and control separately and run above analysis
sdata_case = subset(x = sdata, subset = genotype == "Case")
sdata_control = subset(x = sdata, subset = genotype == "Control")

# prefix = sdata_case
prefix= sdata_case

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)

### further narrow
sdata_EN = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "EN")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_EN,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)

sdata_divRG = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "RG-div")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_divRG,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)

sdata_earlyRG = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "RG-early")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_earlyRG,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


sdata_IPCnen = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "IPC-nEN")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_IPCnen,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


sdata_nenearly = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "nEN-early")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_nenearly,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


sdata_nenlate = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == "nEN-late")
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  sdata_nenlate,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


## Subset only excitatory lineage
sdata_ENlin = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
prefix = sdata_ENlin
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)



#Subset by genotype

ENlin_case=subset(x = prefix, subset = genotype == "Case")
ENlin_control = subset(x = prefix, subset = genotype == "Control")


prefix = ENlin_case
#prefix = ENlin_control

RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped.aggr',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = 'pink',
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)



write.csv(sdata_ENlin@meta.data, "data.ridge.csv")

rm(list=ls())


data = read.csv("data.ridge.csv", header= TRUE, row.names =1)

case=subset(data, data$genotype=="Case")
control=subset(data, data$genotype=="Control")

ks.test(case$pseudotime , control$pseudotime)



##150D 
sdata = readRDS("E:/Sneha/RNAseq/ScSeq/wgcna/AGGR01.seurat.final.rds")
# Load pseudotime infor for cells
pseudo= read.csv ("E:/Sneha/RNAseq/ScSeq/Ridge plot/monocle.6.pseudotime.csv", header= TRUE, row.names = 1)

# add pseudotime to Seurat metadata
sdata <- AddMetaData(
  object = sdata,
  metadata = pseudo,
  col.name = 'pseudotime'
)
head(x = sdata[[]])


#Subset 150D data
sdata_sub = subset(x = sdata, subset = timepoint == "150d")


#saveRDS(sdata_sub, "AGGRO1.final.seurat.150D.rds")
sdata = readRDS("AGGRO1.final.pseudo.seurat.150D.rds")


## plot ridge plot
# bY CELL TYPE

sdata= sdata_sub
RidgePlot(
  sdata,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  sdata,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


## Subset only excitatory lineage
sdata_ENlin = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
prefix = sdata_ENlin
## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# subset case and control separately and run above analysis
sdata_case = subset(x = sdata_ENlin, subset = genotype == "Case")
sdata_control = subset(x = sdata_ENlin, subset = genotype == "Control")

# prefix = sdata_case
prefix= sdata_control

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = 'grey',
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)



##STATISTICS
write.csv(sdata_ENlin@meta.data, "150DENlin.data.ridge.csv")


data = read.csv("150DENlin.data.ridge.csv", header= TRUE, row.names =1)

case=subset(data, data$genotype=="Case")
control=subset(data, data$genotype=="Control")

EN_linKS = ks.test(case$pseudotime , control$pseudotime)


#Subset interneuron lineage
sdata_INlin = subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("MGE-RG", 'MGE-IPC', 'MGE-RG-IPC-div', 'nIN', 'IN-CTX', 'IN-STR' ))

prefix= sdata_INlin

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# subset case and control separately and run above analysis
sdata_case = subset(x = sdata_INlin, subset = genotype == "Case")
sdata_control = subset(x = sdata_INlin, subset = genotype == "Control")

prefix = sdata_case
#prefix= sdata_control

## plot ridge plot
# bY CELL TYPE
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = NULL,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'nowakowski.fine.noglyc_unmapped',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)


# By genotype
RidgePlot(
  prefix,
  features = "pseudotime",
  cols = 'pink',
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = 'genotype',
  y.max = 10,
  same.y.lims = TRUE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  stack = FALSE,
  combine = FALSE,
  fill.by = "ident"
)

##STATISTICS

write.csv(sdata_INlin@meta.data, "150DINlin.data.ridge.csv")


data = read.csv("150DINlin.data.ridge.csv", header= TRUE, row.names =1)

case=subset(data, data$genotype=="Case")
control=subset(data, data$genotype=="Control")

IN_linKS = ks.test(case$pseudotime , control$pseudotime)


