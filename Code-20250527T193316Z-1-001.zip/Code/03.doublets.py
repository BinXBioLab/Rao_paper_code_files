#%%
# Load modules
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import scipy.stats as ss
import scrublet
import seaborn as sns
import sys

sns.set_style('white')
plt.rcParams['savefig.facecolor'] = 'w'

#%%
# Not used, custom functions added to code
# os.chdir('../..')
# sys.path.append(os.path.abspath('..'))
# from fbrundu_sclib import *

#%%
# Define samples
samples = ['AGGR01_mapped']
prefix = samples[0]
prefix

#%%
from typing import Callable
def fullpath_closure(data_dir: str) -> Callable:
    """Helper function for path generation."""
    import os
    def fullpath(path):
        return os.path.join(data_dir, path)
    return fullpath

#%%
# Helper closures for path generation
# Data dir is the folder containing raw data
# Out dir is the folder where results will be saved
data_dir = os.path.join('data')
data = fullpath_closure(data_dir) 
out_dir = os.path.join('results', 'v01', prefix)
out = fullpath_closure(out_dir) 

#%%
# Import scanpy and configure
import scanpy as sc
sc.settings.verbosity = 3
sc.settings.set_figure_params(dpi=150, dpi_save=150)
sc.settings.figdir = out('fig_supp')

#%%
# NOTE Load the following snapshot if you already executed scrublet
# and you want to revert and redo your filtering
# adata = sc.read(out(f'interim_data/scrublet/{prefix}.final.prefilter.h5ad'))

#%%
# NOTE Otherwise, on first execution load the final snapshot
adata = sc.read(out(f'{prefix}.final.h5ad'))

#%%
# Use the unmapped data for higher sensitivity (no read depth normalization)
# NOTE This version of the data can be used since each batch is analyzed 
# separately
adata_counts = sc.read(
    f'results/v01/AGGR01_unmapped/interim_data/qc/AGGR01_unmapped.preqc.h5ad'
)
adata_counts.obs['batch'].value_counts().sort_index()

#%%
# Run scrublet and identify the threshold to discriminate synthetic doublets
doublet_obs = None
for batch in adata_counts.obs['batch'].unique():
    # https://assets.ctfassets.net/an68im79xiti/4IDeyOMrQ0D76LCIcQ8yjX/7436e76fb408cbcf166616af264d758e/CG000184_ChromiumSingle_Cell3__v3_FeatureBarcoding_CRISPR_Screening_UG_Rev_C.pdf
    # NOTE check correct percentage from user guide
    rate_prefix = {
        'JS001': 0.035,
        'JS002': 0.039,
        'JS003': 0.054,
        'JS004': 0.03,
        'JS005': 0.043,
        'JS006': 0.061,
        'JS3001': 0.027,
        'JS3002': 0.045,
        'JS3003': 0.03,
        'JS3004': 0.031,
        'JS3005': 0.037,
        'JS3006': 0.039,
    }
    rate = rate_prefix[batch]
    print(f'Working on {batch}: starting rate {rate}')

    # Get counts matrix for the current batch
    adata_counts_batch = adata_counts[
        adata_counts.obs['batch'] == batch, :
    ].copy()
    counts_matrix = adata_counts_batch.X
    print(f'Original shape {counts_matrix.shape}')

    # Execute scrublet
    scrub = scrublet.Scrublet(counts_matrix, expected_doublet_rate=rate)
    doublet_scores, predicted_doublets = scrub.scrub_doublets(
        min_counts=5, min_cells=5, min_gene_variability_pctl=85,
        n_prin_comps=30,
    )

    # Define threshold to call doublets
    if batch in ('JS001',):
        thr = 0.18
    elif batch in ('JS006',):
        thr = 0.25
    else:
        thr = 0.2
    predicted_doublets = scrub.call_doublets(threshold=thr)
    scrub.plot_histogram()
    plt.savefig(
        out(f'fig_supp/scrublet_unmapped/{batch}.hist.pdf'),
        bbox_inches='tight',
    )

    # Save doublet score and prediction for each cell in the current batch
    doublet_obs = pd.concat([
        doublet_obs, pd.concat([
        pd.Series(doublet_scores, index=adata_counts_batch.obs_names, name='doublet_score'),
        pd.Series(predicted_doublets, index=adata_counts_batch.obs_names, name='doublet_pred')
        ], axis=1)],
    axis=0)

#%%
doublet_obs

#%%
# Save scrublet results in full data (mapped AnnData)
adata.obs = adata.obs.loc[:, ~adata.obs.columns.str.startswith('doublet_')]
adata.obs = pd.concat([
    adata.obs,
    doublet_obs.loc[adata.obs_names, ['doublet_score', 'doublet_pred']],
], axis=1)

#%%
adata

#%%
sc.pl.umap(
    adata,
    color=['doublet_pred', 'doublet_score'],
    cmap='viridis',
    ncols=1,
    save='.scrublet.score.pdf',
)

#%%
# Save snapshot pre-filtering
adata.write(
    out(f'interim_data/scrublet_unmapped/{prefix}.final.prefilter.h5ad')
)

#%%
adata = sc.read(
    out(f'interim_data/scrublet_unmapped/{prefix}.final.prefilter.h5ad')
)
adata

#%%
# NOTE idempotent transformation necessary when column is transformed to string
adata.obs['doublet_pred'] = (adata.obs['doublet_pred'].astype(str) == 'True')
adata.obs['doublet_pred'].value_counts()

#%%
def pl_multi_violin(
    adata: sc.AnnData,
    keys: List[str],
    groupby: str,
    fname: str,
    ncols: int = 4,
    wspace: float = 0.4,
):
    """ Plot different keys on different violin plots with
        tunable parameters.
    """
    import matplotlib.pyplot as plt
    import scanpy as sc
    r = len(keys) // ncols + int((len(keys) % ncols) != 0)
    fig, axs = plt.subplots(r, ncols, figsize=(ncols*5, r*5))
    axs = axs.ravel()
    for i, ax in enumerate(axs):
        if i < len(keys):
            k = keys[i]
            sc.pl.violin(adata, keys=k, groupby=groupby, ax=ax, show=False)
        else:
            ax.axis('off')
    plt.subplots_adjust(wspace=wspace)
    fig.savefig(fname, bbox_inches='tight')

#%%
# Plot some QC metrics splitting on doublet prediction
adata.obs['doublet_pred'] = pd.Categorical(adata.obs['doublet_pred'])
keys = ['n_genes', 'n_counts', 'percent_mito', 'percent_ribo_p'] 
fname = out('fig_supp/scrublet_unmapped/violin.qc.scrublet.doublet_pred.pdf') 
pl_multi_violin(adata, keys, groupby='doublet_pred', fname=fname, ncols=4)

#%%
# Filter predicted doublets
adata = adata[~adata.obs['doublet_pred'].astype(bool), :].copy()
adata

#%%
# Recompute neighbors and UMAP projection
sc.pp.neighbors(
    adata,
    n_pcs=adata.obsm['X_liger_H'].shape[1],
    random_state=42,
    use_rep='X_liger_H',
)
sc.tl.umap(adata, random_state=42)

#%%
sc.pl.umap(
    adata,
    cmap='viridis',
    ncols=1,
)

#%%
# Filter genes with very low expression
sc.pp.filter_genes(adata, min_counts=5)
sc.pp.filter_genes(adata, min_cells=5)

#%%
# Save final snapshot
adata.write(out(f'{prefix}.final.h5ad'))
adata

# %%
