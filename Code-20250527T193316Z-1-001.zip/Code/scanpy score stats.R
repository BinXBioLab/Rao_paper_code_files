library(lme4)
# xdata = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/WGCNAscores.csv", header= TRUE, row.names =1 )
# data = subset(data, data$timepoint == "70d")
# 
# module1= data$module1
# module2= data$module2
# module3 = data$module3
# 
# 
# #module 1
# mdl1 = lmer(data$module1 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module1 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module2 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module3 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 1
# mdl1 = lmer(data$module1 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module1 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module3 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ## ENLIN
# library(lme4)
# data = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/ENlin/ENlin_WGCNAscores.csv", header= TRUE, row.names =1 )
# #data = subset(data, data$timepoint == "70d")
# 
# 
# module2= data$module2
# module3= data$module3
# module4 = data$module4
# module9 = data$module9
# 
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module2 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module3 ~ (1|data$batch))
# anova(mdl2, mdl1)
# 
# 
# #module 4
# mdl1 = lmer(data$module4 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module4 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module9
# mdl1 = lmer(data$module9 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module9 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# 
# ##pair
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module3 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 4
# mdl1 = lmer(data$module4 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module4 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 9
# mdl1 = lmer(data$module9 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module9 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ###Only EN, and nEN
# 
# data = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/EN70D/EN70D_WGCNAscores.csv", header= TRUE, row.names =1 )
# 
# 
# ##Batch
# #module 1
# mdl1 = lmer(data$module1 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module1 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module7
# mdl1 = lmer(data$module7 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module7 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# 
# ##pair
# 
# #module 1
# mdl1 = lmer(data$module1 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module1 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 7
# mdl1 = lmer(data$module7 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module7 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ### 150DIV ENlin
# data = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/ENlin150D/ENlin150_WGCNAscores.csv", header= TRUE, row.names =1 )
# 
# 
# ##Batch
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module2 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module3~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 5
# mdl1 = lmer(data$module5 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module5 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module10
# mdl1 = lmer(data$module10 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module10~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 15
# mdl1 = lmer(data$module15 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module15~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module17
# mdl1 = lmer(data$module17 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module17~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# 
# ##pair
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module3 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 5
# mdl1 = lmer(data$module5 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module5 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 10
# mdl1 = lmer(data$module10 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module10 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 15
# mdl1 = lmer(data$module15 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module15 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 17
# mdl1 = lmer(data$module17 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module17 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ####################################################################################
# 
# ### 150DIV Interneuron lin
# data = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/INlin150D/INlin150_WGCNAscores.csv", header= TRUE, row.names =1 )
# 
# 
# ##Batch
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module2 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module3~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 5
# mdl1 = lmer(data$module5 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module5 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module10
# mdl1 = lmer(data$module10 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module10~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 11
# mdl1 = lmer(data$module11 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module11 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module13
# mdl1 = lmer(data$module13 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module13 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module 16
# mdl1 = lmer(data$module16 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module16~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module17
# mdl1 = lmer(data$module17 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module17~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# 
# ##pair
# 
# #module 2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 3
# mdl1 = lmer(data$module3 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module3 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 5
# mdl1 = lmer(data$module5 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module5 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 10
# mdl1 = lmer(data$module10 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module10 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 11
# mdl1 = lmer(data$module11 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module11 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 13
# mdl1 = lmer(data$module13 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module13 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 16
# mdl1 = lmer(data$module16 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module16 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #module 17
# mdl1 = lmer(data$module17 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module17 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ################################################################################################
# 
# ###Randomw modules 
# data = read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/ENlin/ENlin70RANDOM_WGCNAscores.csv", header= TRUE, row.names =1 )
# 
# 
# ##Batch
# #r1
# mdl1 = lmer(data$r1 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r1 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r2
# mdl1 = lmer(data$r2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r2~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r3
# mdl1 = lmer(data$r3 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r3 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r4
# mdl1 = lmer(data$r4 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r4~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r5
# mdl1 = lmer(data$r5 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r5 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r6
# mdl1 = lmer(data$r6 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r6~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# #r7
# mdl1 = lmer(data$r7 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r7 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #r8
# mdl1 = lmer(data$r8 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$r8~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# ##pair
# 
# #r1
# mdl1 = lmer(data$r1 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r1 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r2
# mdl1 = lmer(data$r2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r3
# mdl1 = lmer(data$r3 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r3 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r4
# mdl1 = lmer(data$r4 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r4 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r5
# mdl1 = lmer(data$r5 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r5 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r6
# mdl1 = lmer(data$r6 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r6 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r7
# mdl1 = lmer(data$r7 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r7 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r8
# mdl1 = lmer(data$r8 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$r8 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# #### In at 70DIV
# data= read.csv("E:/Sneha/RNAseq/ScSeq/wgcna/INlin70_WGCNAscores.csv")
# 
# 
# #batch
# #module2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module2 ~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# #module12
# mdl1 = lmer(data$module.12 ~data$genotype + (1|data$batch))
# mdl2= lmer(data$module.12~ (1|data$batch))
# 
# anova(mdl2, mdl1)
# 
# 
# ##pair
# 
# #module2
# mdl1 = lmer(data$module2 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module2 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# #r2
# mdl1 = lmer(data$module.12 ~data$genotype + (1|data$pair))
# mdl2= lmer(data$module.12 ~ (1|data$pair))
# 
# anova(mdl2, mdl1)
# 
# 
# ########################################################################################################
setwd("E:/Sneha/RNAseq/ScSeq/wgcna")
sdata = readRDS("AGGR01.70d..seurat.final.rds")
sdata_Enlin.WGCNA= readRDS ("ENlin/AGGR01.ControlENlin.70DIV.WGCNA.rds")
library(Seurat)


#plot WGCNA Scores
sdata = AddModuleScore(
  sdata,
  data,
  pool = NULL,
  nbin = 24,
  ctrl = 10,
  k = FALSE,
  assay = NULL,
  name = "module",
  seed = 1,
  search = FALSE,
)

sdata_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div", "RG-early", "IPC-div", "IPC-nEN", "nEN-early", "nEN-late", "EN"))
data =sdata@meta.data
data


#batch
#module2
mdl1 = lmer(data$module2 ~ data$genotype + (1|data$batch))
mdl2= lmer(data$module2 ~ (1|data$batch))

anova(mdl2, mdl1)

#module9
mdl1 = lmer(sdata@meta.data$module9 ~data$genotype + (1|data$batch))
mdl2= lmer(sdata@meta.data$module9~ (1|data$batch))

anova(mdl2, mdl1)

#module3
mdl1 = lmer(data$module3 ~data$genotype + (1|data$batch))
mdl2= lmer(data$module3 ~ (1|data$batch))

anova(mdl2, mdl1)

#module9
mdl1 = lmer(data$module4 ~data$genotype + (1|data$batch))
mdl2= lmer(data$module4~ (1|data$batch))

anova(mdl2, mdl1)



#Violin plots
median.stat <- function(x){
  out <- quantile(x, probs = c(0.5))
  names(out) <- c("ymed")
  return(out) 
}


VlnPlot(
  sdata_sub,
  features = "module2",
  cols = NULL,
  pt.size = 0,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = "genotype",
  split.by = NULL,
  adjust = 1,
  y.max = 0.25,
  same.y.lims = FALSE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  split.plot = FALSE,
  stack = FALSE,
  combine = TRUE,
  fill.by = "feature",
  flip = FALSE,
  raster = NULL
)+ stat_summary(fun.y = mean, geom='point', size = 25, colour = "black", shape = 95) 

VlnPlot(
  sdata_sub,
  features = "module9",
  cols = NULL,
  pt.size = 0,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = "genotype",
  split.by = NULL,
  adjust = 1,
  y.max = NULL,
  same.y.lims = FALSE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  split.plot = FALSE,
  stack = FALSE,
  combine = TRUE,
  fill.by = "feature",
  flip = FALSE,
  raster = NULL
)+ stat_summary(fun.y = median, geom='point', size = 25, colour = "black", shape = 95)

VlnPlot(
  sdata_sub,
  features = "module3",
  cols = NULL,
  pt.size = 0,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = "genotype",
  split.by = NULL,
  adjust = 1,
  y.max = NULL,
  same.y.lims = FALSE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  split.plot = FALSE,
  stack = FALSE,
  combine = TRUE,
  fill.by = "feature",
  flip = FALSE,
  raster = NULL
)+ stat_summary(fun.y = median, geom='point', size = 25, colour = "black", shape = 95)


VlnPlot(
  sdata_sub,
  features = "module4",
  cols = NULL,
  pt.size = 0,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = "genotype",
  split.by = NULL,
  adjust = 1,
  y.max = NULL,
  same.y.lims = FALSE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  split.plot = FALSE,
  stack = FALSE,
  combine = TRUE,
  fill.by = "feature",
  flip = FALSE,
  raster = NULL
)+ stat_summary(fun.y = median, geom='point', size = 25, colour = "black", shape = 95)



####violin plots for cell cyclce hallmark genes

#plot WGCNA Scores
library (ggplot2)

data = read.delim("E:/Sneha/RNAseq/ScSeq/hallmark_reactome_M-G1.txt")

sdata = AddModuleScore(
  sdata,
  data,
  pool = NULL,
  nbin = 24,
  ctrl = 10,
  k = FALSE,
  assay = NULL,
  name = "module",
  seed = 1,
  search = FALSE,
)


median.stat <- function(x){
  out <- quantile(x, probs = c(0.5))
  names(out) <- c("ymed")
  return(out) 
}


sdata_sub= subset(x = sdata, subset = nowakowski.fine.noglyc_unmapped == c("RG-div"))

VlnPlot(
  sdata_sub,
  features = "module1" ,
  cols = NULL,
  pt.size = 0,
  idents = NULL,
  sort = FALSE,
  assay = NULL,
  group.by = "genotype",
  split.by = NULL,
  adjust = 1,
  y.max = NULL,
  same.y.lims = FALSE,
  log = FALSE,
  ncol = NULL,
  slot = "data",
  split.plot = FALSE,
  stack = FALSE,
  combine = TRUE,
  fill.by = "feature",
  flip = FALSE,
  raster = NULL
)+ stat_summary(fun.y = mean, geom='point', size = 25, colour = "black", shape = 95)

data =sdata_sub@meta.data
data

#batch
#module2
mdl1 = lmer(data$module1 ~ data$genotype + (1|data$batch))
mdl2= lmer(data$module1 ~ (1|data$batch))
anova(mdl2, mdl1)
